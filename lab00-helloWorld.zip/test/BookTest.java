import org.junit.Before;
import org.junit.Test;

import cs5010.lab00.book.Book;
import cs5010.lab00.book.Person;

import static org.junit.Assert.assertEquals;

/**
 * A JUnit test class for the Person class.
 */
public class BookTest {
  private Book hogwarts;
  private Person auth;

  @Before
  public void setUp() {

    auth = new Person("JK", "Rowling", 1980);
    hogwarts = new Book("Harry Potter", auth, 50.27f);
  }

  @Test
  public void testTitle() {
    assertEquals("Harry Potter", hogwarts.getTitle());
  }

  @Test
  public void testAuthorFirstname() {
    assertEquals("JK", auth.getFirstName());
  }

  @Test
  public void testAuthorLastname() {
    assertEquals("Rowling", auth.getLastName());
  }

  @Test
  public void testAuthorYearOfBirth() {
    assertEquals(1980, auth.getYearOfBirth());
  }

  @Test
  public void testPrice() {
    assertEquals(50.27, hogwarts.getPrice(), 0.001);
  }
}