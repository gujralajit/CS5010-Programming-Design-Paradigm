package list;

/**
 * Interface for list of term.
 */
public interface ListOfTerm {

  ListOfTerm addTerm(int coefficient, int power) throws IllegalArgumentException;

  boolean isSame(ListOfTerm poly);

  double evaluate(double x);

  int getCoefficient(int power);

  int getDegree();

  ListOfTerm addToBack(Term t);

  ListOfTerm add(ListOfTerm l1);
}