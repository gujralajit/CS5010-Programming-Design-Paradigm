package list;

/**
 * Empty term node.
 */
public class TermEmptyNode implements ListOfTerm {

  /**
   * Adding empty node.
   *
   * @param coefficient coef
   * @param power       power
   * @return empty node
   */
  @Override
  public ListOfTerm addTerm(int coefficient, int power) {
    Term temp = new Term(coefficient, power);
    return new TermElementNode(temp, new TermEmptyNode());
  }

  @Override
  public boolean isSame(ListOfTerm poly) {
    return true;
  }

  @Override
  public double evaluate(double x) {
    return 0;
  }

  @Override
  public int getCoefficient(int power) {
    return 0;
  }

  @Override
  public int getDegree() {
    return 0;
  }

  @Override
  public String toString() {
    return "";
  }

  @Override
  public ListOfTerm addToBack(Term t) {
    return new TermElementNode(t, new TermEmptyNode());
  }

  @Override
  public ListOfTerm add(ListOfTerm l1) {
    return new TermEmptyNode();
  }
}
