package list;

/**
 * Creating poly term.
 */
public class Term {

  private final int coefficient;
  private final int power;

  /**
   * Constrictor for term.
   *
   * @param coefficient coef
   * @param power       power
   */
  public Term(int coefficient, int power) {

    this.coefficient = coefficient;
    this.power = power;
  }

  int getCoefficient() {

    return coefficient;
  }

  int getDegree() {

    return power;
  }
}
