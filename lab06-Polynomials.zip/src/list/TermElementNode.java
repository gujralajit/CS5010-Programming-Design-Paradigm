package list;

/**
 * Term element node for list.
 */
public class TermElementNode implements ListOfTerm {

  private final Term term;
  private ListOfTerm rest;

  /**
   * Constructor for term.
   *
   * @param term term
   * @param rest rest of list
   */
  public TermElementNode(Term term, ListOfTerm rest) {

    this.term = term;
    this.rest = rest;
  }

  @Override
  public ListOfTerm addTerm(int coefficient, int power) throws IllegalArgumentException {
    if (power == term.getDegree()) {
      return new TermElementNode(new Term(coefficient + term.getCoefficient(), power),
              rest);
    } else if (power > term.getDegree()) {
      return new TermElementNode(new Term(coefficient, power), this);
    } else {
      return new TermElementNode(term, rest.addTerm(coefficient, power));
    }
  }

  @Override
  public boolean isSame(ListOfTerm poly) {
    if (term.getCoefficient() == poly.getCoefficient(term.getDegree())) {
      return rest.isSame(poly);
    } else {
      return false;
    }
  }

  @Override
  public double evaluate(double x) {
    return (term.getCoefficient() * Math.pow(x, term.getDegree())) + rest.evaluate(x);
  }

  @Override
  public int getCoefficient(int power) {
    if (term.getDegree() == power) {
      return term.getCoefficient();
    } else {
      return rest.getCoefficient(power);
    }
  }

  @Override
  public int getDegree() {
    return Math.max(term.getDegree(), rest.getDegree());
  }

  @Override
  public String toString() {
    String s;
    if (term.getCoefficient() >= 0) {
      return "+" + term.getCoefficient() + "x^" + term.getDegree() + " " + rest.toString();
    } else {
      return term.getCoefficient() + "x^" + term.getDegree() + " " + rest.toString();
    }
  }

  @Override
  public ListOfTerm addToBack(Term t) {
    rest = rest.addToBack(t);
    return new TermElementNode(term, rest);
  }

  @Override
  public ListOfTerm add(ListOfTerm l1) {
    Term temp = new Term((term.getCoefficient() + l1.getCoefficient(term.getDegree())),
            term.getDegree());
    return new TermElementNode(temp, rest.add(l1));
  }

}
