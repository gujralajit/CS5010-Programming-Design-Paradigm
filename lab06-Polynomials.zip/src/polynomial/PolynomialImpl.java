package polynomial;

import list.ListOfTerm;
import list.Term;
import list.TermElementNode;
import list.TermEmptyNode;

/**
 * Implementing polynomial using string.
 */
public class PolynomialImpl implements Polynomial {

  private ListOfTerm head = new TermEmptyNode();

  /**
   * Constructor for empty polynomial.
   */
  public PolynomialImpl() {
    head = new TermElementNode(new Term(0, 0), new TermEmptyNode());
  }

  /**
   * Constructor for polynomial based on given string.
   *
   * @param poly is the string polynomial
   */
  public PolynomialImpl(String poly) {

    String[] temp = poly.split(" ");
    for (String s : temp) {
      int pow;
      int coef;
      if (s.contains("^")) {
        pow = Integer.parseInt(s.substring(s.indexOf("^") + 1));
        try {
          if (s.substring(0, s.indexOf("x")).equals("+")) {
            coef = 1;
          } else {
            coef = Integer.parseInt(s.substring(0, s.indexOf("x")));
          }
        } catch (NumberFormatException e) {
          throw new IllegalArgumentException("coef is incorrect here : " + e);
        }
      } else {
        pow = 0;
        coef = Integer.parseInt(s);
      }
      if (pow < 0) {
        throw new IllegalArgumentException("Power cannot be negative");
      }
      head = head.addTerm(coef, pow);
    }
  }

  /**
   * This method is used to add the string as a polynomial. The string takes in terms separated
   * by a space. It checks for the coefficient and degree of the terms and adds it to the list.
   * Terms of same power are added by the sum of the coefficient and a new node is created.
   *
   * @param other the other polynomial to be added
   * @return the new polynomial
   * @throws IllegalArgumentException for incorrect arguments
   */
  @Override
  public Polynomial add(Polynomial other) throws IllegalArgumentException {

    ListOfTerm temp = new TermEmptyNode();
    int i = Math.max(other.getDegree(), head.getDegree());
    while (i >= 0) {
      int coef = other.getCoefficient(i) + head.getCoefficient(i);
      if (coef != 0) {
        Term t = new Term(coef, i);
        if (temp instanceof TermEmptyNode) {
          temp = new TermElementNode(t, temp);
        } else {
          temp = temp.addToBack(t);
        }
      }
      i--;
    }
    return new PolynomialImpl(temp.toString());
  }

  /**
   * This method adds the terms to the polynomial that has already been created. The terms are added
   * in the order of their power, which means that higher power terms are added to the front of the
   * list and lower power terms are added to the back of the list.
   *
   * @param coefficient the coefficient of the term to be added
   * @param power       the power of the term to be added
   * @throws IllegalArgumentException for incorrect arguments
   */
  @Override
  public void addTerm(int coefficient, int power) throws IllegalArgumentException {

    if (power < 0) {
      throw new IllegalArgumentException("Power cannot be negative");
    }
    head = head.addTerm(coefficient, power);
  }

  @Override
  public boolean isSame(Polynomial poly) {
    Polynomial p1 = new PolynomialImpl(head.toString());
    return poly.toString().equals(p1.toString());
  }

  @Override
  public double evaluate(double x) {
    return head.evaluate(x);
  }

  @Override
  public int getCoefficient(int power) {
    if (power < 0) {
      throw new IllegalArgumentException("Power cannot be negative");
    }
    return head.getCoefficient(power);
  }

  @Override
  public int getDegree() {
    return head.getDegree();
  }

  @Override
  public String toString() {
    if (head.toString().length() > 1 && head.toString().charAt(0) == '+') {
      if (head.toString().equals("+0x^0 ")) {
        return "0";
      }
      if (head.toString().endsWith("+0x^0 ")) {
        return head.toString().substring(1, head.toString().length() - 7);
      } else if (head.toString().endsWith("x^0 ")) {
        return head.toString().substring(1, head.toString().length() - 4);
      }
      return head.toString().substring(1);
    } else {
      if (head.toString().endsWith("+0x^0 ")) {
        return head.toString().substring(0, head.toString().length() - 7);
      } else if (head.toString().endsWith("x^0 ")) {
        return head.toString().substring(0, head.toString().length() - 4);
      }
      return head.toString();
    }
  }
}
