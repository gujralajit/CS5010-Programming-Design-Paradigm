package polynomial;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Test for polynomial.
 */
public class PolynomialImplTest {

  Polynomial p1;
  Polynomial p2;
  Polynomial p3;
  Polynomial p4;
  Polynomial p5;

  @Before
  public void setUp() {
    p1 = new PolynomialImpl("5 +2x^1 +4x^2 +4x^2");
    p2 = new PolynomialImpl("8x^2 +2x^1 +5");
    p3 = new PolynomialImpl();
    p4 = new PolynomialImpl();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testPoly() {

    assertEquals("0", p3.toString());
    assertEquals("8x^2 +2x^1 +5", p2.toString());
    assertEquals("8x^2 +2x^1 +5", p1.toString());
    assertEquals(true, p1.isSame(p2));
    p3 = new PolynomialImpl("2");
    assertEquals("2", p3.toString());
    p5 = new PolynomialImpl("");
    p5 = new PolynomialImpl(null);
    p4 = new PolynomialImpl("4x^-5 + 74 + 3x ^ 2");
    p4 = new PolynomialImpl("4x^5 +x^3 +7");
    assertEquals(-992, p4.evaluate(-3), 0.1);
    assertEquals(1006, p4.evaluate(3), 0.1);
    assertEquals("4x^5 +1x^3 +7", p4.toString());
    assertEquals(false, p1.isSame(p4));
    assertEquals("4x^5 +1x^3 +8x^2 +2x^1 +12", p1.add(p4).toString());
    assertEquals("16x^2 +4x^1 +10", p1.add(p2).toString());
    p3 = new PolynomialImpl();
    p4 = new PolynomialImpl();
    assertEquals("0", p3.add(p4).toString());
    assertEquals(true, p3.isSame(p4));
    p1.addTerm(1, -5);
    p1.addTerm(2, 2);
    assertEquals("10x^2 +2x^1 +5", p1.toString());
    p1.addTerm(3, 3);
    assertEquals("3x^3 +10x^2 +2x^1 +5", p1.toString());
    assertEquals(3, p1.getDegree());
    assertEquals(3, p1.getCoefficient(3));
    assertEquals(0, p1.getCoefficient(4));
    p3 = new PolynomialImpl("5");
    assertEquals(0, p3.getDegree());
  }
}