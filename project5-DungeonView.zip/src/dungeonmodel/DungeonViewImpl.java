package dungeonmodel;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

/**
 * The view implementation of the dungeon as created by the given parameters by the user. This
 * displays the game state and various visual features of the game to the player.
 */
public class DungeonViewImpl implements DungeonView {

  private final GraphicController cont;
  private final JFrame frame;
  private GamePanel gamePanel;
  private ReadOnlyModel model;
  private PlayerInfoPanel playerInfoPanel;
  private int prevKeyCode;

  /**
   * A constructor for the view of the graphic dungeon which takes in the controller to pass
   * values to the controller while creating the dungeon and to pass various moves.
   *
   * @param controller is the controller for our graphic game
   */
  public DungeonViewImpl(GraphicController controller) {
    if (controller != null) {
      frame = new JFrame();
      this.cont = controller;
      prevKeyCode = 0;
    } else {
      throw new IllegalArgumentException("Null controller has been passed to the view. ");
    }
  }

  @Override
  public void createGamePanel(ReadOnlyModel model) {
    if (model != null) {
      this.model = model;
      frame.setLayout(new GridLayout());
      frame.setTitle("Can you kill the Otyugh? ");
      frame.setSize(400, 400);
      frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

      JMenuBar menuBar;
      JMenu menu;
      menuBar = new JMenuBar();
      JMenuItem menuItem;

      menu = new JMenu("Menu");
      menuBar.add(menu);
      menuItem = new JMenuItem(new AbstractAction("Settings") {
        public void actionPerformed(ActionEvent e) {
          frame.dispose();
          cont.playGame(0);
        }
      });
      menu.add(menuItem);

      menuItem = new JMenuItem(new AbstractAction("Restart") {
        public void actionPerformed(ActionEvent e) {
          frame.dispose();
          cont.playGame(1);
        }
      });
      menu.add(menuItem);

      menuItem = new JMenuItem(new AbstractAction("Quit") {
        public void actionPerformed(ActionEvent e) {
          frame.dispatchEvent(new WindowEvent(frame, WindowEvent.WINDOW_CLOSING));
        }
      });
      menu.add(menuItem);

      frame.setJMenuBar(menuBar);

      gamePanel = new GamePanel(model);

      //https://stackoverflow.com/questions/1385737/scrollable-jpanel
      int width = 320;
      int height = 180;
      gamePanel.setPreferredSize(
              new Dimension(model.getRowSize() * width, model.getColumnSize() * height));
      JScrollPane scrollFrame = new JScrollPane(gamePanel);

      frame.add(scrollFrame);
      //https://stackoverflow.com/questions/41172472/how-to-make-jpanel-scrollable
    } else {
      throw new IllegalArgumentException("Null model has been passed to the view. ");
    }
  }

  @Override
  public String getAttributes() {
    StringBuilder sb = new StringBuilder();

    //https://stackoverflow.com/questions/6555040/multiple-input-in-joptionpane-showinputdialog/6555051
    JTextField rowField = new JTextField("5", 5);
    JTextField columnField = new JTextField("5", 5);
    JTextField interconnectivityField = new JTextField("5", 5);
    JCheckBox wrappingField = new JCheckBox("Wrapping");
    JTextField cavePercentageField = new JTextField("50", 5);
    JTextField difficultyField = new JTextField("0", 5);

    JPanel myPanel = new JPanel();
    myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
    myPanel.add(new JLabel("Row:"));
    myPanel.add(rowField);
    myPanel.add(new JLabel("Column:"));
    myPanel.add(columnField);
    myPanel.add(new JLabel("Interconnectivity:"));
    myPanel.add(interconnectivityField);
    myPanel.add(wrappingField);
    myPanel.add(new JLabel("Cave Percentage:"));
    myPanel.add(cavePercentageField);
    myPanel.add(new JLabel("Difficulty:"));
    myPanel.add(difficultyField);

    int result = JOptionPane.showConfirmDialog(null, myPanel,
            "Settings", JOptionPane.OK_CANCEL_OPTION);
    if (result == JOptionPane.OK_OPTION) {
      sb.append(rowField.getText()).append(",");
      sb.append(columnField.getText()).append(",");
      sb.append(interconnectivityField.getText()).append(",");
      sb.append(wrappingField.isSelected()).append(",");
      sb.append(cavePercentageField.getText()).append(",");
      sb.append(difficultyField.getText()).append(",");
    } else {
      System.exit(0);
    }
    return sb.toString();
  }

  @Override
  public void setModel(ReadOnlyModel model) {
    if (model != null) {
      this.model = model;
    } else {
      throw new IllegalArgumentException("Null model has been passed to the view. ");
    }
  }

  @Override
  public void setPlayerInfoPanel() {
    playerInfoPanel = new PlayerInfoPanel(model);
    frame.add(playerInfoPanel);
  }

  @Override
  public void setFeedback(String givenFeedback) {
    if (givenFeedback != null) {
      playerInfoPanel.setFeedback(givenFeedback);
    } else {
      throw new IllegalArgumentException("Feedback cannot be null. ");
    }
  }

  @Override
  public void addClickListener(GraphicController listener) {
    if (listener != null) {
      if (!model.isGameOver()) {
        MouseAdapter clickAdapter = new MouseAdapter() {
          @Override
          public void mouseClicked(MouseEvent e) {
            if (e != null) {
              super.mouseClicked(e);
              int row = e.getY();
              int column = e.getX();

              int playerRow = model.getPlayerRow();
              int playerColumn = model.getPlayerColumn();

              row = row / 50;
              column = column / 50;

              if (row == playerRow && column > playerColumn) {
                listener.handleCellClick("south");
              } else if (row == playerRow && column < playerColumn) {
                listener.handleCellClick("north");
              } else if (row > playerRow && column == playerColumn) {
                listener.handleCellClick("east");
              } else if (row < playerRow && column == playerColumn) {
                listener.handleCellClick("west");
              }
              refresh();
            } else {
              throw new IllegalArgumentException("Null mouse event has been passed to the view. ");
            }
          }
        };
        gamePanel.addMouseListener(clickAdapter);
      }
    } else {
      throw new IllegalArgumentException("Null controller has been passed to the view. ");
    }
  }

  @Override
  public void addKeyListener(GraphicController listener) {
    if (listener != null) {
      if (!model.isGameOver()) {
        KeyListener keyListener = new KeyListener() {
          @Override
          public void keyTyped(KeyEvent e) {
            //empty body since we don't need to capture key typed data
          }

          @Override
          public void keyPressed(KeyEvent e) {
            //empty body since we don't need to capture key pressed data
          }

          @Override
          public void keyReleased(KeyEvent e) {
            if (e != null) {
              if (prevKeyCode == 83) {
                if (e.getKeyCode() == 37 || e.getKeyCode() == 38 || e.getKeyCode() == 39
                        || e.getKeyCode() == 40) {
                  JPanel myPanel = new JPanel();
                  myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
                  JTextField rowField = new JTextField("1", 5);
                  myPanel.add(new JLabel("Enter distance to shoot (1-5)"));
                  myPanel.add(rowField);

                  int distance = 0;
                  int result = JOptionPane.showConfirmDialog(null, myPanel,
                          "Enter distance", JOptionPane.OK_CANCEL_OPTION);
                  if (result == JOptionPane.OK_OPTION) {
                    try {
                      distance = Integer.parseInt(rowField.getText());
                    } catch (NumberFormatException npe) {
                      distance = 1;
                    }
                  }
                  listener.handleKeyPress(83, e.getKeyCode(), distance);
                  prevKeyCode = e.getKeyCode();
                }
              } else {
                listener.handleKeyPress(e.getKeyCode(), 0, 0);
                prevKeyCode = e.getKeyCode();
              }
            } else {
              throw new IllegalArgumentException("Null key event has been passed to the view. ");
            }
          }
        };
        frame.addKeyListener(keyListener);
      }
    } else {
      throw new IllegalArgumentException("Null controller has been passed to the view. ");
    }
  }

  @Override
  public void refresh() {
    playerInfoPanel.repaint();
    frame.repaint();
  }

  @Override
  public void makeVisible() {
    frame.setVisible(true);
  }
}
