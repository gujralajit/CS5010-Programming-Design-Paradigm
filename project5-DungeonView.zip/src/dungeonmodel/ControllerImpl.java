package dungeonmodel;

import java.io.IOException;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * This the controller implementation for the dungeon which takes in the model and allows the
 * user to give valid commands and play the game. It acts as a bridge between the user and the
 * dungeon.
 */
public class ControllerImpl implements Controller {

  private final Readable in;
  private final Appendable out;
  private final Model model;

  /**
   * Constructor for the controller class for our dungeon.
   *
   * @param model is the model created in the driver class and assigned to the controller
   * @param in    is the readable assigned to the controller, which in our case is System.in
   * @param out   is the appendable assigned to the controller, which in our case is System.out
   */
  public ControllerImpl(Model model, Readable in, Appendable out) {
    if (model != null && in != null && out != null) {
      this.in = in;
      this.out = out;
      this.model = model;
    } else {
      throw new IllegalArgumentException("Null values have been passed to the controller. ");
    }
  }

  @Override
  public void playGame() {

    Scanner sc = new Scanner(in);
    String nextMove = "";
    try {
      out.append(model.getCurrentLocation());
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }

    while (!model.isGameOver() && !nextMove.equals("quit")) {
      try {
        out.append("\nMove, pickup, shoot or quit? ");
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
      }

      nextMove = sc.next();
      try {
        switch (nextMove.toLowerCase().trim()) {
          case "q":
          case "quit":
            try {
              nextMove = "quit";
              out.append("Quitting the game. ");
            } catch (IOException e) {
              throw new IllegalStateException("Illegal arguments have been passed for appendable.");
            }
            break;
          case "m":
          case "move":
            String sb = move(sc);
            if (sb.contains("Better luck next time")) {
              return;
            }
            break;
          case "p":
          case "pickup":
            try {
              out.append("Pick up treasure or arrow? ");
            } catch (IOException e) {
              throw new IllegalStateException("Illegal arguments have been passed for appendable.");
            }
            nextMove = sc.next();
            try {
              switch (nextMove.toLowerCase().trim()) {
                case "a":
                case "arrow":
                  pickupArrow();
                  break;
                case "t":
                case "treasure":
                  pickupTreasure();
                  break;
                default:
                  try {
                    out.append("Invalid command ").append(nextMove).append(". Try again. \n");
                  } catch (IOException e) {
                    throw new IllegalStateException("Illegal arguments have been passed for "
                            + "appendable. ");
                  }
                  break;
              }
            } catch (NullPointerException npe1) {
              throw new IllegalArgumentException("Null arguments have been passed for commands. ");
            }
            break;
          case "s":
          case "shoot":
            shoot(sc);
            break;
          default:
            try {
              out.append("Invalid command ").append(nextMove).append(". Try again. \n");
            } catch (IOException e) {
              throw new IllegalStateException("Illegal arguments have been passed for appendable.");
            }
            break;
        }
      } catch (NullPointerException npe) {
        throw new IllegalArgumentException("Null arguments have been passed for commands. ");
      }
      if (!model.isGameOver() && !nextMove.trim().equals("quit")) {
        try {
          out.append(model.getCurrentLocation());
        } catch (IOException e) {
          throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
        }
      }
    }
    if (/*out.toString().contains("Better luck next time") && */!nextMove.trim().equals("quit")) {
      try {
        out.append("");
        out.append("Congratulations on winning the game! \n");
        out.append("You have exited the dungeon successfully. ");
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
      }
    }
  }

  @Override
  public void shoot(Scanner sc) {
    if (sc != null) {
      try {
        out.append("Enter direction in which arrow is to be shot : ");
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
      }
      String direction = sc.next();
      try {
        out.append("Enter distance at which arrow is to be shot (1-5): ");
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
      }

      int distance = 0;
      try {
        distance = sc.nextInt();
        if (distance <= 0 || distance > 5) {
          throw new IllegalArgumentException();
        }
        try {
          out.append(model.shootArrow(direction, distance));
        } catch (IOException e) {
          throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
        }
      } catch (IllegalArgumentException | InputMismatchException e) {
        try {
          out.append("Illegal arguments detected for move: direction -> ").append(direction);
          out.append(" distance -> ").append(String.valueOf(distance)).append(". Try again. \n");
        } catch (IOException ioe) {
          throw new IllegalArgumentException("Illegal arguments have been passed for appendable. ");
        }
      }
    } else {
      throw new IllegalArgumentException("Null values have been passed to the controller. ");
    }
  }

  @Override
  public String move(Scanner sc) {
    if (sc != null) {
      try {
        out.append("Move where? ");
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
      }
      String nextMove = sc.next();
      try {
        String s = model.move(nextMove);
        out.append(s);
        nextMove = s;
      } catch (IllegalArgumentException | IOException iae) {
        try {
          out.append("Invalid move ").append(nextMove).append(". Try again. \n");
        } catch (IOException e) {
          throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
        }
      }
      return nextMove;
    } else {
      throw new IllegalArgumentException("Null values have been passed to the controller. ");
    }
  }

  @Override
  public void pickupArrow() {
    model.pickupArrows();
    try {
      out.append(model.getPlayerDetails()).append("\n");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public void pickupTreasure() {
    model.pickupTreasure();
    try {
      out.append(model.getPlayerDetails()).append("\n");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }
}