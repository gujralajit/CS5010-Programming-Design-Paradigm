package dungeonmodel;

/**
 * A view for the graphic dungeon of our game. The view has the ability to show the game to the
 * player with various visual feedbacks. The player is able to look at the current location and
 * nodes that have been visited by it. The rest of the dungeon is shrouded in darkness. The
 * dungeon opens up more and more to the player as they continue traversing the dungeon.
 */
public interface DungeonView {

  /**
   * Creates a game panel for the view. This panel contains the game state and the locations are
   * displayed here as the player traverses them. It starts of as blank and continues to be
   * visible and the player navigates through the caves.
   *
   * @param model is the model of the game to get game state
   */
  void createGamePanel(ReadOnlyModel model);

  /**
   * This method displays the settings of the dungeon such as the row, column, interconnectivity,
   * wrapping nature, the cave percentage as well as the difficulty. Based on these parameters,
   * the dungeon is created.
   *
   * @return the string containing the parameters of the user defined dungeon.
   */
  String getAttributes();

  /**
   * Sets the model of the dungeon to the view so that it can capture the game state and do
   * various functions.
   *
   * @param model is the read only model of the dungeon which exposes only a select few read only
   *              methods required by the view
   */
  void setModel(ReadOnlyModel model);

  /**
   * Sets the player information panel at the side. This panel displays the player information at
   * all times displaying the amount of treasures and arrows available to the player at all
   * times.
   */
  void setPlayerInfoPanel();

  /**
   * Assigns a click listener to the given controller to capture the various clicks happening on
   * the game panel. These clicks are used to move the player if there exists a valid move.
   *
   * @param listener is the controller which captures the clicks
   */
  void addClickListener(GraphicController listener);

  /**
   * Assigns a keyboard listener to the given controller to capture the various key presses
   * happening on the game panel. These keys presses are used to move the player, shoot an arrow,
   * or pickup treasure or arrows.
   *
   * @param listener is the controller which captures the clicks
   */
  void addKeyListener(GraphicController listener);

  /**
   * Refreshes the view to display new information after every move, shoot, or pickup instance.
   */
  void refresh();

  /**
   * Makes the view visible. The game state will not be shown to the player until this is visible.
   */
  void makeVisible();

  /**
   * Sets the feedback text for the user based on the user's previous actions.
   *
   * @param givenFeedback is the given feedback from the controller
   */
  void setFeedback(String givenFeedback);
}
