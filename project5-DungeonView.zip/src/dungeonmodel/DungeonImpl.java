package dungeonmodel;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Creates the dungeon based on the given row and column numbers. Based on the given
 * interconnectivity, wrapping and percentage of caves having treasure, we create an adjacency list
 * and form the dungeon based on this.
 */
public class DungeonImpl implements Dungeon {

  private final Cave[][] dungeon;
  private final Player player;
  private final int interconnectivity;
  private final boolean wrapping;
  private final int cavePercentage;
  private Vertex start;
  private Vertex end;
  private Vertex currentLocation;
  private List<Edge> adjacencyList;
  private final List<Otyugh> listOfMonsters;

  /**
   * Constructor for the dungeon based on the given attributes.
   *
   * @param row               denotes the row number of the dungeon
   * @param column            denotes the column number of the dungeon
   * @param interconnectivity denotes the interconnectivity of the dungeon
   * @param wrapping          denotes if the dungeon is wrapping or not
   * @param cavePercentage    denotes the percentage of caves having treasure
   */
  public DungeonImpl(int row, int column, int interconnectivity, boolean wrapping,
                     int cavePercentage, int difficulty) {
    if (row > 0 && column > 0 && interconnectivity >= 0 && cavePercentage >= 0
            && cavePercentage <= 100 && difficulty >= 0 && difficulty <= Math.min(row, column)) {
      this.interconnectivity = interconnectivity;
      this.wrapping = wrapping;
      this.dungeon = createDungeon(row, column);
      this.player = new PlayerImpl();
      this.cavePercentage = cavePercentage;
      this.currentLocation = getStart();
      populateDungeon();
      listOfMonsters = new ArrayList<>();
      assignMonsters(difficulty);
      dungeon[start.getRow()][start.getColumn()].setVisitedFlag();
    } else {
      throw new IllegalArgumentException("Illegal arguments have been passed to the dungeon. ");
    }
  }

  /**
   * A copy constructor to create a deep copy of the dungeon used when we need to restart the
   * game using the same parameters and want to land in the same dungeon.
   *
   * @param d1 is the dungeon whose copy is to be made
   */
  public DungeonImpl(DungeonImpl d1) {
    if (d1 != null) {
      this.interconnectivity = d1.getInterconnectivity();
      this.wrapping = d1.getWrapping();
      this.dungeon = d1.getDungeon();
      this.player = new PlayerImpl();
      this.cavePercentage = d1.getCavePercentage();
      this.start = d1.getStart();
      this.end = d1.getEnd();
      this.currentLocation = d1.getStart();
      this.listOfMonsters = d1.getListOfMonsters();
      this.adjacencyList = d1.getAdjacencyList();
      dungeon[start.getRow()][start.getColumn()].setVisitedFlag();
    } else {
      throw new IllegalArgumentException("Dungeon cannot be null. ");
    }
  }

  private int getInterconnectivity() {
    return interconnectivity;
  }

  private Boolean getWrapping() {
    return wrapping;
  }

  private Cave[][] getDungeon() {
    Cave[][] tempDungeon1 = new Cave[getRowSize()][getColumnSize()];
    for (int i = 0; i < getRowSize(); i++) {
      for (int j = 0; j < getColumnSize(); j++) {
        tempDungeon1[i][j] = new Cave(dungeon[i][j]);
      }
    }
    return tempDungeon1;
  }

  private int getCavePercentage() {
    return cavePercentage;
  }

  private List<Otyugh> getListOfMonsters() {
    return new ArrayList<>(listOfMonsters);
  }

  /**
   * Constructor for the fake dungeon where we create a deterministic dungeon everytime based on the
   * given row and column number.
   *
   * @param row    denotes the row number of the dungeon
   * @param column denotes the column number of the dungeon
   */
  public DungeonImpl(int row, int column) {
    if (row > 0 && column > 0) {
      this.interconnectivity = 0;
      this.wrapping = true;
      this.dungeon = createFakeDungeon(row, column);
      this.player = new PlayerImpl();
      this.cavePercentage = 100;
      this.currentLocation = getStart();

      listOfMonsters = new ArrayList<>();
      assignMonsters(2);

      dungeon[0][0].setSmellCounter(4);
      dungeon[0][1].setSmellCounter(1);
      dungeon[0][2].setSmellCounter(1);
      dungeon[0][3].setSmellCounter(2);
      dungeon[4][2].setSmellCounter(2);

      dungeon[0][column - 1].setTreasure(Treasure.RUBY, 0);
      dungeon[0][column - 1].setTreasure(Treasure.SAPPHIRE, 0);
      dungeon[0][column - 1].setTreasure(Treasure.DIAMOND, 0);
      dungeon[0][column - 1].setArrowInCave(1);

      dungeon[row - 1][0].setTreasure(Treasure.RUBY, 1);
      dungeon[row - 1][0].setTreasure(Treasure.SAPPHIRE, 1);
      dungeon[row - 1][0].setTreasure(Treasure.DIAMOND, 1);
      dungeon[row - 1][0].setArrowInCave(1);
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than 0. ");
    }
  }

  /**
   * Creates a fake dungeon where we create a deterministic dungeon everytime based on the given
   * row and column numbers.
   *
   * @param row    denotes the row number of the dungeon
   * @param column denotes the column number of the dungeon
   * @return the fake dungeon created here
   */
  public Cave[][] createFakeDungeon(int row, int column) {
    if (row >= 0 && column >= 0) {
      Cave[][] tempDungeon = new Cave[row][column];
      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          int left = 0;
          int right = 0;
          int top = 0;
          int bottom = 0;

          if (i % 2 == 0) {
            if (i == 0 && j == 0) {
              right = 1;
            } else if (j == column - 1 && i != row - 1) {
              bottom = 1;
              left = 1;
            } else if (j == 0) {
              top = 1;
              right = 1;
            } else if (j == column - 1 && i == row - 1) {
              left = 1;
            } else {
              right = 1;
              left = 1;
            }
          } else {
            if (j == 0 && i != row - 1) {
              bottom = 1;
              right = 1;
            } else if (j == column - 1) {
              left = 1;
              top = 1;
            } else if (j == 0 && i == row - 1) {
              right = 1;
            } else {
              right = 1;
              left = 1;
            }
          }
          if (i == 0 && j == 0) {
            left = 1;
            top = 1;
          } else if (i == 0 && j == column - 1) {
            right = 1;
          } else if (i == row - 1 && j == 0) {
            bottom = 1;
          }
          tempDungeon[i][j] = new Cave(left, right, top, bottom);
        }
      }

      start = new Vertex(0, 0);
      end = new Vertex(row - 1, column - 1);

      tempDungeon[row - 1][column - 1].setTreasure(Treasure.RUBY, 1);
      tempDungeon[row - 1][column - 1].setTreasure(Treasure.DIAMOND, 1);
      tempDungeon[row - 1][column - 1].setTreasure(Treasure.SAPPHIRE, 1);

      Graph g1 = new Graph(row, column, interconnectivity, wrapping);
      adjacencyList = g1.getAdjacencyList();
      Cave[][] tempDungeon1 = new Cave[row][column];

      for (int i = 0; i < row; i++) {
        System.arraycopy(tempDungeon[i], 0, tempDungeon1[i], 0, column);
      }
      return tempDungeon1;
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 5. ");
    }
  }

  @Override
  public Cave[][] createDungeon(int row, int column) {
    if (row >= 0 && column >= 0) {
      Cave[][] tempDungeon = new Cave[row][column];
      String[][] tempString = new String[row][column];
      Graph g1 = new Graph(row, column, interconnectivity, wrapping);
      adjacencyList = g1.getAdjacencyList();
      for (Edge e1 : adjacencyList) {
        Vertex v1 = e1.getSource();
        Vertex v2 = e1.getDestination();
        if (v1.getColumn() == 0 && v2.getColumn() == column - 1) {
          tempString[v1.getRow()][v1.getColumn()] += "left";
          tempString[v2.getRow()][v2.getColumn()] += "right";
        } else if (v1.getColumn() == column - 1 && v2.getColumn() == 0) {
          tempString[v2.getRow()][v2.getColumn()] += "left";
          tempString[v1.getRow()][v1.getColumn()] += "right";
        } else if (v1.getColumn() > v2.getColumn()) {
          tempString[v2.getRow()][v2.getColumn()] += "right";
          tempString[v1.getRow()][v1.getColumn()] += "left";
        } else if (v1.getColumn() < v2.getColumn()) {
          tempString[v2.getRow()][v2.getColumn()] += "left";
          tempString[v1.getRow()][v1.getColumn()] += "right";
        }
        if (v1.getRow() == 0 && v2.getRow() - 1 == row) {
          tempString[v2.getRow()][v2.getColumn()] += "bottom";
          tempString[v1.getRow()][v1.getColumn()] += "top";
        } else if (v1.getRow() == row - 1 && v2.getRow() == 0) {
          tempString[v2.getRow()][v2.getColumn()] += "top";
          tempString[v1.getRow()][v1.getColumn()] += "bottom";
        } else if (v1.getRow() > v2.getRow()) {
          tempString[v2.getRow()][v2.getColumn()] += "bottom";
          tempString[v1.getRow()][v1.getColumn()] += "top";
        } else if (v1.getRow() < v2.getRow()) {
          tempString[v2.getRow()][v2.getColumn()] += "top";
          tempString[v1.getRow()][v1.getColumn()] += "bottom";
        }
      }

      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          int left = 0;
          int right = 0;
          int top = 0;
          int bottom = 0;
          if (tempString[i][j].contains("left")) {
            left = 1;
          }
          if (tempString[i][j].contains("right")) {
            right = 1;
          }
          if (tempString[i][j].contains("top")) {
            top = 1;
          }
          if (tempString[i][j].contains("bottom")) {
            bottom = 1;
          }
          tempDungeon[i][j] = new Cave(left, right, top, bottom);
        }
      }

      int retry = 100;
      while (retry != 0) {
        try {
          getStartEnd(tempDungeon, adjacencyList);
          retry = 0;
        } catch (IllegalArgumentException iae) {
          retry--;
        }
      }
      Cave[][] tempDungeon1 = new Cave[row][column];
      for (int i = 0; i < row; i++) {
        System.arraycopy(tempDungeon[i], 0, tempDungeon1[i], 0, column);
      }
      return tempDungeon1;
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public String toString() {

    StringBuilder sb3 = new StringBuilder();
    sb3.append("\n");
    for (int j = 0; j < dungeon.length; j++) {
      if (dungeon[0][j].getTop() == 1) {
        sb3.append("  |");
      } else {
        sb3.append("   ");
      }
    }
    sb3.append("\n");
    int counter = 0;
    for (Cave[] caves : dungeon) {
      StringBuilder sb1 = new StringBuilder();
      StringBuilder sb2 = new StringBuilder();
      for (int j = 0; j < dungeon[0].length; j++) {
        if (j == 0 && caves[j].getLeft() == 1) {
          sb1.append("--");
        } else if (j == 0) {
          sb1.append("  ");
        }
        if (counter == currentLocation.getRow() && j == currentLocation.getColumn()) {
          sb1.append("P");
        } else if (dungeon[counter][j].getSmellCounter() == 100) {
          sb1.append("M");
        } else if (caves[j].isTunnel()) {
          sb1.append("T");
        } else {
          sb1.append("C");
        }
        if (caves[j].getRight() == 1) {
          sb1.append("--");
        } else {
          sb1.append("  ");
        }
        if (caves[j].getBottom() == 1) {
          sb2.append("  |");
        } else {
          sb2.append("   ");
        }
      }
      sb3.append(sb1).append("\n").append(sb2).append("\n");
      counter++;
    }
    return sb3.append("\n").toString();
  }

  @Override
  public void populateDungeon() {

    if (cavePercentage > 0) {
      List<Cave> caveList = getCaveList(dungeon);
      int numberOfCaves = (caveList.size() * cavePercentage) / 100;
      if (numberOfCaves == 0) {
        numberOfCaves = 1;
      }
      for (int i = 0; i < numberOfCaves; i++) {
        int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
        Cave c1 = caveList.get(randomNum);
        c1.setTreasure(Treasure.RUBY, 1);
      }
      for (int i = 0; i < numberOfCaves; i++) {
        int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
        Cave c1 = caveList.get(randomNum);
        c1.setTreasure(Treasure.SAPPHIRE, 1);
      }
      for (int i = 0; i < numberOfCaves; i++) {
        int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
        Cave c1 = caveList.get(randomNum);
        c1.setTreasure(Treasure.DIAMOND, 1);
      }

      numberOfCaves = ((dungeon.length * dungeon[0].length) * cavePercentage) / 100;
      if (numberOfCaves == 0) {
        numberOfCaves = 1;
      }
      for (int i = 0; i < numberOfCaves; i++) {
        int r = ThreadLocalRandom.current().nextInt(0, dungeon.length);
        int c = ThreadLocalRandom.current().nextInt(0, dungeon[0].length);
        int randomArrow = ThreadLocalRandom.current().nextInt(1, 4);
        if (dungeon[r][c].getArrowInCave() > 0) {
          i--;
        }
        dungeon[r][c].setArrowInCave(randomArrow);
      }
    }
  }

  @Override
  public void assignMonsters(int difficulty) {
    if (difficulty >= 0) {
      Otyugh m1 = new Otyugh(new Vertex(end.getRow(), end.getColumn()));
      listOfMonsters.add(m1);
      dungeon[end.getRow()][end.getColumn()].setSmellCounter(100);
      setSmellForMonster(end.getRow(), end.getColumn());

      if (difficulty >= 1) {
        for (int i = 0; i < difficulty; i++) {
          int row = ThreadLocalRandom.current().nextInt(0, dungeon.length);
          int column = ThreadLocalRandom.current().nextInt(0, dungeon[0].length);
          if (dungeon[row][column].isTunnel() || (row == getStart().getRow()
                  && column == getStart().getColumn())
                  || dungeon[row][column].getSmellCounter() == 100) {
            i--;
          } else {
            m1 = new Otyugh(new Vertex(row, column));
            listOfMonsters.add(m1);
            dungeon[row][column].setSmellCounter(100);
            setSmellForMonster(row, column);
          }
        }
      }
    } else {
      throw new IllegalArgumentException("Difficulty cannot be negative. ");
    }
  }

  @Override
  public void setSmellForMonster(int r, int c) {
    if (r >= 0 && c >= 0) {
      for (int i = 0; i < dungeon.length; i++) {
        for (int j = 0; j < dungeon[0].length; j++) {
          if (dungeon[i][j].getSmellCounter() != 100) {
            if (getShortestPath(new Vertex(r, c), new Vertex(i, j)) == 1) {
              dungeon[i][j].increaseSmellCounter();
              dungeon[i][j].increaseSmellCounter();
            } else if (getShortestPath(new Vertex(r, c), new Vertex(i, j)) == 2) {
              dungeon[i][j].increaseSmellCounter();
            }
          }
        }
      }
    } else {
      throw new IllegalArgumentException("Illegal values for row and column have been passed. ");
    }
  }

  @Override
  public void setSmellForDeadMonster(int r, int c) {
    if (r >= 0 && c >= 0) {
      dungeon[r][c].setSmellCounter(0);
      for (int i = 0; i < dungeon.length; i++) {
        for (int j = 0; j < dungeon[0].length; j++) {
          if (dungeon[i][j].getSmellCounter() != 100) {
            if (getShortestPath(new Vertex(r, c), new Vertex(i, j)) == 1) {
              dungeon[i][j].decreaseSmellCounter();
              dungeon[i][j].decreaseSmellCounter();
            } else if (getShortestPath(new Vertex(r, c), new Vertex(i, j)) == 2) {
              dungeon[i][j].decreaseSmellCounter();
            }
          }
        }
      }
    } else {
      throw new IllegalArgumentException("Illegal values for row and column have been passed. ");
    }
  }

  @Override
  public List<Cave> getCaveList(Cave[][] dungeon) {
    if (dungeon != null) {
      List<Cave> caveList = new ArrayList<>();
      for (Cave[] caves : dungeon) {
        for (int j = 0; j < dungeon[0].length; j++) {
          if (!caves[j].isTunnel()) {
            caveList.add(caves[j]);
          }
        }
      }
      return new ArrayList<>(caveList);
    } else {
      throw new IllegalArgumentException("Null dungeon has been passed to get caves. ");
    }
  }

  @Override
  public Vertex getStart() {
    return new Vertex(start.getRow(), start.getColumn());
  }

  @Override
  public Vertex getEnd() {
    return new Vertex(end.getRow(), end.getColumn());
  }

  @Override
  public String getPlayerLocation() {
    StringBuilder sb = new StringBuilder();
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()].isTunnel()) {
      sb.append("You are currently in a tunnel. Doors lead to the ");
    } else {
      sb.append("You are currently in a cave. Doors lead to the ");
    }
    int count = 0;
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()].getTop() == 1) {
      sb.append("north");
      count++;
    }
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()].getBottom() == 1) {
      if (count > 0) {
        sb.append(", ");
        count--;
      }
      sb.append("south");
      count++;
    }
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()].getLeft() == 1) {
      if (count > 0) {
        sb.append(", ");
        count--;
      }
      sb.append("west");
      count++;
    }
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()].getRight() == 1) {
      if (count > 0) {
        sb.append(", ");
      }
      sb.append("east");
    }
    sb.append(". ");
    if (!dungeon[currentLocation.getRow()][currentLocation.getColumn()].toString().isEmpty()) {
      sb.append("\n");
      sb.append(dungeon[currentLocation.getRow()][currentLocation.getColumn()].toString());
    }
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()].getSmellCounter() == 1) {
      sb.append("\nSomething smells pungent nearby. ");
    } else if (dungeon[currentLocation.getRow()][currentLocation.getColumn()].getSmellCounter()
            >= 2) {
      sb.append("\nSomething smells terribly close by. ");
    }
    return sb.toString();
  }

  @Override
  public String move(String nextMove) {
    if (nextMove != null) {
      int r = currentLocation.getRow();
      int c = currentLocation.getColumn();
      switch (nextMove.toLowerCase().trim()) {
        case "s":
        case "south":
          if (dungeon[r][c].getBottom() != 0) {
            if (r != dungeon.length - 1) {
              currentLocation = new Vertex(r + 1, c);
            } else {
              currentLocation = new Vertex(0, c);
            }
          } else {
            throw new IllegalArgumentException("No south opening available. ");
          }
          break;
        case "n":
        case "north":
          if (dungeon[r][c].getTop() != 0) {
            if (r != 0) {
              currentLocation = new Vertex(r - 1, c);
            } else {
              currentLocation = new Vertex(dungeon.length - 1, c);
            }
          } else {
            throw new IllegalArgumentException("No north opening available. ");
          }
          break;
        case "e":
        case "east":
          if (dungeon[r][c].getRight() != 0) {
            if (c != dungeon[0].length - 1) {
              currentLocation = new Vertex(r, c + 1);
            } else {
              currentLocation = new Vertex(r, 0);
            }
          } else {
            throw new IllegalArgumentException("No east opening available. ");
          }
          break;
        case "w":
        case "west":
          if (dungeon[r][c].getLeft() != 0) {
            if (c != 0) {
              currentLocation = new Vertex(r, c - 1);
            } else {
              currentLocation = new Vertex(r, dungeon[0].length - 1);
            }
          } else {
            throw new IllegalArgumentException("No west opening available. ");
          }
          break;
        default:
          throw new IllegalArgumentException("Invalid move. Try again. ");
      }
      r = currentLocation.getRow();
      c = currentLocation.getColumn();
      dungeon[r][c].setVisitedFlag();
      for (Otyugh m1 : listOfMonsters) {
        int r1 = m1.getMonsterLocation().getRow();
        int c1 = m1.getMonsterLocation().getColumn();

        if ((r == r1 && c == c1) && m1.getMonsterHealth() == 2) {
          return "The monster has eaten you. Better luck next time! ";
        } else if ((r == r1 && c == c1) && m1.getMonsterHealth() == 1) {
          int diceRoll = ThreadLocalRandom.current().nextInt(0, 2);
          if (diceRoll == 1) {
            return "The monster has eaten you. Better luck next time! ";
          }
        }
      }
      return "";
    } else {
      throw new IllegalArgumentException("Null move cannot be passed to the move method. ");
    }
  }

  @Override
  public void pickupTreasure() {
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()] != null) {
      int r = currentLocation.getRow();
      int c = currentLocation.getColumn();
      if (dungeon[r][c].getSapphireValue() != 0) {
        player.addTreasure(Treasure.SAPPHIRE, dungeon[r][c].getSapphireValue());
        dungeon[r][c].setTreasure(Treasure.SAPPHIRE, 0);
      }
      if (dungeon[r][c].getRubyValue() != 0) {
        player.addTreasure(Treasure.RUBY, dungeon[r][c].getRubyValue());
        dungeon[r][c].setTreasure(Treasure.RUBY, 0);
      }
      if (dungeon[r][c].getDiamondValue() != 0) {
        player.addTreasure(Treasure.DIAMOND, dungeon[r][c].getDiamondValue());
        dungeon[r][c].setTreasure(Treasure.DIAMOND, 0);
      }
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public void pickUpArrows() {
    if (dungeon[currentLocation.getRow()][currentLocation.getColumn()] != null) {
      int r = currentLocation.getRow();
      int c = currentLocation.getColumn();
      if (dungeon[r][c].getArrowInCave() != 0) {
        player.pickupArrows(dungeon[r][c].getArrowInCave());
        dungeon[r][c].setArrowInCave(0);
      }
    }
  }

  @Override
  public String shootArrow(String direction, int distance) {
    if (direction != null && distance >= 1 && distance <= 5) {
      StringBuilder sb = new StringBuilder();
      String s = player.shootArrow();
      if (!s.isBlank()) {
        sb.append(s);
      }
      direction = direction.toLowerCase().trim();
      int currentRow = currentLocation.getRow();
      int currentColumn = currentLocation.getColumn();
      while (distance > 0) {
        switch (direction) {
          case "n":
          case "north":
            if (dungeon[currentRow][currentColumn].getTop() == 1) {
              if (currentRow == 0 && wrapping) {
                currentRow = dungeon.length - 1;
              } else {
                currentRow--;
              }
              if (!dungeon[currentRow][currentColumn].isTunnel()) {
                distance--;
              } else {
                if (dungeon[currentRow][currentColumn].getRight() == 1) {
                  direction = "east";
                } else if (dungeon[currentRow][currentColumn].getLeft() == 1) {
                  direction = "west";
                }
              }
            } else {
              distance = 0;
              currentRow = currentLocation.getRow();
              currentColumn = currentLocation.getColumn();
            }
            break;
          case "s":
          case "south":
            if (dungeon[currentRow][currentColumn].getBottom() == 1) {
              if (currentRow == dungeon.length - 1 && wrapping) {
                currentRow = 0;
              } else {
                currentRow++;
              }
              if (!dungeon[currentRow][currentColumn].isTunnel()) {
                distance--;
              } else {
                if (dungeon[currentRow][currentColumn].getRight() == 1) {
                  direction = "east";
                } else if (dungeon[currentRow][currentColumn].getLeft() == 1) {
                  direction = "west";
                }
              }
            } else {
              distance = 0;
              currentRow = currentLocation.getRow();
              currentColumn = currentLocation.getColumn();
            }
            break;
          case "e":
          case "east":
            if (dungeon[currentRow][currentColumn].getRight() == 1) {
              if (currentColumn == dungeon[0].length - 1 && wrapping) {
                currentColumn = 0;
              } else {
                currentColumn++;
              }
              if (!dungeon[currentRow][currentColumn].isTunnel()) {
                distance--;
              } else {
                if (dungeon[currentRow][currentColumn].getTop() == 1) {
                  direction = "north";
                } else if (dungeon[currentRow][currentColumn].getBottom() == 1) {
                  direction = "south";
                }
              }
            } else {
              distance = 0;
              currentRow = currentLocation.getRow();
              currentColumn = currentLocation.getColumn();
            }
            break;
          case "w":
          case "west":
            if (dungeon[currentRow][currentColumn].getLeft() == 1) {
              if (currentColumn == 0 && wrapping) {
                currentColumn = dungeon[0].length - 1;
              } else {
                currentColumn--;
              }
              if (!dungeon[currentRow][currentColumn].isTunnel()) {
                distance--;
              } else {
                if (dungeon[currentRow][currentColumn].getTop() == 1) {
                  direction = "north";
                } else if (dungeon[currentRow][currentColumn].getBottom() == 1) {
                  direction = "south";
                }
              }
            } else {
              distance = 0;
              currentRow = currentLocation.getRow();
              currentColumn = currentLocation.getColumn();
            }
            break;
          default:
            throw new IllegalArgumentException("Invalid move. Try again. ");
        }
      }

      if (!(currentRow == currentLocation.getRow() && currentColumn == currentLocation.getColumn())
              && dungeon[currentRow][currentColumn].getSmellCounter() == 100) {
        for (Otyugh l1 : listOfMonsters) {
          if (l1.getMonsterLocation().getRow() == currentRow
                  && l1.getMonsterLocation().getColumn() == currentColumn) {
            l1.damageMonster();
            sb.append("You hear a monster howling in pain. \n");
            if (l1.getMonsterHealth() == 0) {
              setSmellForDeadMonster(currentRow, currentColumn);
              listOfMonsters.remove(l1);
              return "You hear a dying monster's last cry. \n";
            }
            break;
          }
        }
      }
      return sb.toString();
    } else {
      throw new IllegalArgumentException("Illegal arguments have been passed to the shoot method.");
    }
  }

  @Override
  public boolean isGameOver() {
    return currentLocation.getRow() == end.getRow()
            && currentLocation.getColumn() == end.getColumn();
  }

  @Override
  public void getStartEnd(Cave[][] tempDungeon, List<Edge> adjacencyList) {
    if (tempDungeon != null && adjacencyList != null) {
      List<Cave> caveList = getCaveList(tempDungeon);
      int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
      Cave c1 = caveList.get(randomNum);
      int r = 0;
      int c = 0;
      for (int i = 0; i < tempDungeon.length; i++) {
        for (int j = 0; j < tempDungeon[0].length; j++) {
          if (c1 == tempDungeon[i][j]) {
            r = i;
            c = j;
          }
        }
      }

      LinkedHashMap<Vertex, Integer> hm1 = new LinkedHashMap<>();
      List<Vertex> l1 = new ArrayList<>();

      Vertex v1 = new Vertex(r, c);

      helperStartEnd(adjacencyList, hm1, l1, v1);

      while (l1.size() != 0) {
        for (Edge e1 : adjacencyList) {
          v1 = getVertex(v1, hm1, l1, e1);
        }

        l1.remove(v1);
        if (!l1.isEmpty()) {
          v1 = l1.get(0);
        }
      }
      ArrayList<Vertex> listOfVertex = new ArrayList<>();
      for (Vertex v : hm1.keySet()) {
        if (hm1.get(v) == 0) {
          v1 = v;
        }
        if (hm1.get(v) >= 5) {
          listOfVertex.add(v);
        }
      }

      Vertex v2;
      randomNum = ThreadLocalRandom.current().nextInt(0, listOfVertex.size());
      v2 = listOfVertex.get(randomNum);
      while (tempDungeon[v2.getRow()][v2.getColumn()].isTunnel()) {
        listOfVertex.remove(v2);
        randomNum = ThreadLocalRandom.current().nextInt(0, listOfVertex.size());
        v2 = listOfVertex.get(randomNum);
      }
      start = new Vertex(v1.getRow(), v1.getColumn());
      end = new Vertex(v2.getRow(), v2.getColumn());
    } else {
      throw new IllegalArgumentException("Null arguments have been passed. ");
    }
  }

  //helper method to get start and end
  private void helperStartEnd(List<Edge> adjacencyList, LinkedHashMap<Vertex, Integer> hm1,
                              List<Vertex> l1, Vertex v1) {
    if (adjacencyList != null && hm1 != null && l1 != null && v1 != null) {
      for (Edge e1 : adjacencyList) {
        if (v1.getRow() == e1.getSource().getRow()
                && v1.getColumn() == e1.getSource().getColumn()) {
          hm1.put(e1.getSource(), 0);
          l1.add(e1.getSource());
          break;
        } else if (v1.getRow() == e1.getDestination().getRow()
                && v1.getColumn() == e1.getDestination().getColumn()) {
          hm1.put(e1.getDestination(), 0);
          l1.add(e1.getDestination());
          break;
        }
      }
    } else {
      throw new IllegalArgumentException("Null arguments have been passed to the helper method. ");
    }
  }

  //helper method to get start and end
  private Vertex getVertex(Vertex v1, LinkedHashMap<Vertex, Integer> hm1,
                           List<Vertex> l1, Edge e1) {
    if (v1 != null && hm1 != null && l1 != null && e1 != null) {
      Vertex v2;
      if (v1.getRow() == e1.getSource().getRow() && v1.getColumn() == e1.getSource().getColumn()) {
        v1 = e1.getSource();
        v2 = e1.getDestination();
        if (!hm1.containsKey(v2)) {
          hm1.put(v2, hm1.get(v1) + 1);
          l1.add(v2);
        }
      } else if (v1.getRow() == e1.getDestination().getRow()
              && v1.getColumn() == e1.getDestination().getColumn()) {
        v1 = e1.getDestination();
        v2 = e1.getSource();
        if (!hm1.containsKey(v2)) {
          hm1.put(v2, hm1.get(v1) + 1);
          l1.add(v2);
        }
      }
      return v1;
    } else {
      throw new IllegalArgumentException("Null arguments have been passed to the helper method. ");
    }
  }

  @Override
  public String getPlayerDetails() {
    return player.toString();
  }

  @Override
  public String getCaveDetails(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].toString();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public String getExitsText(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].getExitsText();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public List<Edge> getAdjacencyList() {
    return new ArrayList<>(adjacencyList);
  }

  @Override
  public int countOfCavesContainingTreasure() {
    int count = 0;
    for (Cave[] caves : dungeon) {
      for (int j = 0; j < dungeon[0].length; j++) {
        if (!caves[j].isTunnel() && (caves[j].getRubyValue() != 0
                || caves[j].getSapphireValue() != 0 || caves[j].getDiamondValue() != 0)) {
          count++;
        }
      }
    }
    return count;
  }

  @Override
  public int getShortestPath(Vertex v1, Vertex v2) {
    if (v1 != null && v2 != null) {
      Vertex end = new Vertex(v2.getRow(), v2.getColumn());

      LinkedHashMap<Vertex, Integer> hm1 = new LinkedHashMap<>();
      List<Vertex> l1 = new ArrayList<>();

      helperStartEnd(adjacencyList, hm1, l1, v1);

      while (l1.size() != 0) {
        for (Edge e1 : adjacencyList) {
          v1 = getVertex(v1, hm1, l1, e1);
          if (v1.getRow() == end.getRow() && v1.getColumn() == end.getColumn()) {
            end = v1;
          }
        }

        l1.remove(v1);
        if (!l1.isEmpty()) {
          v1 = l1.get(0);
        }
      }
      return hm1.get(end);
    } else {
      throw new IllegalArgumentException("Null arguments have been passed to the shortest path. ");
    }
  }

  @Override
  public int getSmellCounter(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].getSmellCounter();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public int countOfCavesContainingArrow() {
    int counter = 0;
    for (Cave[] caves : dungeon) {
      for (int j = 0; j < dungeon.length; j++) {
        if (caves[j].getArrowInCave() > 0) {
          counter++;
        }
      }
    }
    return counter;
  }

  @Override
  public boolean isVisited(int row, int column) {
    if (row >= 0 && column >= 0) {
      return dungeon[row][column].isVisitedFlag();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public int getPlayerRow() {
    return currentLocation.getRow();
  }

  @Override
  public int getPlayerColumn() {
    return currentLocation.getColumn();
  }

  @Override
  public int getRubyCount(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].getRubyValue();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public int getSapphireCount(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].getSapphireValue();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public int getDiamondCount(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].getDiamondValue();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public int getArrowCount(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].getArrowInCave();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public boolean isTunnel(int row, int column) {
    if (row >= 0 && column >= 0) {
      return dungeon[row][column].isTunnel();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public int getPlayerRubyCount() {
    return player.getRubyValue();
  }

  @Override
  public int getPlayerSapphireCount() {
    return player.getSapphireValue();
  }

  @Override
  public int getPlayerDiamondCount() {
    return player.getDiamondValue();
  }

  @Override
  public int getPlayerArrowCount() {
    return player.getArrowValue();
  }

  @Override
  public int getRowSize() {
    return dungeon.length;
  }

  @Override
  public int getColumnSize() {
    return dungeon[0].length;
  }
}