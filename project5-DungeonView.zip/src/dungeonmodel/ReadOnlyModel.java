package dungeonmodel;

/**
 * A readonly model which exposes only the functions required by the view to validate and set the
 * game state as well as show the dungeon to the player. No modification functionality is present
 * in a read only model.
 */
public interface ReadOnlyModel {

  /**
   * Checks if the player has reached the end node in the dungeon successfully without dying.
   *
   * @return true if the game is over
   */
  boolean isGameOver();

  /**
   * Gets the current row number of the player.
   *
   * @return the current row of the player
   */
  int getPlayerRow();

  /**
   * Gets the current column number of the player.
   *
   * @return the current column of the player
   */
  int getPlayerColumn();

  /**
   * Gets the count of ruby in the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of ruby in location
   */
  int getRubyCount(int row, int column);

  /**
   * Gets the count of sapphire in the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of sapphire in location
   */
  int getSapphireCount(int row, int column);

  /**
   * Gets the count of diamond in the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of diamond in location
   */
  int getDiamondCount(int row, int column);

  /**
   * Gets the count of arrow at the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of arrow at location
   */
  int getArrowCount(int row, int column);

  /**
   * Checks if the given location is a tunnel or not.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return if the location is a tunnel or not
   */
  boolean isTunnel(int row, int column);

  /**
   * Gets the count of rubies with the player.
   *
   * @return the ruby count
   */
  int getPlayerRubyCount();

  /**
   * Gets the count of sapphire with the player.
   *
   * @return the sapphire count
   */
  int getPlayerSapphireCount();

  /**
   * Gets the count of diamond with the player.
   *
   * @return the diamond count
   */
  int getPlayerDiamondCount();

  /**
   * Gets the count of arrow with the player.
   *
   * @return the arrow count
   */
  int getPlayerArrowCount();

  /**
   * Gets the row size of the dungeon.
   *
   * @return the row size
   */
  int getRowSize();

  /**
   * Gets the column size of the dungeon.
   *
   * @return the column size
   */
  int getColumnSize();

  /**
   * Checks if the location has been visited or not.
   *
   * @param row    is the row number of the location
   * @param column is the column number of the location
   * @return if the location has been visited
   */
  boolean isVisited(int row, int column);

  /**
   * Gets the exits in text format.
   *
   * @param row    is the row of the location
   * @param column is the column of the location
   * @return the exits in text format
   */
  String getExitsText(int row, int column);

  /**
   * Gets the smell counter of the specific cave. If it is 1, it means that there is only 1 monster
   * 2 distance away from the cave. If it is 2 or greater, it means that there is at least 1 monster
   * 1 distance away or at least 2 monsters 2 distance away. If it is 100, it means that this cave
   * houses a monster.
   *
   * @param row    denotes the row number of the cave
   * @param column denotes the column number of the cave
   * @return the smell counter of the cave
   */
  int getSmellCounter(int row, int column);
}
