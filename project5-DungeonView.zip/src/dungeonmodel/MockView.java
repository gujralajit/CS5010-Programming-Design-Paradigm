package dungeonmodel;

import java.io.IOException;

/**
 * A mock view to test the features of the view when tested in isolation with the controller.
 */
public class MockView implements DungeonView {

  private final Appendable log;

  /**
   * A constructor for the mock view  that initializes the log.
   *
   * @param log denotes the log appendable
   */
  public MockView(Appendable log) {
    this.log = log;
  }

  @Override
  public void createGamePanel(ReadOnlyModel model) {
    try {
      log.append("Read only model appended to the view. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public String getAttributes() {
    try {
      log.append("Inside the get attribute function. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return null;
  }

  @Override
  public void setModel(ReadOnlyModel model) {
    try {
      log.append("Read only model has been set in the view. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public void setPlayerInfoPanel() {
    try {
      log.append("Setting the player information panel to the view. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public void addClickListener(GraphicController listener) {
    try {
      log.append("Added click listener to the view. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public void addKeyListener(GraphicController listener) {
    try {
      log.append("Added key listener to the view. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public void refresh() {
    try {
      log.append("Inside the refresh method for the view. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public void makeVisible() {
    try {
      log.append("Inside the make visible method for the view. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }

  @Override
  public void setFeedback(String givenFeedback) {
    try {
      log.append("Setting the feedback for the view : ").append(givenFeedback);
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
  }
}
