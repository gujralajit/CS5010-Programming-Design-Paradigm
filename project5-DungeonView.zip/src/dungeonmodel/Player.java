package dungeonmodel;

/**
 * Creates the Player that enters the dungeon. The player enters at the start node and exits at the
 * end node. The player has the ability to collect and hold treasure that is present in the cave
 * that the player moves into.
 */
public interface Player {

  /**
   * It adds the treasure to the player based on the treasure present in the cave.
   *
   * @param treasure denotes the type of treasure present in the cave
   * @param value    denotes the value of the treasure being assigned to the player
   */
  void addTreasure(Treasure treasure, int value);

  /**
   * Picks up all the arrows from the dungeon and assigns it to their quiver.
   *
   * @param val denotes the number of arrows to be added
   */
  void pickupArrows(int val);

  /**
   * The player shoots an arrow and removes it from the player's quiver.
   *
   * @return if the player has no arrows left
   */
  String shootArrow();

  /**
   * Gets the count of rubies with the player.
   *
   * @return the count of rubies
   */
  int getRubyValue();

  /**
   * Gets the count of diamonds with the player.
   *
   * @return the count of diamonds
   */
  int getDiamondValue();

  /**
   * Gets the count of sapphires with the player.
   *
   * @return the count of sapphires
   */
  int getSapphireValue();

  /**
   * Gets the count of arrows with the player.
   *
   * @return the count of arrows
   */
  int getArrowValue();
}