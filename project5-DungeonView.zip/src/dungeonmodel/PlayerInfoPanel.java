package dungeonmodel;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * This is the player information panel of our graphic dungeon. The info panel showcases the
 * various treasures and arrows collected by the player at the given time.
 */
public class PlayerInfoPanel extends JPanel {

  private final ReadOnlyModel model;
  private final JLabel[] labelSet;
  private String feedbackText;

  /**
   * Constructor for the player info panel which assigns a readonly model to the panel to get the
   * game state.
   *
   * @param m denotes the read only model
   */
  public PlayerInfoPanel(ReadOnlyModel m) {
    if (m != null) {
      this.model = m;
      feedbackText = "";
      labelSet = new JLabel[5];

      this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

      BufferedImage b2;
      try {
        b2 = ImageIO.read(
                Objects.requireNonNull(getClass().getResourceAsStream("/diamond.png")));
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for image.");
      }
      labelSet[0] = new JLabel(new ImageIcon(b2));
      labelSet[0].setText("" + model.getPlayerDiamondCount());
      labelSet[0].setSize(100, 100);
      this.add(labelSet[0]);

      try {
        b2 = ImageIO.read(
                Objects.requireNonNull(getClass().getResourceAsStream("/ruby.png")));
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for image.");
      }
      labelSet[1] = new JLabel(new ImageIcon(b2));
      labelSet[1].setText("" + model.getPlayerRubyCount());
      this.add(labelSet[1]);

      try {
        b2 = ImageIO.read(
                Objects.requireNonNull(getClass().getResourceAsStream("/sapphire.png")));
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for image.");
      }
      labelSet[2] = new JLabel(new ImageIcon(b2));
      labelSet[2].setText("" + model.getPlayerSapphireCount());
      this.add(labelSet[2]);

      try {
        b2 = ImageIO.read(
                Objects.requireNonNull(getClass().getResourceAsStream("/arrow-black.png")));
      } catch (IOException e) {
        throw new IllegalStateException("Illegal arguments have been passed for image.");
      }
      labelSet[3] = new JLabel(new ImageIcon(b2));
      labelSet[3].setText("" + model.getPlayerArrowCount());
      this.add(labelSet[3]);

      labelSet[4] = new JLabel("");
      this.add(labelSet[4]);

      this.setVisible(true);
    } else {
      throw new IllegalArgumentException("Null model has been passed to the player panel. ");
    }
  }

  /**
   * This function sets the feedback text received from the model to display to the user in case
   * it smells something or if they have won or have died.
   *
   * @param feedback is the feedback text to be shown to the player.
   */
  public void setFeedback(String feedback) {
    if (feedback != null) {
      feedbackText = feedback;
    } else {
      throw new IllegalArgumentException("Null feedback has been passed the player panel. ");
    }
  }

  @Override
  protected void paintComponent(Graphics g) {
    if (g != null) {
      super.paintComponent(g);
      labelSet[0].setText("" + model.getPlayerDiamondCount());
      labelSet[1].setText("" + model.getPlayerRubyCount());
      labelSet[2].setText("" + model.getPlayerSapphireCount());
      labelSet[3].setText("" + model.getPlayerArrowCount());
      if (model.isGameOver()) {
        feedbackText = "Congratulations on winning the game!";
      }
      labelSet[4].setText(feedbackText);
    } else {
      throw new IllegalArgumentException("Null graphics have been passed to the paint component. ");
    }
  }
}