package dungeonmodel;

/**
 * A model for creating and accessing the dungeon. The model has the ability to create a dungeon,
 * start the game, move player in the dungeon, and check if the game is over. We can also get the
 * player and cave details at a current location.
 */
public interface Model extends ReadOnlyModel {

  /**
   * Moves the player to the specified position if the move is valid.
   *
   * @param nextMove is the next move for the player from north, south, east and west
   * @return if the player has been eaten or not
   */
  String move(String nextMove);

  /**
   * Picks up the treasure at the current location.
   */
  void pickupTreasure();

  /**
   * Picks up the arrows at the current location.
   */
  void pickupArrows();

  /**
   * Shoots an arrow in the given direction with the specified distance.
   *
   * @param direction towards which the arrow is to be shot at
   * @param distance  at which the arrow is to be shot at
   * @return the row and column at which the arrow lands
   */
  String shootArrow(String direction, int distance);

  /**
   * Gets the current location of the user denoted by the row and column number of its position.
   *
   * @return the current location of the user
   */
  String getCurrentLocation();

  /**
   * Checks if the player has reached the end node in the dungeon successfully without dying.
   *
   * @return true if the game is over
   */
  boolean isGameOver();

  /**
   * Gets the player details returning the amount of treasures currently held by the player.
   *
   * @return the string containing player details.
   */
  String getPlayerDetails();

  /**
   * Gets the cave details returning the amount of treasures currently present in the cave.
   *
   * @return the string containing cave details.
   */
  String getCaveDetails(int row, int column);

  /**
   * Gets the start node and returns the row and column number of start.
   *
   * @return the string containing start row and column
   */
  String getStart();

  /**
   * Gets the start node and returns the row and column number of start.
   *
   * @return the string containing end row and column
   */
  String getEnd();

  /**
   * Gets the smell counter of the specific cave. If it is 1, it means that there is only 1 monster
   * 2 distance away from the cave. If it is 2 or greater, it means that there is at least 1 monster
   * 1 distance away or at least 2 monsters 2 distance away. If it is 100, it means that this cave
   * houses a monster.
   *
   * @param row    denotes the row number of the cave
   * @param column denotes the column number of the cave
   * @return the smell counter of the cave
   */
  int getSmellCounter(int row, int column);

  /**
   * Counts the number of caves that contain arrows in the dungeon.
   *
   * @return the count
   */
  int countOfCavesContainingArrow();

  /**
   * Checks if the location has been visited or not.
   *
   * @param row    is the row number of the location
   * @param column is the column number of the location
   * @return if the location has been visited
   */
  boolean isVisited(int row, int column);

  /**
   * Gets the exits in text format.
   *
   * @param row    is the row of the location
   * @param column is the column of the location
   * @return the exits in text format
   */
  String getExitsText(int row, int column);

  /**
   * Gets the current row number of the player.
   *
   * @return the current row of the player
   */
  int getPlayerRow();

  /**
   * Gets the current column number of the player.
   *
   * @return the current column of the player
   */
  int getPlayerColumn();

  /**
   * Gets the count of ruby in the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of ruby in location
   */
  int getRubyCount(int row, int column);

  /**
   * Gets the count of sapphire in the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of sapphire in location
   */
  int getSapphireCount(int row, int column);

  /**
   * Gets the count of diamond in the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of diamond in location
   */
  int getDiamondCount(int row, int column);

  /**
   * Gets the count of arrow at the location.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return the count of arrow at location
   */
  int getArrowCount(int row, int column);

  /**
   * Checks if the given location is a tunnel or not.
   *
   * @param row    denotes the row number of the location
   * @param column denotes the column number of the location
   * @return if the location is a tunnel or not
   */
  boolean isTunnel(int row, int column);

  /**
   * Gets the count of rubies with the player.
   *
   * @return the ruby count
   */
  int getPlayerRubyCount();

  /**
   * Gets the count of sapphire with the player.
   *
   * @return the sapphire count
   */
  int getPlayerSapphireCount();

  /**
   * Gets the count of diamond with the player.
   *
   * @return the diamond count
   */
  int getPlayerDiamondCount();

  /**
   * Gets the count of arrow with the player.
   *
   * @return the arrow count
   */
  int getPlayerArrowCount();

  /**
   * Gets the row size of the dungeon.
   *
   * @return the row size
   */
  int getRowSize();

  /**
   * Gets the column size of the dungeon.
   *
   * @return the column size
   */
  int getColumnSize();
}
