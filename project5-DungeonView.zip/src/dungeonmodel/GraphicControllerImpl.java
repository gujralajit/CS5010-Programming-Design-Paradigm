package dungeonmodel;

/**
 * This is the implementation of the graphic controller of our dungeon game. This takes in the
 * attributes from the view and creates a model based on the parameters entered by the user and
 * acts as a mediator between the game and the user.
 */
public class GraphicControllerImpl implements GraphicController {

  private Model model;
  private Model copyModel;
  private DungeonView view;
  private boolean flag;

  /**
   * This is the constructor for the graphic controller which creates a view here.
   */
  public GraphicControllerImpl() {
    view = new DungeonViewImpl(this);
    flag = false;
  }

  @Override
  public void getAttributes() {
    String[] s = view.getAttributes().split(",");

    int row;
    int column;
    int interconnectivity;
    boolean wrapping;
    int cavePercentage;
    int difficulty;

    try {
      row = Integer.parseInt(s[0]);
    } catch (NullPointerException | NumberFormatException | ArrayIndexOutOfBoundsException npe) {
      row = 5;
    }
    try {
      column = Integer.parseInt(s[1]);
    } catch (NullPointerException | NumberFormatException | ArrayIndexOutOfBoundsException npe) {
      column = 5;
    }
    try {
      interconnectivity = Integer.parseInt(s[2]);
    } catch (NullPointerException | NumberFormatException | ArrayIndexOutOfBoundsException npe) {
      interconnectivity = 5;
    }
    try {
      wrapping = Boolean.parseBoolean(s[3]);
    } catch (NullPointerException npe) {
      wrapping = false;
    }
    try {
      cavePercentage = Integer.parseInt(s[4]);
    } catch (NullPointerException | NumberFormatException | ArrayIndexOutOfBoundsException npe) {
      cavePercentage = 50;
    }
    try {
      difficulty = Integer.parseInt(s[5]);
    } catch (NullPointerException | NumberFormatException | ArrayIndexOutOfBoundsException npe) {
      difficulty = 0;
    }
    try {
      model = new ModelImpl(row, column, interconnectivity, wrapping, cavePercentage, difficulty);
    } catch (IllegalArgumentException e) {
      model = new ModelImpl(5, 5, 5, false, 50, 0);
    }
  }

  @Override
  public void playGame(int flag) {
    if (flag == 0) {
      newGame();
    } else {
      restart();
    }

    try {
      view.setModel(model);
      view.createGamePanel(model);
      view.setPlayerInfoPanel();
      view.refresh();
      view.makeVisible();
      view.addClickListener(this);
      view.addKeyListener(this);
    } catch (IllegalArgumentException e) {
      view.setFeedback(e.getMessage());
    }
  }

  private void newGame() {
    view = new DungeonViewImpl(this);
    getAttributes();
    copyModel = new ModelImpl((ModelImpl) model);
  }

  private void restart() {
    view = new DungeonViewImpl(this);
    model = copyModel;
    copyModel = new ModelImpl((ModelImpl) model);
  }

  @Override
  public void handleKeyPress(int code, int code2, int dist) {
    if (code >= 0 && code2 >= 0 && dist >= 0) {
      try {
        if (!model.isGameOver() && !flag) {
          String feedback = "";
          if (code == 37) {
            feedback = model.move("west");
          } else if (code == 38) {
            feedback = model.move("north");
          } else if (code == 39) {
            feedback = model.move("east");
          } else if (code == 40) {
            feedback = model.move("south");
          } else if (code == 65) {
            model.pickupArrows();
          } else if (code == 84) {
            model.pickupTreasure();
          } else if (code == 83) {
            if (code2 == 37) {
              feedback = model.shootArrow("west", dist);
            } else if (code2 == 38) {
              feedback = model.shootArrow("north", dist);
            } else if (code2 == 39) {
              feedback = model.shootArrow("east", dist);
            } else if (code2 == 40) {
              feedback = model.shootArrow("south", dist);
            }
          }
          view.setFeedback(feedback);
          view.refresh();
          if (feedback.contains("luck next time")) {
            flag = true;
          }
        }
      } catch (IllegalArgumentException e) {
        view.setFeedback(e.getMessage());
        view.refresh();
      }
    } else {
      throw new IllegalArgumentException("Invalid keycode or distance has been passed. ");
    }
  }

  @Override
  public void handleCellClick(String direction) {
    if (direction != null && !direction.isBlank()) {
      if (!model.isGameOver() && !flag) {
        String feedback = "";
        try {
          feedback = model.move(direction);
        } catch (IllegalArgumentException e) {
          view.setFeedback(e.getMessage());
          view.refresh();
        }
        view.setFeedback(feedback);
        view.refresh();
        if (feedback.contains("luck next time")) {
          flag = true;
        }
      }
    } else {
      throw new IllegalArgumentException("Direction cannot be null or empty. ");
    }
  }
}