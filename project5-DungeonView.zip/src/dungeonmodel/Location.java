package dungeonmodel;

/**
 * The location interface is used to denote the caves and tunnels in the dungeon. The location has
 * the ability to store treasure. The location is able to have upto 4 exits, on right, left, top
 * and bottom. We characterize the location as a tunnel if it only has 2 exits.
 */
public interface Location {

  /**
   * Calculates the number of exits in the location.
   *
   * @return the exits in location
   */
  int getExits();

  /**
   * Returns if the location is a tunnel or not.
   *
   * @return true if it has exactly 2 exits
   */
  Boolean isTunnel();

  /**
   * Adds the treasure in the location.
   *
   * @param treasure is the type of treasure
   * @param value    is the value of the treasure
   */
  void setTreasure(Treasure treasure, int value);

  /**
   * Sets the value of the curved arrows present in the cave.
   *
   * @param value is the value of the curved arrow
   */
  void setArrowInCave(int value);

  /**
   * Gets the value of the arrows available in the cave.
   *
   * @return the value of the curved arrows
   */
  int getArrowInCave();

  /**
   * Sets the smell counter based on the given value.
   *
   * @param value to be assigned as the smell counter
   */
  void setSmellCounter(int value);

  /**
   * Increases the smell counter of the location upto a max of 2 based on how far apart the monsters
   * are to the location.
   */
  void increaseSmellCounter();

  /**
   * Decreases the smell counter of the location upto a min of 0 based on how far apart the monsters
   * are to the location or if the monster is dead.
   */
  void decreaseSmellCounter();

  /**
   * Gets the smell counter of the cave. If it is 0, it means there are no monsters in the nearby
   * caves. If it is 1, it means there is only 1 monster 2 distance away from this location.
   * If it is 2 or more, it means there is at least 1 monster 1 distance away or multiple monsters
   * 2 distance away. If it is 100, it means that the location houses a monster.
   *
   * @return the smell counter of the location
   */
  int getSmellCounter();

  /**
   * If the location has an exit to the left, it returns true.
   *
   * @return 1 if it has a left exit
   */
  int getLeft();

  /**
   * If the location has an exit to the right, it returns true.
   *
   * @return 1 if it has a right exit
   */
  int getRight();

  /**
   * If the location has an exit at the top, it returns true.
   *
   * @return 1 if it has a top exit
   */
  int getTop();

  /**
   * If the location has an exit at the bottom, it returns true.
   *
   * @return 1 if it has a bottom exit
   */
  int getBottom();

  /**
   * We can check the amount of sapphire stored in the given location.
   *
   * @return the value of sapphire in the location
   */
  int getSapphireValue();

  /**
   * We can check the amount of ruby stored in the given location.
   *
   * @return the value of ruby in the location
   */
  int getRubyValue();

  /**
   * We can check the amount of diamond stored in the given location.
   *
   * @return the value of diamond in the location
   */
  int getDiamondValue();

  /**
   * This method checks if the location has been visited or not.
   *
   * @return if the location has been visited
   */
  boolean isVisitedFlag();

  /**
   * This method sets the visited flag for this location.
   */
  void setVisitedFlag();

  /**
   * Gets the exits in text format.
   *
   * @return the name of the cave
   */
  String getExitsText();
}
