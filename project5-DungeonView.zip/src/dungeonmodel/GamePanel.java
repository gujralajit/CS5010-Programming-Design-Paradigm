package dungeonmodel;

import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Objects;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * This is the game panel of our graphic dungeon. The game panel takes in the state from the
 * dungeon and presents the dungeon in a way to the player such that only the locations visited
 * by the player are visible to the user.
 */
public class GamePanel extends JPanel {

  private final ReadOnlyModel model;
  private final JLabel[][] labelSet;
  private final int row;
  private final int column;

  /**
   * A constructor for the game panel that takes in a read only model to capture the game state
   * and validate which nodes have been visited by the player.
   *
   * @param model denotes the read only model
   */
  public GamePanel(ReadOnlyModel model) {
    if (model != null) {
      this.model = model;
      row = model.getRowSize();
      column = model.getColumnSize();

      labelSet = new JLabel[row][column];
      JPanel rowPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));

      setLayout(new GridLayout(0, 5));

      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          BufferedImage b2;
          try {
            b2 = ImageIO.read(Objects.requireNonNull(getClass().getResourceAsStream("/blank.png")));
          } catch (IOException e) {
            throw new IllegalStateException("Illegal arguments have been passed for image.");
          }

          labelSet[i][j] = new JLabel(new ImageIcon(b2));
          rowPanel.add(labelSet[i][j]);
        }
        add(rowPanel);
      }
    } else {
      throw new IllegalArgumentException("Null model has been passed to the game panel. ");
    }
  }

  @Override
  protected void paintComponent(Graphics g) {
    if (g != null) {
      super.paintComponent(g);

      BufferedImage b;
      BufferedImage b1;
      BufferedImage b2;

      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          if (model.isVisited(i, j)) {
            if (i == model.getPlayerRow() && j == model.getPlayerColumn()) {
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream("/player.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              try {
                b = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream(
                                "/" + model.getExitsText(i, j) + ".png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              b2 = overlay(b, b1, 2, 16);
            } else {
              try {
                b2 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream(
                                "/" + model.getExitsText(i, j) + ".png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
            }

            int counter = 1;
            if (model.getArrowCount(i, j) > 0) {
              b = b2;
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(
                                getClass().getResourceAsStream("/arrow-white.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              if (model.isTunnel(i, j)) {
                b2 = overlay(b, b1, 10, counter * 25);
              } else {
                b2 = overlay(b, b1, 10, counter * 10);
              }
              counter++;
            }
            if (model.getRubyCount(i, j) > 0) {
              b = b2;
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream("/ruby.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              b2 = overlay(b, b1, 10, counter * 10);
              counter++;
            }
            if (model.getDiamondCount(i, j) > 0) {
              b = b2;
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream("/diamond.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              b2 = overlay(b, b1, 10, counter * 10);
              counter++;
            }
            if (model.getSapphireCount(i, j) > 0) {
              b = b2;
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream("/sapphire.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              b2 = overlay(b, b1, 10, counter * 10);
            }

            if (model.getSmellCounter(i, j) == 100) {
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream("/otyugh.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              b = b2;
              b2 = overlay(b, b1, 2, 18);
            } else if (model.getSmellCounter(i, j) >= 2) {
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream("/stench02.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              b = b2;
              b2 = overlay(b, b1, 1, 0);
            } else if (model.getSmellCounter(i, j) == 1) {
              try {
                b1 = ImageIO.read(
                        Objects.requireNonNull(getClass().getResourceAsStream("/stench01.png")));
              } catch (IOException e) {
                throw new IllegalStateException("Illegal arguments have been passed for image.");
              }
              b = b2;
              b2 = overlay(b, b1, 1, 0);
            }

            labelSet[i][j].setIcon(new ImageIcon(b2));
            //https://stackoverflow.com/questions/299495/how-to-add-an-image-to-a-jpanel
          } else {
            try {
              b2 = ImageIO.read(
                      Objects.requireNonNull(getClass().getResourceAsStream("/blank.png")));
            } catch (IOException e) {
              throw new IllegalStateException("Illegal arguments have been passed for image.");
            }
            labelSet[i][j].setIcon(new ImageIcon(b2));
          }
        }
      }
    } else {
      throw new IllegalArgumentException("Null graphics have been passed to the game panel. ");
    }
  }

  //https://piazza.com/class/kt0jcw0x7h955a?cid=1471
  //helper method to overlay 2 images over each other
  private BufferedImage overlay(BufferedImage starting, BufferedImage overlay, int division,
                                int offset) {
    if (starting != null && overlay != null && division > 0 && offset >= 0) {
      int w = starting.getWidth();
      int h = starting.getHeight();
      BufferedImage combined = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
      Graphics g = combined.getGraphics();
      Image newImage = overlay.getScaledInstance(w / division, h / division, Image.SCALE_DEFAULT);
      g.drawImage(starting, 0, 0, null);
      g.drawImage(newImage, offset, offset, null);
      return combined;
    } else {
      throw new IllegalArgumentException("Incorrect arguments have been passed to the overlay"
              + " method. ");
    }
  }
}
