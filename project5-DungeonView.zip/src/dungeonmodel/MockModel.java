package dungeonmodel;

import java.io.IOException;

/**
 * A mock model to test the features of a read only model when passed to a controller and view.
 */
public class MockModel implements ReadOnlyModel {

  Appendable log;

  /**
   * A constructor for the mock model that initializes the log.
   *
   * @param log denotes the log appendable
   */
  public MockModel(Appendable log) {
    this.log = log;
  }

  @Override
  public boolean isGameOver() {
    try {
      log.append("Inside the isGameOver method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return true;
  }

  @Override
  public int getPlayerRow() {
    try {
      log.append("Inside the get player row method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getPlayerColumn() {
    try {
      log.append("Inside the get player column method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getRubyCount(int row, int column) {
    try {
      log.append("Inside the get ruby count method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getSapphireCount(int row, int column) {
    try {
      log.append("Inside the get sapphire count method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getDiamondCount(int row, int column) {
    try {
      log.append("Inside the get diamond count method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getArrowCount(int row, int column) {
    try {
      log.append("Inside the get arrow count method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public boolean isTunnel(int row, int column) {
    try {
      log.append("Inside the is tunnel method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return true;
  }

  @Override
  public int getPlayerRubyCount() {
    try {
      log.append("Inside the get ruby count for player method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getPlayerSapphireCount() {
    try {
      log.append("Inside the get sapphire count for player method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getPlayerDiamondCount() {
    try {
      log.append("Inside the get diamond count for player method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getPlayerArrowCount() {
    try {
      log.append("Inside the get arrow count for player method. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getRowSize() {
    try {
      log.append("Inside the get row size of dungeon. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public int getColumnSize() {
    try {
      log.append("Inside the get row size of dungeon. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }

  @Override
  public boolean isVisited(int row, int column) {
    try {
      log.append("Inside the is visited method for a specific location in the dungeon. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return true;
  }

  @Override
  public String getExitsText(int row, int column) {
    try {
      log.append("Inside getting the exits in text format. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return "";
  }

  @Override
  public int getSmellCounter(int row, int column) {
    try {
      log.append("Inside the get smell counter for a location in the dungeon. ");
    } catch (IOException e) {
      throw new IllegalStateException("Illegal arguments have been passed for appendable. ");
    }
    return 0;
  }
}
