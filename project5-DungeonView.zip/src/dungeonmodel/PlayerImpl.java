package dungeonmodel;

/**
 * Creates a player class to enter the dungeon. It has the ability to traverse the dungeon and
 * collect treasures present in the caves.
 */
public class PlayerImpl implements Player {

  private int rubyValue;
  private int sapphireValue;
  private int diamondValue;
  private int curvedArrowWithPlayer;

  /**
   * Constructor for the player which sets the default values of the treasure held by the player
   * to 0 and assigns 3 crooked arrows to their quiver.
   */
  public PlayerImpl() {

    rubyValue = 0;
    sapphireValue = 0;
    diamondValue = 0;
    curvedArrowWithPlayer = 3;
  }

  @Override
  public void addTreasure(Treasure t, int val) {

    if (t != null && val >= 0) {
      if (t == Treasure.RUBY) {
        rubyValue += val;
      } else if (t == Treasure.SAPPHIRE) {
        sapphireValue += val;
      } else if (t == Treasure.DIAMOND) {
        diamondValue += val;
      }
    } else {
      throw new IllegalArgumentException("Incorrect values have been passed to the treasure. ");
    }
  }

  @Override
  public void pickupArrows(int val) {
    if (val >= 0) {
      curvedArrowWithPlayer += val;
    } else {
      throw new IllegalArgumentException("Incorrect values have been passed to the arrow. ");
    }
  }


  @Override
  public String shootArrow() {
    if (curvedArrowWithPlayer > 0) {
      curvedArrowWithPlayer--;
    } else {
      return "No arrows available to the player. \n";
    }
    return "";
  }

  @Override
  public int getRubyValue() {
    return rubyValue;
  }

  @Override
  public int getDiamondValue() {
    return diamondValue;
  }

  @Override
  public int getSapphireValue() {
    return sapphireValue;
  }

  @Override
  public int getArrowValue() {
    return curvedArrowWithPlayer;
  }

  @Override
  public String toString() {

    StringBuilder tempTreasure = new StringBuilder();
    StringBuilder sb = new StringBuilder();
    if (curvedArrowWithPlayer != 0) {
      sb.append("The player has ").append(curvedArrowWithPlayer);
      sb.append(" arrows currently equipped. ");
    }
    if (rubyValue == 0 && sapphireValue == 0 && diamondValue == 0) {
      sb.append("The player has no treasures equipped yet. ");
      return sb.toString();
    }
    tempTreasure.append("The player has the following treasures equipped --> ");
    sb.append(Cave.getString(tempTreasure, rubyValue, sapphireValue, diamondValue));
    return sb.toString();
  }
}