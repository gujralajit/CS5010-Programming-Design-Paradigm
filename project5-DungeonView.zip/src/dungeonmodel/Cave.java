package dungeonmodel;

/**
 * Creates a cave class which represents the location in the given dungeon. It can represent a cave
 * as well as a tunnel. Only caves have the property to hold treasure. A cave can have at max 4
 * exits and 3 types of treasures.
 */
public class Cave implements Location {

  private final int leftExit;
  private final int rightExit;
  private final int topExit;
  private final int bottomExit;

  private int rubyValue;
  private int sapphireValue;
  private int diamondValue;
  private int curvedArrowInCave;
  private int smellCounter;

  private boolean visitedFlag;

  /**
   * Constructor to create a cave in the dungeon. The exits are decided by the edges present in the
   * adjacency list based on the given interconnectivity and the wrapping properties.
   *
   * @param leftExit   denotes if it has a left exit
   * @param rightExit  denotes if it has a right exit
   * @param topExit    denotes if it has a top exit
   * @param bottomExit denotes if it has a bottom exit
   */
  public Cave(int leftExit, int rightExit, int topExit, int bottomExit) {
    if ((leftExit == 0 || leftExit == 1) && (rightExit == 0 || rightExit == 1)
            && (topExit == 0 || topExit == 1) && (bottomExit == 0 || bottomExit == 1)) {
      this.leftExit = leftExit;
      this.rightExit = rightExit;
      this.topExit = topExit;
      this.bottomExit = bottomExit;
      rubyValue = 0;
      sapphireValue = 0;
      diamondValue = 0;
      curvedArrowInCave = 0;
      smellCounter = 0;
      visitedFlag = false;
    } else {
      throw new IllegalArgumentException("Exit values have been passed incorrectly. ");
    }
  }

  /**
   * A copy constructor for the cave to create a deep copy when restarting the game.
   *
   * @param c1 is the cave whose details are to be copied.
   */
  public Cave(Cave c1) {
    this.leftExit = c1.getLeft();
    this.rightExit = c1.getRight();
    this.topExit = c1.getTop();
    this.bottomExit = c1.getBottom();
    rubyValue = c1.getRubyValue();
    sapphireValue = c1.getSapphireValue();
    diamondValue = c1.getDiamondValue();
    curvedArrowInCave = c1.getArrowInCave();
    smellCounter = c1.getSmellCounter();
    visitedFlag = false;
  }

  /**
   * A helper method to create the string function which denotes the cave properties and what values
   * of treasure are present in the cave, if any.
   *
   * @param tempTreasure  holds the string of the treasure values
   * @param rubyValue     contains the ruby value in the cave
   * @param sapphireValue contains the sapphire value in the cave
   * @param diamondValue  contains the diamond value in the cave
   * @return the string that contains the treasure values
   */
  static String getString(StringBuilder tempTreasure, int rubyValue, int sapphireValue,
                          int diamondValue) {
    if (tempTreasure != null) {
      if (rubyValue != 0) {
        tempTreasure.append("\nRuby : ").append(rubyValue);
      }
      if (sapphireValue != 0) {
        tempTreasure.append("\nSapphire : ").append(sapphireValue);
      }
      if (diamondValue != 0) {
        tempTreasure.append("\nDiamond : ").append(diamondValue);
      }
    } else {
      throw new IllegalArgumentException("String cannot be null for treasure. ");
    }
    return tempTreasure.toString();
  }

  @Override
  public void setTreasure(Treasure t, int val) {

    if (t != null && val >= 0) {
      if (t == Treasure.RUBY) {
        rubyValue = val;
      } else if (t == Treasure.SAPPHIRE) {
        sapphireValue = val;
      } else if (t == Treasure.DIAMOND) {
        diamondValue = val;
      }
    } else {
      throw new IllegalArgumentException("Incorrect values have been passed to the treasure. ");
    }
  }

  @Override
  public void setArrowInCave(int val) {
    if (val >= 0) {
      curvedArrowInCave = val;
    } else {
      throw new IllegalArgumentException("Incorrect values have been passed to the arrow. ");
    }
  }

  @Override
  public int getArrowInCave() {
    return curvedArrowInCave;
  }


  @Override
  public void setSmellCounter(int val) {
    if (val >= 0 && val <= 100) {
      smellCounter = val;
    } else {
      throw new IllegalArgumentException("Invalid value for smell counter. ");
    }
  }

  @Override
  public void increaseSmellCounter() {
    smellCounter++;
  }

  @Override
  public void decreaseSmellCounter() {
    smellCounter--;
  }

  @Override
  public int getSmellCounter() {
    return smellCounter;
  }

  @Override
  public int getExits() {
    return leftExit + rightExit + topExit + bottomExit;
  }

  @Override
  public Boolean isTunnel() {
    return getExits() == 2;
  }

  @Override
  public int getLeft() {
    return leftExit;
  }

  @Override
  public int getRight() {
    return rightExit;
  }

  @Override
  public int getTop() {
    return topExit;
  }

  @Override
  public int getBottom() {
    return bottomExit;
  }

  @Override
  public int getSapphireValue() {
    return sapphireValue;
  }

  @Override
  public int getRubyValue() {
    return rubyValue;
  }

  @Override
  public int getDiamondValue() {
    return diamondValue;
  }

  @Override
  public boolean isVisitedFlag() {
    return visitedFlag;
  }

  @Override
  public String getExitsText() {
    StringBuilder sb = new StringBuilder();
    if (getTop() == 1) {
      sb.append("N");
    }
    if (getBottom() == 1) {
      sb.append("S");
    }
    if (getRight() == 1) {
      sb.append("E");
    }
    if (getLeft() == 1) {
      sb.append("W");
    }
    return sb.toString();
  }

  @Override
  public void setVisitedFlag() {
    visitedFlag = true;
  }

  @Override
  public String toString() {

    StringBuilder sb = new StringBuilder();
    if (rubyValue == 0 && sapphireValue == 0 && diamondValue == 0) {
      if (!isTunnel()) {
        sb.append("This cave has no treasures. ");
      }
    } else {
      sb.append("The cave has the following treasures : ");
      sb.append(getString(new StringBuilder(), rubyValue, sapphireValue, diamondValue));
    }
    if (curvedArrowInCave > 0) {
      if (!isTunnel()) {
        sb.append("\n");
      }
      sb.append("It has ").append(curvedArrowInCave).append(" arrows. ");
    }
    return sb.toString();
  }
}
