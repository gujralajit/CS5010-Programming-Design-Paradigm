package dungeonmodel;

/**
 * This is the controller for our interactive graphical adventure game. The controller handles
 * the game and the functioning of the model and the user. The controller takes in the input from
 * the user on where to move and what actions to commit and parses and passes that information to
 * the model. The controller acts as a bridge between the user and the actual game to prevent
 * the game from breaking in case the user enters invalid arguments.
 */
public interface GraphicController {

  /**
   * Gets the attribute from the view based on the parameters entered by the user and takes in
   * creates a model based on the given parameters.
   */
  void getAttributes();

  /**
   * Starts the game and passes the control to the user. The user can not make various moves and
   * try to win the game by killing the Otyugh.
   *
   * @param flag is the term that denotes if it is a new game or restart
   */
  void playGame(int flag);

  /**
   * This function andles the various commands entered by the user. The user can enter 'a' to
   * pickup arrows, 't' to pickup treasure, directional keys to move and 's' + a directional key
   * to shoot an arrow.
   *
   * @param code  is the first key press
   * @param code2 is the second key press captured for shooting the arrow
   * @param dist  is the distance entered by the user to shoot the arrow at
   */
  void handleKeyPress(int code, int code2, int dist);

  /**
   * This function handles the mouse clicks done by the user. This is captured to move the player
   * in the correct direction in case they decide to navigate the dungeon by mouse clicks rather
   * than directional keys.
   *
   * @param direction is the direction in which to move
   */
  void handleCellClick(String direction);
}
