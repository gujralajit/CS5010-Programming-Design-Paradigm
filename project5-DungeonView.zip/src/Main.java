import dungeonmodel.Controller;
import dungeonmodel.ControllerImpl;
import dungeonmodel.GraphicControllerImpl;
import dungeonmodel.Model;
import dungeonmodel.ModelImpl;
import java.io.InputStreamReader;

/**
 * Main method to denote the driver class.
 */
public class Main {

  /**
   * Main class which is the driver for our dungeon.
   *
   * @param args inline arguments
   */
  public static void main(String[] args) {

    int row;
    int column;
    int interconnectivity;
    int cavePercentage;
    int difficulty;
    try {
      row = Integer.parseInt(args[0]);
      column = Integer.parseInt(args[1]);
      interconnectivity = Integer.parseInt(args[2]);
      cavePercentage = Integer.parseInt(args[4]);
      difficulty = Integer.parseInt(args[5]);
      boolean wrapping = Boolean.parseBoolean(args[3]);

      Model model = new ModelImpl(row, column, interconnectivity, wrapping, cavePercentage,
              difficulty);

      Readable in = new InputStreamReader(System.in);
      Appendable out = System.out;

      Controller c = new ControllerImpl(model, in, out);
      c.playGame();
    } catch (NumberFormatException nfe) {
      throw new IllegalArgumentException("Illegal arguments have been passed. Please try again. ");
    } catch (ArrayIndexOutOfBoundsException | NullPointerException nfe) {
      GraphicControllerImpl c = new GraphicControllerImpl();
      c.playGame(0);
    }
  }
}