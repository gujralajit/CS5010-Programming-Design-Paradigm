import org.junit.Before;
import org.junit.Test;

import dungeonmodel.DungeonView;
import dungeonmodel.GraphicControllerImpl;
import dungeonmodel.MockModel;
import dungeonmodel.MockView;
import dungeonmodel.ReadOnlyModel;

import static org.junit.Assert.assertEquals;

/**
 * Testing for dungeon.
 */
public class GraphicTest {

  ReadOnlyModel mockModel;
  Appendable modelLog;

  DungeonView mockView;
  Appendable viewLog;

  ReadOnlyModel rom;

  @Before
  public void setUp() {
    modelLog = new StringBuilder();
    viewLog = new StringBuilder();
    mockModel = new MockModel(modelLog);
    mockView = new MockView(viewLog);
  }

  @Test
  public void testCreateGamePanel() {
    mockView.createGamePanel(rom);
    assertEquals("Read only model appended to the view. ", viewLog.toString());
  }

  @Test
  public void testGetAttributes() {
    mockView.getAttributes();
    assertEquals("Inside the get attribute function. ", viewLog.toString());
  }

  @Test
  public void testSetModel() {
    mockView.setModel(mockModel);
    assertEquals("Read only model has been set in the view. ", viewLog.toString());

  }

  @Test
  public void testSetPlayerInfoPanel() {
    mockView.setPlayerInfoPanel();
    assertEquals("Setting the player information panel to the view. ", viewLog.toString());

  }

  @Test
  public void testAddClickListener() {
    mockView.addClickListener(new GraphicControllerImpl());
    assertEquals("Added click listener to the view. ", viewLog.toString());

  }

  @Test
  public void testAddKeyListener() {
    mockView.addKeyListener(new GraphicControllerImpl());
    assertEquals("Added key listener to the view. ", viewLog.toString());
  }

  @Test
  public void testRefresh() {
    mockView.refresh();
    assertEquals("Inside the refresh method for the view. ", viewLog.toString());
  }

  @Test
  public void testMakeVisible() {
    mockView.makeVisible();
    assertEquals("Inside the make visible method for the view. ", viewLog.toString());
  }

  @Test
  public void testSetFeedback() {
    mockView.setFeedback("");
    assertEquals("Setting the feedback for the view : ", viewLog.toString());
  }

  @Test
  public void testIsGameOver() {
    mockModel.isGameOver();
    assertEquals("Inside the isGameOver method. ", modelLog.toString());
  }

  @Test
  public void testGetPlayerRow() {
    mockModel.getPlayerRow();
    assertEquals("Inside the get player row method. ", modelLog.toString());
  }

  @Test
  public void testGetPlayerColumn() {
    mockModel.getPlayerColumn();
    assertEquals("Inside the get player column method. ", modelLog.toString());
  }

  @Test
  public void testGetRubyCount() {
    mockModel.getRubyCount(0, 0);
    assertEquals("Inside the get ruby count method. ", modelLog.toString());
  }

  @Test
  public void testGetSapphireCount() {
    mockModel.getSapphireCount(0, 0);
    assertEquals("Inside the get sapphire count method. ", modelLog.toString());
  }

  @Test
  public void testGetDiamondCount() {
    mockModel.getDiamondCount(0, 0);
    assertEquals("Inside the get diamond count method. ", modelLog.toString());
  }

  @Test
  public void testGetArrowCount() {
    mockModel.getArrowCount(0, 0);
    assertEquals("Inside the get arrow count method. ", modelLog.toString());
  }

  @Test
  public void testIsTunnel() {
    mockModel.isTunnel(0, 0);
    assertEquals("Inside the is tunnel method. ", modelLog.toString());
  }

  @Test
  public void testGetPlayerRubyCount() {
    mockModel.getPlayerRubyCount();
    assertEquals("Inside the get ruby count for player method. ", modelLog.toString());
  }

  @Test
  public void testGetPlayerSapphireCount() {
    mockModel.getPlayerSapphireCount();
    assertEquals("Inside the get sapphire count for player method. ", modelLog.toString());
  }

  @Test
  public void testGetPlayerDiamondCount() {
    mockModel.getPlayerDiamondCount();
    assertEquals("Inside the get diamond count for player method. ", modelLog.toString());
  }

  @Test
  public void testGetPlayerArrowCount() {
    mockModel.getPlayerArrowCount();
    assertEquals("Inside the get arrow count for player method. ", modelLog.toString());
  }

  @Test
  public void testGetRowSize() {
    mockModel.getRowSize();
    assertEquals("Inside the get row size of dungeon. ", modelLog.toString());
  }

  @Test
  public void testGetColumnSize() {
    mockModel.getColumnSize();
    assertEquals("Inside the get row size of dungeon. ", modelLog.toString());
  }

  @Test
  public void testIsVisited() {
    mockModel.isVisited(0, 0);
    assertEquals("Inside the is visited method for a specific location in the dungeon. ",
            modelLog.toString());
  }

  @Test
  public void testGetExitsText() {
    mockModel.getExitsText(0, 0);
    assertEquals("Inside getting the exits in text format. ", modelLog.toString());
  }

  @Test
  public void testGetSmellCounter() {
    mockModel.getSmellCounter(0, 0);
    assertEquals("Inside the get smell counter for a location in the dungeon. ",
            modelLog.toString());
  }
}