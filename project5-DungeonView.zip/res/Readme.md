# Readme

1. **About**
    * Creating a model that can create a dungeon.
    * The dungeon contains caves and tunnels.
    * If the location has exactly 2 exits, it is a tunnel.
    * The size of the dungeon is given by the user.
    * The dungeon can be wrapping, which means the last row connects to first row and last column
      connects to first column.
    * The user can increase interconnectivity among the dungeons, which means increasing paths among
      nodes.
    * By default, we create the dungeon with 0 interconnectivity, meaning there exists only 1
      distinct path among any 2 nodes in the dungeon.
    * We can also populate the dungeon with treasure.
    * Treasure can be assigned only to caves.
    * The difficulty can also be increased by the player.
    * By default, only 1 monster is assigned to the end cave.
    * Monsters are only assigned to a cave, and they cannot move.
    * Monsters are smelly creatures and their smell affects the adjoining locations in the dungeon.
    * Player can enter at the start and get out at the end.
    * Player can collect treasure from the caves.
    * If the player hits the monster twice, it dies.
    * If the player enters a cave with an injured monster, there is a 50% chance they will be eaten.
    * There is also a graphical dungeon available to the player now. 
    * The user can see the positions that they have traversed and try to escape the dungeon. 
    * The user has the ability to move, pickup treasures and arrows, or shoot arrows. 
    * If the user reaches the end without killing the otyugh, they die. 
    * If they kill the otyugh and reach the end, the have won the game. 

2. **List of Features**
    * Player can collect treasure.
    * Caves can have treasure.
    * Player can get into the dungeon from start cave.
    * Player can get out of the dungeon from end cave.
    * Player can pick up arrows from the dungeon.
    * Player can shoot the arrow and try to hit the monster.
    * Player can move through the graphical dungeon by clicking on neighbouring cells. 
    * Player can also move my pressing the arrow keys. 
    * Player can pick up arrows and treasures. 
    * Player can shoot an arrow of up to 5 distance. 


3. **How To Run**
    * User has to run the jar and give command line arguments.
    * The command is as follows : java -jar project4-DungeonController.jar 5 5 5 true 20 0
    * User has to enter the row, column, interconnectivity, wrapping, cave percentage and difficulty
      to create the dungeon using command line arguments.
    * The user will have to move the player and give commands to pick up treasure and arrows
    * The user has to give direction and distance to shoot.
    * If the user wishes to play the graphical dungeon, they must run the jar with no command line 
      arguments. 
    * The default values are already entered when the user is prompted for the settings. 
    * The user can update the settings and play the game. 
    * The images in teh dungeon are already inside the jar so the user simply needs to run it. 


4. **How to Use the Program**
    * User has to create the dungeon by giving command line arguments.
    * The dungeon is created and user has to give command to play or quit the game.
    * User knows what commands to give and how to read the output to gauge the feedback.
    * User can play the graphical game by simply running the jar with no command line arguments. 
    * The default values are entered when opening the settings menu. 
    * If the user enters some incorrect values, it'll capture the default value and create the model. 


5. **Description of Examples**
    * Image 1 shows a scrollable dungeon. 
    * Image 2 shows a completely dark dungeon when the player is at start location.
    * Image 3 shows a fully traversed dungeon. 
    * Image 4 shows the smell being removed after killing the monster. 
    * Image 5 shows the player winning the dungeon and appropriate feedback. 


6. **Design/Model Changes**
    * Added a controller class and interface to the model.
    * The driver class simply creates the model, readable and appendable and passes it to the
      controller to run the program and allows the user to play the game.
    * Added monster class and interface to display the characteristics of the otyugh.
    * Assigned arrows to the locations and player.
    * Allowed the player the ability to shoot the arrow and try to hit the monster.
    * Added functions to the model to assign monsters and populate arrows in the dungeon.
    * Added functionality to the cave to know if it has been visited or not. 
    * Returned treasure and arrow values from the dungeon to the view and controller. 



7. **Assumptions**
    * User knows how to run the program.
    * They are aware that they have to give input for creating the dungeon using command line args.
    * User is aware of illegal arguments (row negative, cave percentage greater than 100).
    * User is aware of the attributes of the dungeon.
    * User is aware that to win the game they have to successfully exit the dungeon from the end
      cave.
    * User is aware of valid and invalid commands. 
    * User is aware of order of entering values. 
    * User is aware on how to quit or restart the game. 


8. **Limitations**
    * User has to enter valid inputs for the commands of the game.
    * There is no limit to the bag and quiver to apply a max of arrows or treasure stored.
    * There is very little feedback given to the player to make choices to advance to the exit.
    * Player can see the full dungeon and makes it easy to traverse. 
    * Player cannot see how far the arrow was shot. 
    * Player does not know which location is the end location when there are multiple Otyughs. 


9. **Citations**
    * https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/
    * https://www.geeksforgeeks.org/graph-and-its-representations/
    * https://www.geeksforgeeks.org/shortest-path-unweighted-graph/
    * https://en.wikipedia.org/wiki/Kruskal's_algorithm
    * https://en.wikipedia.org/wiki/Depth-first_search#:~:text=Depth%2Dfirst%20search%20(DFS
    * https://en.wikipedia.org/wiki/Adventure_game
    * https://en.wikipedia.org/wiki/Text-based_game
    * https://forgottenrealms.fandom.com/wiki/Otyugh
    * https://stackoverflow.com/questions/1385737/scrollable-jpanel
    * https://stackoverflow.com/questions/41172472/how-to-make-jpanel-scrollable
    * https://stackoverflow.com/questions/6555040/multiple-input-in-joptionpane-showinputdialog/6555051
    * https://piazza.com/class/kt0jcw0x7h955a?cid=1471
    * https://stackoverflow.com/questions/299495/how-to-add-an-image-to-a-jpanel

