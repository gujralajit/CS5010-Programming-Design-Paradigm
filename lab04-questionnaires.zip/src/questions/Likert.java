package questions;

/**
 * Creating a likert type question that takes opinions on a 5 point scale with no incorrect answer.
 */
public class Likert implements Question {

  private String ques;

  /**
   * Creating a constructor to initialize the question for likert type questions.
   *
   * @param question has the text for the question
   */
  public Likert(String question) {
    ques = question;
  }

  @Override
  public String answer(String answer) {
    if (answer.equals("1") || answer.equals("2") || answer.equals("3") || answer.equals("4")
            || answer.equals("5")) {
      return "Correct";
    } else {
      return "Incorrect";
    }
  }

  @Override
  public String getText() {
    return ques;
  }

  @Override
  public int compareTo(Question o) {
    if (o instanceof TrueFalse || o instanceof MultipleChoice || o instanceof MultipleSelect) {
      return 1;
    } else if (o instanceof Likert) {
      return ques.compareTo(o.getText());
    } else {
      return -1;
    }
  }
}
