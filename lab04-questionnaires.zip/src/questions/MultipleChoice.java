package questions;

/**
 * Creating a multiple choice type question that takes 3 to 8 options and has only 1 correct answer.
 */
public class MultipleChoice implements Question {

  private final String ques;
  private final String ans;
  private String[] opt = new String[8];

  /**
   * Creating a constructor to initialize the question, answer and options of a multiple choice type
   * question.
   *
   * @param question has the text for the question
   * @param answer   has the correct option
   * @param options  has all the options of the provided question
   */
  public MultipleChoice(String question, String answer, String... options) {
    if (options.length < 3 || options.length > 8) {
      throw new IllegalArgumentException("There should be a minimum of 3 options and a maximum "
              + "of 8 options. ");
    }
    ques = question;
    ans = answer;

    System.arraycopy(options, 0, opt, 0, options.length);
  }

  @Override
  public String answer(String answer) {

    if (answer.equals(ans)) {
      return "Correct";
    } else {
      return "Incorrect";
    }
  }

  @Override
  public String getText() {
    return ques;
  }

  @Override
  public int compareTo(Question o) {
    if (o instanceof TrueFalse) {
      return 1;
    } else if (o instanceof MultipleChoice) {
      return ques.compareTo(o.getText());
    } else {
      return -1;
    }
  }
}
