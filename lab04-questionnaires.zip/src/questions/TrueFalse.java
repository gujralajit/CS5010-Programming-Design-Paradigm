package questions;

/**
 * Creating a true false type question that can only have 1 answer.
 */
public class TrueFalse implements Question {

  private String ques;
  private String ans;

  /**
   * Creating a constructor to initialize the question and the answer.
   *
   * @param question has the text for the question
   * @param answer   has the correct answer of either true or false
   */
  public TrueFalse(String question, String answer) {

    ques = question;
    ans = answer;
  }

  @Override
  public String answer(String answer) {
    if (answer.equals(ans)) {
      return "Correct";
    } else {
      return "Incorrect";
    }
  }

  @Override
  public String getText() {
    return ques;
  }

  @Override
  public int compareTo(Question o) {
    if (o instanceof TrueFalse) {
      o = (TrueFalse) o;
      return ques.compareTo(o.getText());
    } else {
      return -1;
    }
  }
}
