import org.junit.Before;
import org.junit.Test;

import questions.Likert;

import static org.junit.Assert.assertEquals;

/**
 * Creating a test for the likert type questions.
 */
public class LikertTest {

  Likert l1;

  @Before
  public void setUp() throws Exception {
    l1 = new Likert("What do you think about x?");
  }

  @Test
  public void answer() {
    assertEquals("Correct", l1.answer("2"));
  }

  @Test
  public void getText() {
    assertEquals("What do you think about x?", l1.getText());
  }

  @Test
  public void compareTo() {
    assertEquals(0, l1.compareTo(l1));
  }
}