import org.junit.Before;
import org.junit.Test;

import questions.MultipleChoice;
import questions.TrueFalse;

import static org.junit.Assert.assertEquals;

/**
 * Creating a test for the true false type questions.
 */
public class TrueFalseTest {

  TrueFalse m1;
  MultipleChoice m2;

  @Before
  public void setUp() throws Exception {
    m1 = new TrueFalse("What do you think about x?", "True");
  }

  @Test
  public void answer() {
    assertEquals("Correct", m1.answer("True"));
  }

  @Test
  public void getText() {
    assertEquals("What do you think about x?", m1.getText());
  }

  @Test
  public void compareTo() {
    assertEquals(-1, m1.compareTo(m2));
  }
}