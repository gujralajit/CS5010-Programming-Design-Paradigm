import org.junit.Before;
import org.junit.Test;

import questions.MultipleChoice;

import static org.junit.Assert.assertEquals;

/**
 * Creating a test for the multiple choice type questions.
 */
public class MultipleChoiceTest {

  MultipleChoice m1;

  @Before
  public void setUp() throws Exception {
    m1 = new MultipleChoice("What do you think about x?", "3",
            "Hello1", "Hello2", "Hello3", "Hello4", "Hello5");
  }

  @Test
  public void answer() {
    assertEquals("Correct", m1.answer("3"));
  }

  @Test
  public void getText() {
    assertEquals("What do you think about x?", m1.getText());
  }

  @Test
  public void compareTo() {
    assertEquals(0, m1.compareTo(m1));
  }
}