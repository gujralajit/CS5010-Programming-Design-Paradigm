package bst;

import java.util.stream.Collectors;

/**
 * Implementing the binary search tree as a recursive list.
 *
 * @param <T> is defined by the argument.
 */
public class BinarySearchTreeImpl<T extends Comparable<T>> implements BinarySearchTree<T> {

  private BSTNode<T> root;

  /**
   * Constructor for BSTImpl.
   */
  public BinarySearchTreeImpl() {
    root = new BSTLeafNode<>();
  }

  @Override
  public void add(T data) {
    root = root.add(data);
  }

  @Override
  public int size() {
    return root.size();
  }

  @Override
  public int height() {
    return root.height();
  }

  @Override
  public boolean present(T data) {
    return root.present(data);
  }

  @Override
  public T minimum() {
    return root.minimum();
  }

  @Override
  public T maximum() {
    return root.maximum();
  }

  @Override
  public String preOrder() {
    return "[" + root.preOrder().stream().map(Object::toString)
            .collect(Collectors.joining(" ")) + "]";
  }

  @Override
  public String inOrder() {
    return "[" + root.inOrder().stream().map(Object::toString)
            .collect(Collectors.joining(" ")) + "]";
  }

  @Override
  public String postOrder() {
    return "[" + root.postOrder().stream().map(Object::toString)
            .collect(Collectors.joining(" ")) + "]";
  }

  @Override
  public String toString() {
    return inOrder();
  }
}
