package bst;

import java.util.ArrayList;
import java.util.List;

class BSTGroupNode<T extends Comparable<T>> implements BSTNode<T> {

  private final T data;
  private BSTNode<T> left;
  private BSTNode<T> right;

  BSTGroupNode(T data, BSTNode<T> left, BSTNode<T> right) {
    this.data = data;
    this.left = left;
    this.right = right;
  }

  @Override
  public BSTNode<T> add(T data) {
    if (this.data.compareTo(data) < 0) {
      right = this.right.add(data);
    } else if (this.data.compareTo(data) > 0) {
      left = this.left.add(data);
    }
    return this;
  }

  @Override
  public int size() {
    return 1 + left.size() + right.size();
  }

  @Override
  public int height() {
    return 1 + Math.max(left.height(), right.height());
  }

  @Override
  public boolean present(T data) {
    if (this.data.compareTo(data) == 0) {
      return true;
    } else if (this.data.compareTo(data) > 0) {
      return left.present(data);
    } else {
      return right.present(data);
    }
  }

  @Override
  public T minimum() {
    if (left instanceof BSTLeafNode) {
      return data;
    } else {
      return left.minimum();
    }
  }

  @Override
  public T maximum() {
    if (right instanceof BSTLeafNode) {
      return data;
    } else {
      return right.maximum();
    }
  }

  @Override
  public List<T> preOrder() {
    List<T> l1 = new ArrayList<>();
    l1.add(data);
    l1.addAll(left.preOrder());
    l1.addAll(right.preOrder());
    return l1;
  }

  @Override
  public List<T> inOrder() {
    List<T> l1 = new ArrayList<>(left.inOrder());
    l1.add(data);
    l1.addAll(right.inOrder());
    return l1;
  }

  @Override
  public List<T> postOrder() {
    List<T> l1 = new ArrayList<>();
    l1.addAll(left.postOrder());
    l1.addAll(right.postOrder());
    l1.add(data);
    return l1;
  }
}
