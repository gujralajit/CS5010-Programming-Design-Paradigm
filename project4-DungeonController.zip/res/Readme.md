# Readme

1. **About**
    * Creating a model that can create a dungeon.
    * The dungeon contains caves and tunnels.
    * If the location has exactly 2 exits, it is a tunnel.
    * The size of the dungeon is given by the user.
    * The dungeon can be wrapping, which means the last row connects to first row and last column
      connects to first column.
    * The user can increase interconnectivity among the dungeons, which means increasing paths among
      nodes.
    * By default, we create the dungeon with 0 interconnectivity, meaning there exists only 1
      distinct path among any 2 nodes in the dungeon.
    * We can also populate the dungeon with treasure.
    * Treasure can be assigned only to caves.
    * The difficulty can also be increased by the player.
    * By default, only 1 monster is assigned to the end cave.
    * Monsters are only assigned to a cave, and they cannot move.
    * Monsters are smelly creatures and their smell affects the adjoining locations in the dungeon.
    * Player can enter at the start and get out at the end.
    * Player can collect treasure from the caves.
    * If the player hits the monster twice, it dies.
    * If the player enters a cave with an injured monster, there is a 50% chance they will be eaten.

2. **List of Features**
    * Player can collect treasure.
    * Caves can have treasure.
    * Player can get into the dungeon from start cave.
    * Player can get out of the dungeon from end cave.
    * Player can pick up arrows from the dungeon.
    * Player can shoot the arrow and try to hit the monster.


3. **How To Run**
    * User has to run the jar and give command line arguments.
    * The command is as follows : java -jar project4-DungeonController.jar 5 5 5 true 20 0
    * User has to enter the row, column, interconnectivity, wrapping, cave percentage and difficulty
      to create the dungeon using command line arguments.
    * The user will have to move the player and give commands to pick up treasure and arrows
    * The user has to give direction and distance to shoot.


4. **How to Use the Program**
    * User has to create the dungeon by giving command line arguments.
    * The dungeon is created and user has to give command to play or quit the game.
    * User knows what commands to give and how to read the output to gauge the feedback.


5. **Description of Examples**
    * Run 1 contains the player moving from the start location to the end location.
    * This includes picking up treasures and arrows.
    * This also includes shooting arrows in the dungeon and successfully hitting and missing the
      monster.
    * The player successfully kills the otyugh and escapes the dungeon, winning the game.
    * Run 2 contains the player moving from start to end and being eaten by the monster.


6. **Design/Model Changes**
    * Added a controller class and interface to the model.
    * The driver class simply creates the model, readable and appendable and passes it to the
      controller to run the program and allows the user to play the game.
    * Added monster class and interface to display the characteristics of the otyugh.
    * Assigned arrows to the locations and player.
    * Allowed the player the ability to shoot the arrow and try to hit the monster.
    * Added functions to the model to assign monsters and populate arrows in the dungeon.


7. **Assumptions**
    * User knows how to run the program.
    * They are aware that they have to give input for creating the dungeon using command line args.
    * User is aware of illegal arguments (row negative, cave percentage greater than 100).
    * User is aware of the attributes of the dungeon.
    * User is aware that to win the game they have to successfully exit the dungeon from the end
      cave.


8. **Limitations**
    * User has to enter valid inputs for the commands of the game.
    * There is no limit to the bag and quiver to apply a max of arrows or treasure stored.
    * There is very little feedback given to the player to make choices to advance to the exit.


9. **Citations**
    * https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/
    * https://www.geeksforgeeks.org/graph-and-its-representations/
    * https://www.geeksforgeeks.org/shortest-path-unweighted-graph/
    * https://en.wikipedia.org/wiki/Kruskal's_algorithm
    * https://en.wikipedia.org/wiki/Depth-first_search#:~:text=Depth%2Dfirst%20search%20(DFS
    * https://en.wikipedia.org/wiki/Adventure_game
    * https://en.wikipedia.org/wiki/Text-based_game
    * https://forgottenrealms.fandom.com/wiki/Otyugh
    
