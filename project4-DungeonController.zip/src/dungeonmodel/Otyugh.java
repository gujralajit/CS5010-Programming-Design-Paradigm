package dungeonmodel;

/**
 * The Otyugh class implements the monster interface and has all the properties of a monster that is
 * housed in the dungeon. It cannot move and exists at least at the end location.
 */
public class Otyugh implements Monster {

  private int health;
  private final Vertex location;

  /**
   * Constructor for the monster which is to be assigned to one of the locations in the dungeon.
   *
   * @param location is the location at which the monster is assigned.
   */
  public Otyugh(Vertex location) {
    if (location != null) {
      health = 2;
      this.location = location;
    } else {
      throw new IllegalArgumentException("Null location is passed to the monster. ");
    }
  }

  @Override
  public void damageMonster() {
    if (health > 0) {
      health--;
    }
  }

  @Override
  public Vertex getMonsterLocation() {
    return new Vertex(location.getRow(), location.getColumn());
  }

  @Override
  public int getMonsterHealth() {
    return health;
  }

  @Override
  public String toString() {
    if (health != 0) {
      return "The Otyugh is at row : " + location.getRow() + " and column : "
              + location.getColumn() + " with " + health + "health. ";
    } else {
      return "The Otyugh is dead at row : " + location.getRow() + " and column : "
              + location.getColumn();
    }
  }
}