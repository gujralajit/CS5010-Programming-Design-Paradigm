package dungeonmodel;

/**
 * Creates an edge denoting the connecting edges among the nodes of the dungeon. The edges present
 * in the list help us create the dungeon with the given interconnectivity and wrapping properties.
 * It takes in a source and destination node and stores if the edge exits or not.
 */
public class Edge {

  private final Vertex source;
  private final Vertex destination;

  /**
   * Constructor to create an edge with the given source and destination node.
   *
   * @param source      is the source node for this edge
   * @param destination is the destination node for this edge
   */
  public Edge(Vertex source, Vertex destination) {
    if (source == null || destination == null) {
      throw new IllegalArgumentException("Source or destination cannot be null. ");
    } else {
      this.source = source;
      this.destination = destination;
    }
  }

  /**
   * Returns the source of the edge.
   *
   * @return source
   */
  public Vertex getSource() {
    return new Vertex(source.getRow(), source.getColumn());
  }

  /**
   * Returns the destination of the edge.
   *
   * @return destination
   */
  public Vertex getDestination() {
    return new Vertex(destination.getRow(), destination.getColumn());
  }
}
