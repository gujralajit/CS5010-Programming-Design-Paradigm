package dungeonmodel;

/**
 * Creating a vertex to add to the graph so that we can compare the different caves in the dungeon
 * and find minimum distance, shortest path among 2 nodes, and other functions.
 * It takes in the row and column number of the dungeon and creates a vertex to denote the cave
 * or tunnel created at that node.
 */
public class Vertex {
  private final int row;
  private final int column;

  /**
   * Constructor to create a vertex representing the node in the dungeon.
   *
   * @param row    at which the cave is created
   * @param column at which the column is created
   */
  public Vertex(int row, int column) {
    if (row >= 0 && column >= 0) {
      this.row = row;
      this.column = column;
    } else {
      throw new IllegalArgumentException("Row or column cannot be less than 0. ");
    }
  }

  /**
   * Returns the row number of the vertex.
   *
   * @return row
   */
  public int getRow() {
    return row;
  }

  /**
   * Returns the column number of the vertex.
   *
   * @return column
   */
  public int getColumn() {
    return column;
  }
}
