package dungeonmodel;

/**
 * The monster interface is used to denote the Monster that is currently housed in the dungeon. The
 * monster is housed in a singular cave and cannot move from this location, one of which has to be
 * the end location. The monster has 2 health and can be killed by the player. The player can shoot
 * an arrow and if it hits the monster, it will damage it. A half damaged monster has a 50% chance
 * to eat the player if it enters its cave. The monster dies when it's health reaches zero.
 */
public interface Monster {

  /**
   * Damages the monster if the arrow hits it successfully, reducing its health by 1 if it is not
   * already dead.
   */
  void damageMonster();

  /**
   * Gets the location of the monster currently housed in the dungeon.
   *
   * @return the location of the monster
   */
  Vertex getMonsterLocation();

  /**
   * Gets the health of the monster, max of 2.
   *
   * @return the health of the monster
   */
  int getMonsterHealth();
}
