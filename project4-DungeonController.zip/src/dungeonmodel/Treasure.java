package dungeonmodel;

/**
 * Created an enumeration to denote the types of treasure in teh dungeon. Currently, we have 3
 * types of treasures : ruby, sapphire and diamond. This treasure is being held in the caves and
 * can be picked up by the player on traversing the dungeon.
 */
public enum Treasure {
  RUBY, SAPPHIRE, DIAMOND;
}