package dungeonmodel;

import java.util.Scanner;

/**
 * This is the controller for our interactive text based adventure game. The controller handles the
 * game and the functioning of the model and the user. The controller takes in the input from the
 * user on where to move and what actions to commit and parses and passes that information to the
 * model. The controller acts as a bridge between the user and the actual game to prevent the game
 * from breaking in case the user enters invalid arguments. The controller takes in the model from
 * the driver class, which acts as the view for our game and the readable and appendable, which in
 * our case seem to be System.in and System.out.
 */
public interface Controller {

  /**
   * The play game function starts the game and assigns the control to the user prompting them for
   * various moves and operations that they can run over the game. The player is supposed to travel
   * the dungeon and get out from the end cave, but they are plagued by a monster, and they must
   * hunt it down to successfully escape.
   */
  void playGame();

  /**
   * Allows the user to shoot an arrow into one of the directions at a distance of 1-5 units. The
   * arrows can travel freely through a tunnel. The user is trying to kill the monster but is able
   * to hit it if it lands in the exact location that the player intended it to be.
   *
   * @param sc takes in the scanner input, which in our case is System.in
   */
  void shoot(Scanner sc);

  /**
   * Allows the player to move in the dungeon based on the openings present in the current location
   * of the dungeon. The player can only move 1 distance at a time, and they are not allowed to make
   * invalid moves, such as trying to move north in a cave that has no north opening.
   *
   * @param sc takes in the scanner input, which in our case is System.in
   */
  void move(Scanner sc);

  /**
   * Allows the player to pick up the arrows present in the current location.
   */
  void pickupArrow();

  /**
   * Allows the player to pick up the treasure present in the current location.
   */
  void pickupTreasure();

}
