package dungeonmodel;

/**
 * The model implementation for the dungeon which creates a dungeon based on the given input by the
 * user.
 */
public class ModelImpl implements Model {

  private final Dungeon d1;

  /**
   * Starts the model and creates a dungeon based on the given input from the user.
   *
   * @param row               denotes the row numbers of the dungeon
   * @param column            denotes the column numbers of the dungeon
   * @param interconnectivity denotes the interconnectivity of the dungeon
   * @param wrapping          denotes if the dungeon is wrapping or not
   * @param cavePercentage    denotes the percentage of the dungeon having treasure
   * @param difficulty        denotes the number of monsters in the dungeon
   */
  public ModelImpl(int row, int column, int interconnectivity, boolean wrapping,
                   int cavePercentage, int difficulty) {
    if (row > 4 && column > 4 && interconnectivity >= 0 && cavePercentage >= 0
            && cavePercentage <= 100 && difficulty >= 0) {
      d1 = new DungeonImpl(row, column, interconnectivity, wrapping, cavePercentage, difficulty);
    } else {
      throw new IllegalArgumentException("Illegal arguments have been passed to the dungeon. ");
    }
  }

  /**
   * A constructor for creating the deterministic dungeon.
   *
   * @param r denotes the row number of the deterministic dungeon
   * @param c denotes the column number of the deterministic dungeon
   */
  public ModelImpl(int r, int c) {
    if (r > 4 && c > 4) {
      d1 = new DungeonImpl(r, c);
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than 4. ");
    }
  }

  @Override
  public String move(String nextMove) {
    if (nextMove != null) {
      return d1.move(nextMove);
    } else {
      throw new IllegalArgumentException("Illegal arguments have been passed to the model. ");
    }
  }

  @Override
  public void pickupTreasure() {
    d1.pickupTreasure();
  }

  @Override
  public void pickupArrows() {
    d1.pickUpArrows();
  }

  @Override
  public String shootArrow(String direction, int distance) {
    if (direction != null && distance >= 0) {
      return d1.shootArrow(direction, distance);
    } else {
      throw new IllegalArgumentException("Illegal arguments have been passed to the model. ");
    }
  }

  @Override
  public String toString() {
    return d1.toString();
  }

  @Override
  public String getCurrentLocation() {
    return d1.getPlayerLocation();
  }

  @Override
  public boolean isGameOver() {
    return d1.isGameOver();
  }

  @Override
  public String getPlayerDetails() {
    return d1.getPlayerDetails();
  }

  @Override
  public String getCaveDetails(int r, int c) {
    if (r > 0 && c > 0) {
      return d1.getCaveDetails(r, c);
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than 0. ");
    }
  }

  @Override
  public String getStart() {
    return "Start node is at row : " + d1.getStart().getRow() + " and column : "
            + d1.getStart().getColumn();
  }

  @Override
  public String getEnd() {
    return "End node is at row : " + d1.getEnd().getRow() + " and column : "
            + d1.getEnd().getColumn();
  }

  @Override
  public int getSmellCounter(int r, int c) {
    return d1.getSmellCounter(r, c);
  }

  @Override
  public int countOfCavesContainingArrow() {
    return d1.countOfCavesContainingArrow();
  }
}