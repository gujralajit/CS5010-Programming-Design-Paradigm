package dungeonmodel;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Creates a graph class to create a graph using which we can create the dungeon based on the
 * interconnectivity and wrapping properties.
 */
public class Graph implements GraphInterface {

  private final Vertex[][] allV;
  private final List<Edge> edgeList;
  private final List<Edge> adjacencyList;
  private final List<Edge> leftoverList;
  private final List<HashSet<Vertex>> listOfSets;

  /**
   * Constructor for graph using which we create the graph based on the given interconnectivity
   * and the wrapping properties.
   *
   * @param row               is the rows for the dungeon
   * @param column            is the columns for the dungeon
   * @param interconnectivity is the interconnectivity of the dungeon
   * @param wrapping          denotes if the dungeon is wrapping or not
   */
  public Graph(int row, int column, int interconnectivity, boolean wrapping) {
    if (row > 0 && column > 0 && interconnectivity >= 0) {
      edgeList = new ArrayList<>();
      adjacencyList = new ArrayList<>();
      leftoverList = new ArrayList<>();
      listOfSets = new ArrayList<>();
      allV = new Vertex[row][column];
      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          Vertex v1 = new Vertex(i, j);
          allV[i][j] = v1;
          HashSet<Vertex> h1 = new HashSet<>();
          h1.add(v1);
          listOfSets.add(h1);
        }
      }
      createEdgeList(row, column, wrapping);
      unionSet(interconnectivity);
    } else {
      throw new IllegalArgumentException("Input attributes are incorrect. ");
    }
  }

  @Override
  public void createEdgeList(int row, int column, boolean wrapping) {

    if (row > 0 && column > 0) {
      if (!wrapping) {
        for (int i = 0; i < row; i++) {
          for (int j = 0; j < column; j++) {
            if (i != row - 1 && j != column - 1) {
              edgeList.add(new Edge(allV[i][j], allV[i][j + 1]));
              edgeList.add(new Edge(allV[i][j], allV[i + 1][j]));
            } else if (i != row - 1 && j == column - 1) {
              edgeList.add(new Edge(allV[i][j], allV[i + 1][j]));
            } else if (i == row - 1 && j != column - 1) {
              edgeList.add(new Edge(allV[i][j], allV[i][j + 1]));
            }
          }
        }
      } else {
        for (int i = 0; i < row; i++) {
          for (int j = 0; j < column; j++) {
            if (i != row - 1 && j != column - 1) {
              edgeList.add(new Edge(allV[i][j], allV[i][j + 1]));
              edgeList.add(new Edge(allV[i][j], allV[i + 1][j]));
            } else if (j == column - 1) {
              if (i != row - 1) {
                edgeList.add(new Edge(allV[i][j], allV[i + 1][j]));
              } else {
                edgeList.add(new Edge(allV[i][j], allV[0][j]));
              }
              edgeList.add(new Edge(allV[i][j], allV[i][0]));
            } else if (i == row - 1) {
              edgeList.add(new Edge(allV[i][j], allV[i][j + 1]));
              edgeList.add(new Edge(allV[i][j], allV[0][j]));
            }
          }
        }
      }
    } else {
      throw new IllegalArgumentException("Row and column cannot be less than 0. ");
    }
  }

  @Override
  public void unionSet(int interconnectivity) {
    if (interconnectivity >= 0) {
      while (edgeList.size() != 0) {

        Edge e1;
        int randomNum = ThreadLocalRandom.current().nextInt(0, edgeList.size());
        e1 = edgeList.get(randomNum);
        edgeList.remove(randomNum);

        Vertex v1 = e1.getSource();
        Vertex v2 = e1.getDestination();

        int i1 = -1;
        int i2 = -1;
        HashSet<Vertex> s1 = new HashSet<>();
        HashSet<Vertex> s2 = new HashSet<>();

        for (int i = 0; i < listOfSets.size(); i++) {
          if (listOfSets.get(i).contains(v1)) {
            i1 = i;
            s1 = listOfSets.get(i1);
          }
          if (listOfSets.get(i).contains(v2)) {
            i2 = i;
            s2 = listOfSets.get(i2);
          }
        }

        if (i1 == i2) {
          leftoverList.add(e1);
        } else {
          adjacencyList.add(e1);
          if (i1 > i2) {
            listOfSets.remove(i1);
            listOfSets.remove(i2);
          } else {
            listOfSets.remove(i2);
            listOfSets.remove(i1);
          }
          HashSet<Vertex> s3 = new HashSet<>();
          s3.addAll(s1);
          s3.addAll(s2);
          listOfSets.add(s3);
        }
      }
      for (int i = 0; i < interconnectivity; i++) {
        if (leftoverList.size() == 1) {
          Edge e1 = leftoverList.get(0);
          leftoverList.remove(0);
          adjacencyList.add(e1);
          break;
        }
        int randomNum = ThreadLocalRandom.current().nextInt(0, leftoverList.size());
        Edge e1 = leftoverList.get(randomNum);
        leftoverList.remove(randomNum);
        adjacencyList.add(e1);
      }
    } else {
      throw new IllegalArgumentException("Interconnectivity has to be greater than or equal to 0.");
    }
  }

  @Override
  public List<Edge> getAdjacencyList() {
    return new ArrayList<>(adjacencyList);
  }
}
