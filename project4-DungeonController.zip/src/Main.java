import java.io.InputStreamReader;

import dungeonmodel.Controller;
import dungeonmodel.ControllerImpl;
import dungeonmodel.Model;
import dungeonmodel.ModelImpl;

/**
 * Main method to denote the driver class.
 */
public class Main {

  /**
   * Main class which is the driver for our dungeon.
   *
   * @param args inline arguments
   */
  public static void main(String[] args) {

    int row;
    int column;
    int interconnectivity;
    int cavePercentage;
    int difficulty;
    try {
      row = Integer.parseInt(args[0]);
      column = Integer.parseInt(args[1]);
      interconnectivity = Integer.parseInt(args[2]);
      cavePercentage = Integer.parseInt(args[4]);
      difficulty = Integer.parseInt(args[5]);
    } catch (NumberFormatException nfe) {
      throw new IllegalArgumentException("Illegal arguments have been passed. Please try again. ");
    }
    boolean wrapping = Boolean.parseBoolean(args[3]);

    Model model = new ModelImpl(row, column, interconnectivity, wrapping, cavePercentage,
            difficulty);

    Readable in = new InputStreamReader(System.in);
    Appendable out = System.out;

    Controller c = new ControllerImpl(model, in, out);
    c.playGame();
  }
}