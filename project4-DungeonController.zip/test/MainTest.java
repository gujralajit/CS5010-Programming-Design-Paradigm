import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.StringReader;

import dungeonmodel.Controller;
import dungeonmodel.ControllerImpl;
import dungeonmodel.Dungeon;
import dungeonmodel.DungeonImpl;
import dungeonmodel.Model;
import dungeonmodel.ModelImpl;
import dungeonmodel.Vertex;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * Testing for dungeon.
 */
public class MainTest {

  Dungeon deterministic;
  Dungeon wrapping;
  Dungeon nonWrapping;
  Dungeon d1;

  @Before
  public void setUp() {
    deterministic = new DungeonImpl(5, 5);
    wrapping = new DungeonImpl(5, 5, 6, true, 10, 0);
    nonWrapping = new DungeonImpl(5, 5, 0, false, 20, 0);
  }

  @Test
  public void testDeterministicDungeonModel() {
    assertEquals("\n  |            \n"
            + "--P--T--T--T--M--\n"
            + "              |\n"
            + "  T--T--T--T--T  \n"
            + "  |            \n"
            + "  T--T--T--T--T  \n"
            + "              |\n"
            + "  T--T--T--T--T  \n"
            + "  |            \n"
            + "  M--T--T--T--M  \n"
            + "  |            \n"
            + "\n", deterministic.toString());


    //check adjacency list size
    assertEquals(24, deterministic.getAdjacencyList().size());

    //check percentage of caves
    assertEquals(2, deterministic.countOfCavesContainingTreasure());

    //check cave to string
    assertEquals("This cave has no treasures. ",
            deterministic.getCaveDetails(0, 0));

    //check player description
    assertEquals("The player has 3 arrows currently equipped. "
                    + "The player has no treasures equipped yet. ",
            deterministic.getPlayerDetails());

    //check start location
    assertEquals("0 + 0", deterministic.getStart().getRow() + " + "
            + deterministic.getStart().getColumn());

    //check player location is same as start
    assertEquals("You are currently in a cave. Doors lead to the north, west, east. \n"
                    + "This cave has no treasures. \n"
                    + "Something smells terribly close by. ",
            deterministic.getPlayerLocation());

    //move left in wrapping
    deterministic.move("west");
    assertEquals("You are currently in a cave. Doors lead to the south, west, east. \n"
                    + "This cave has no treasures. \n"
                    + "It has 1 arrows. \n"
                    + "Something smells terribly close by. ",
            deterministic.getPlayerLocation());

    //move right in wrapping
    deterministic.move("east");
    assertEquals("You are currently in a cave. Doors lead to the north, west, east. \n"
                    + "This cave has no treasures. \n"
                    + "Something smells terribly close by. ",
            deterministic.getPlayerLocation());

    //move top
    deterministic.move("north");
    assertEquals("You are currently in a cave. Doors lead to the north, south, east. \n"
                    + "The cave has the following treasures : \n"
                    + "Ruby : 1\n"
                    + "Sapphire : 1\n"
                    + "Diamond : 1\n"
                    + "It has 1 arrows. \n"
                    + "Something smells terribly close by. ",
            deterministic.getPlayerLocation());

    //move bottom
    deterministic.move("south");
    assertEquals("You are currently in a cave. Doors lead to the north, west, east. \n"
                    + "This cave has no treasures. \n"
                    + "Something smells terribly close by. ",
            deterministic.getPlayerLocation());

    assertEquals("The player has 3 arrows currently equipped. The player has no "
                    + "treasures equipped yet. ",
            deterministic.getPlayerDetails());

    //treasure in cave before player moved in
    assertEquals("The cave has the following treasures : \n"
            + "Ruby : 1\n"
            + "Sapphire : 1\n"
            + "Diamond : 1\n"
            + "It has 1 arrows. ", deterministic.getCaveDetails(4, 0));

    //treasure with player before picking up
    assertEquals("The player has 3 arrows currently equipped. "
            + "The player has no treasures equipped yet. ", deterministic.getPlayerDetails());

    //move north
    deterministic.move("n");

    //treasure in cave after player has picked it up
    deterministic.pickupTreasure();
    deterministic.pickUpArrows();
    assertEquals("This cave has no treasures. ",
            deterministic.getCaveDetails(4, 0));

    //treasure picked up by player
    assertEquals("The player has 4 arrows currently equipped. "
            + "The player has the following treasures equipped --> \n"
            + "Ruby : 1\n"
            + "Sapphire : 1\n"
            + "Diamond : 1", deterministic.getPlayerDetails());

    assertEquals(24, nonWrapping.getAdjacencyList().size());

    assertTrue(wrapping.getShortestPath(new
                    Vertex(wrapping.getStart().getRow(), wrapping.getStart().getColumn()),
            new Vertex(wrapping.getEnd().getRow(), wrapping.getEnd().getColumn())) >= 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFailingDungeon() {
    d1 = new DungeonImpl(5, 3, 0, false, 0, 0);
    d1 = new DungeonImpl(3, 5, 0, false, 0, 0);
    d1 = new DungeonImpl(5, 5, -1, false, 0, 0);
    d1 = new DungeonImpl(5, 5, 0, true, 0, 0);
    d1 = new DungeonImpl(5, 5, 0, false, 120, 0);

    assertEquals("The player is at row : 3 and column : 0\n",
            nonWrapping.getPlayerLocation());
  }

  //every location is connected to other
  @Test
  public void testEveryLocation() {
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        for (int x = 0; x < 5; x++) {
          for (int y = 0; y < 5; y++) {
            assertTrue(wrapping.getShortestPath(new Vertex(i, j), new Vertex(x, y)) >= 0);
          }
        }
      }
    }
  }

  @Test
  public void newModelTesting() {

    //monster is at end
    int r = deterministic.getEnd().getRow();
    int c = deterministic.getEnd().getColumn();
    assertEquals(100, deterministic.getSmellCounter(r, c));

    //monster is not at start
    r = deterministic.getStart().getRow();
    c = deterministic.getStart().getColumn();
    assertNotEquals(100, deterministic.getSmellCounter(r, c));

    //monster is only in caves
    assertEquals("The cave has the following treasures : \n"
            + "Ruby : 1\n"
            + "Sapphire : 1\n"
            + "Diamond : 1\n"
            + "It has 1 arrows. ", deterministic.getCaveDetails(4, 0));

    int counter = 0;
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        if (deterministic.getSmellCounter(i, j) == 100) {
          //test monster is not in tunnels and only in caves
          assertFalse(deterministic.getCaveDetails(i, j).toLowerCase().contains("tunnel"));
          assertTrue(deterministic.getCaveDetails(i, j).toLowerCase().contains("cave"));
          counter++;
        }
      }
    }

    //test number of monsters is same as difficulty
    assertEquals(3, counter);

    //no smell for monster away from 2
    assertEquals(0, deterministic.getSmellCounter(2, 2));

    //terrible smell for monster 1 distance away
    assertEquals(4, deterministic.getSmellCounter(0, 0));

    //terrible smell for 2 monsters 2 distance away
    assertEquals(2, deterministic.getSmellCounter(4, 2));

    //pungent smell for 1 monster 1 distance away
    assertEquals(1, deterministic.getSmellCounter(0, 1));

    //test monster is not hit if distance is not accurate
    assertEquals("", deterministic.shootArrow("north", 5));

    //shoot once and get feedback
    assertEquals("You hear a monster howling in pain. \n", deterministic.shootArrow("east", 1));

    //shoot injured monster and get feedback
    assertEquals("You hear a dying monster's last cry. \n", deterministic.shootArrow("east", 1));

    //no feedback received if there is no monster or player does not hit it successfully
    assertTrue(deterministic.shootArrow("east", 1).isEmpty());

    //test smell decreases after monster dies
    assertEquals(2, deterministic.getSmellCounter(0, 0));

    //test shooting arrows not possible when 0
    assertEquals("No arrows available to the player. \n", deterministic.shootArrow("east", 1));

    //test 50% chance of surviving if monster is damaged
    assertEquals("The cave has the following treasures : \n"
            + "Ruby : 1\n"
            + "Sapphire : 1\n"
            + "Diamond : 1\n"
            + "It has 1 arrows. ", deterministic.move("north"));

    //arrow percentage in dungeon
    assertEquals(2, deterministic.countOfCavesContainingArrow());

  }

  @Test
  public void testPlayerWinning() {
    //player winning
    Model m = new ModelImpl(5, 5);
    Readable in = new StringReader("s n 1 s n 1 m n s e 1 s e 1 m e m e m e m e");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("Congratulations on winning the game! \n"
            + "You have exited the dungeon successfully. "));
  }

  @Test
  public void testMonsterEatingPlayer() {
    //player losing
    Model m = new ModelImpl(5, 5);
    Readable in = new StringReader("m n");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("The monster has eaten you. Better luck next "
            + "time!"));
  }

  @Test
  public void testInvalidControllerCommands() {
    Model m = new ModelImpl(5, 5, 5, false, 50, 0);
    Readable in = new StringReader("makeamove q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("Invalid command makeamove. Try again."));
  }

  @Test
  public void testInvalidMoveCommands() {
    Model m = new ModelImpl(5, 5, 5, false, 50, 0);
    Readable in = new StringReader("m bottom m top m left m right q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("Invalid move bottom. Try again."));
    assertTrue(out.toString().contains("Invalid move top. Try again."));
    assertTrue(out.toString().contains("Invalid move left. Try again."));
    assertTrue(out.toString().contains("Invalid move right. Try again."));
  }

  @Test
  public void testInvalidShootCommands() {
    Model m = new ModelImpl(5, 5, 5, false, 50, 0);
    Readable in = new StringReader("s n -5 s n 0 s n 7 s gg 1 s northumberland 3 q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("Illegal arguments detected for move: direction -> n "
            + "distance -> -5"));
    assertTrue(out.toString().contains("Illegal arguments detected for move: direction -> n "
            + "distance -> 0"));
    assertTrue(out.toString().contains("Illegal arguments detected for move: direction -> n "
            + "distance -> 7"));
    assertTrue(out.toString().contains("Illegal arguments detected for move: direction -> gg "
            + "distance -> 1"));
    assertTrue(out.toString().contains("Illegal arguments detected for move: direction -> "
            + "northumberland distance -> 3"));
  }

  @Test
  public void testInvalidPickupCommands() {
    Model m = new ModelImpl(5, 5, 5, false, 50, 0);
    Readable in = new StringReader("p b pick pickupb pi pickup treasures q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("Invalid command b. Try again."));
    assertTrue(out.toString().contains("Invalid command pick. Try again."));
    assertTrue(out.toString().contains("Invalid command pickupb. Try again."));
    assertTrue(out.toString().contains("Invalid command pi. Try again."));
    assertTrue(out.toString().contains("Pick up treasure or arrow? Invalid command treasures. "
            + "Try again."));
  }

  @Test
  public void testValidMoveCommands() {
    Model m = new ModelImpl(5, 5);
    Readable in = new StringReader("m e q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("Move, pickup, shoot or quit? Move where? "
            + "You are currently in a tunnel. Doors lead to the west, east."));
  }

  @Test
  public void testValidShootCommands() {
    Model m = new ModelImpl(5, 5);
    Readable in = new StringReader("s n 1 s n 1 q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("Move, pickup, shoot or quit? Enter direction in which arrow"
            + " is to be shot : Enter distance at which arrow is to be shot (1-5): "
            + "You hear a monster howling in pain."));
    assertTrue(out.toString().contains("Move, pickup, shoot or quit? Enter direction in which arrow"
            + " is to be shot : Enter distance at which arrow is to be shot (1-5): "
            + "You hear a dying monster's last cry."));
  }

  @Test
  public void testValidPickupCommands() {
    Model m = new ModelImpl(5, 5);
    Readable in = new StringReader("s n 1 s n 1 m n p a p t q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
    assertTrue(out.toString().contains("The cave has the following treasures : \n"
            + "Ruby : 1\n"
            + "Sapphire : 1\n"
            + "Diamond : 1\n"
            + "It has 1 arrows."));
    assertTrue(out.toString().contains("The player has 2 arrows currently equipped. "
            + "The player has no treasures equipped yet."));
    assertTrue(out.toString().contains("The cave has the following treasures : \n"
            + "Ruby : 1\n"
            + "Sapphire : 1\n"
            + "Diamond : 1"));
    assertTrue(out.toString().contains("The player has 2 arrows currently equipped. "
            + "The player has the following treasures equipped --> \n"
            + "Ruby : 1\n"
            + "Sapphire : 1\n"
            + "Diamond : 1"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void InvalidModelForController() {
    Model m = null;
    Readable in = new StringReader("s n 1 s n 1 m n p a p t q");
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
  }

  @Test(expected = IllegalArgumentException.class)
  public void InvalidReadableForController() {
    Model m = new ModelImpl(5, 5);
    Readable in = null;
    Appendable out = new StringBuilder();
    Controller c1 = new ControllerImpl(m, in, out);
  }

  @Test(expected = IllegalArgumentException.class)
  public void InvalidAppendableForController() {
    Model m = new ModelImpl(5, 5);
    Readable in = new StringReader("s n 1 s n 1 m n p a p t q");
    Appendable out = null;
    Controller c1 = new ControllerImpl(m, in, out);
  }

  @Test(expected = IllegalStateException.class)
  public void InvalidFailingAppendableForController() {
    Model m = new ModelImpl(5, 5);
    Readable in = new StringReader("s n 1 s n 1 m n p a p t q");
    Appendable out = new Appendable() {
      @Override
      public Appendable append(CharSequence csq) throws IOException {
        throw new IOException("testing for failing appendable");
      }

      @Override
      public Appendable append(CharSequence csq, int start, int end) throws IOException {
        throw new IOException("testing for failing appendable");
      }

      @Override
      public Appendable append(char c) throws IOException {
        throw new IOException("testing for failing appendable");
      }
    };
    Controller c1 = new ControllerImpl(m, in, out);
    c1.playGame();
  }
}