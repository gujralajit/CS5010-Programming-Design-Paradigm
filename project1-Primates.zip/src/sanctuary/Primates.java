package sanctuary;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Extends the animal class and contains primate specific functions.
 */
public interface Primates extends Animals {

  /**
   * Gets the sex of the primate.
   *
   * @return
   */
  String getSex(int id);

  /**
   * Gets the size of the primate.
   *
   * @return size
   */
  int getSize(int id);

  /**
   * Gets the approximate age of the primate.
   *
   * @return approxAge
   */
  int getApproxAge(int id);

  /**
   * Gets the favourite food of the primate from the enum.
   *
   * @return favFod
   */
  String getFavFood(int id);

  /**
   * Gets the sign of the primate, which contains the name, sex, and the favfood.
   *
   * @return sign
   */
  String getSign(int id);

  /**
   * Adds a new primate to the sanctuary.
   */
  void addPrimate(String name, String species, Sex s1, int size, int weight, int approxAge,
                  FavFood f1);

  /**
   * Gets the orimate details of all animals in the sanctuary.
   */
  HashMap<Integer, ArrayList<String>> getPrimateDetails();
}
