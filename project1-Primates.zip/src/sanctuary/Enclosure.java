package sanctuary;

/**
 * Enclosure handles the methods used specifically for the class.
 */
public interface Enclosure extends Housing {

  int getSpaceLeft(int id);
  /**
   * Adds a new enclosure to the sanctuary.
   */

  void addEnclosure();

}
