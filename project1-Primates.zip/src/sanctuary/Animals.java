package sanctuary;

/**
 * Contains all the common functions to get all animals details.
 */
public interface Animals {

  /**
   * Gets the name of the animal.
   *
   * @return name
   */
  String getName(int id);

  /**
   * Gets the species of the animal.
   *
   * @return species
   */
  String getSpecies(int id);


  /**
   * Gets the weight of the animal.
   *
   * @return weight
   */
  int getWeight(int id);
}
