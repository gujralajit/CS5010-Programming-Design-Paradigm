package sanctuary;

/**
 * Defines the favourite food types of the primates.
 */
public enum FavFood {
  EGGS, FRUITS, INSECTS, LEAVES, NUTS, SEEDS, TREE_SAP;
}
