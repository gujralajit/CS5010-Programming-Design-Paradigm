package sanctuary;

/**
 * Housing contains the common functions for both isolation and housing.
 */

public interface Housing {

  /**
   * Gets the housingID for the cage.
   *
   * @return the ID.
   */
  int getHousingID(int id);

  /**
   * Moves the primate to a specific housing.
   */
  void moveToHousing(int id, String house);

  /**
   * Removes the primate from the housing.
   */
  void removeFromHousing(int id);

  /**
   * Gets the space left in the housing.
   *
   * @return the space left.
   */
  int getSpaceLeft(int id);
}
