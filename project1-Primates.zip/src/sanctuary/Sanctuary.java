package sanctuary;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * It has the sanctuary specific functions to get the list of al monkeys, shopping list
 * and species housed.
 */
public interface Sanctuary {

  /**
   * Gets the details of where each species is stored in housing.
   *
   * @return
   */
  String speciesHoused(String species);

  /**
   * Gets the list of all monkeys in alphabetical order with details about where they are stored.
   *
   * @return
   */
  HashMap<Integer, ArrayList<String>> listOfMonkeys();

  /**
   * Gets the shopping list for all the favourite foods of the primates and their weight based on
   * the size of the monkeys.
   *
   * @return
   */
  String shoppingList();

  /**
   * Creates a new sanctuary with given number of isolations and space for given troops of monkeys.
   *
   * @param numberOfIsolations denotes number of isolations in the sanctuary
   * @param troopsOfMonkeys    denotes the space for troops of monkeys in the sanctuary
   */
  void createSanctuary(int numberOfIsolations, int troopsOfMonkeys);

}
