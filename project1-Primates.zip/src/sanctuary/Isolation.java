package sanctuary;

/**
 * It has the specific methods to get isolation specific details like primate details.
 */
public interface Isolation extends Housing {

  /**
   * Adds a new isolation to the sanctuary.
   */
  void addIsolation();
}
