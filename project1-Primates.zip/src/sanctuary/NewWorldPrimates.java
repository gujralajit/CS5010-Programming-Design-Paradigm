package sanctuary;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * The NewWorldPrimates class takes all the housing, animal and sanctuary details and creates a
 * sanctuary based on the number of isolations and number of troops provided by the user.
 */
public class NewWorldPrimates implements Isolation, Enclosure, Primates, Sanctuary {

  private int primateId = 0;
  private int isoSize;
  private int enclSize;
  private HashMap<Integer, ArrayList<String>> primateDetails = new HashMap<>();
  private HashMap<Integer, Integer> housingDetails = new HashMap<>();
  private HashMap<Integer, String> housingList = new HashMap<>();
  private HashMap<Integer, Integer> housingSpace = new HashMap<>();
  private HashMap<Integer, String> enclosureSpecies = new HashMap<>();

  @Override
  public String getName(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return primateDetails.get(id).get(0);
  }

  @Override
  public String getSpecies(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return primateDetails.get(id).get(1);
  }

  @Override
  public int getWeight(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return Integer.parseInt(primateDetails.get(id).get(4));
  }

  @Override
  public int getSpaceLeft(int id) {
    if (housingSpace.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return housingSpace.get(id);
  }

  @Override
  public void addEnclosure() {
    enclSize++;
  }

  @Override
  public int getHousingID(int id) {
    if (housingDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return housingDetails.get(id);
  }

  @Override
  public void moveToHousing(int id, String house) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    if (house.equals("ISO")) {
      for (int i = 1; i <= housingList.size(); i++) {
        if (housingList.get(i) != null && housingList.get(i).equals("ISO")
                && getSpaceLeft(i) == -1) {
          if (housingDetails.containsKey(id)) {
            housingDetails.replace(id, i);
            housingSpace.replace(i, 0);
          } else if (isoSize > 0) {
            housingDetails.put(id, i);
            housingSpace.replace(i, 0);
            isoSize--;
          }
        }
      }
    } else if (house.equals("ENCL")) {
      String species = getSpecies(id);
      for (int i = 1; i <= housingList.size(); i++) {
        if (housingList.get(i) != null && housingList.get(i).equals("ENCL")
                && enclosureSpecies.get(i).equals(species) && getSpaceLeft(i) > 0) {
          if (housingDetails.containsKey(id)) {
            housingDetails.replace(id, i);
            int size = getSize(id);
            int mul = 0;
            if (size < 10) {
              mul = 1;
            } else if (size > 10 && size < 20) {
              mul = 5;
            } else if (size > 20) {
              mul = 10;
            }
            if (getSpaceLeft(i) - mul >= 0) {
              housingSpace.replace(i, getSpaceLeft(id) - mul);
            }
          } else if (enclSize > 0) {
            housingDetails.put(id, i);
            housingSpace.put(i, 0);
          }
        }
      }
    } else {
      housingDetails.put(id, 0);
    }
  }

  @Override
  public void removeFromHousing(int id) {
    if (housingDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    housingDetails.replace(id, 0);
  }

  @Override
  public void addIsolation() {
    isoSize++;
  }

  @Override
  public String getSex(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return primateDetails.get(id).get(2);
  }

  @Override
  public int getSize(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return Integer.parseInt(primateDetails.get(id).get(3));
  }

  @Override
  public int getApproxAge(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return Integer.parseInt(primateDetails.get(id).get(5));
  }

  @Override
  public String getFavFood(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    return primateDetails.get(id).get(6).toString();
  }

  @Override
  public String getSign(int id) {
    if (primateDetails.get(id) == null) {
      throw new IllegalArgumentException("The supplied id is not part of the sanctuary. ");
    }
    StringBuilder sb = new StringBuilder();
    sb.append("Name : " + primateDetails.get(id).get(0) + "\nSex : " + primateDetails.get(id).get(2)
            + "\nFavourite Food : " + primateDetails.get(id).get(6));
    return sb.toString();
  }

  @Override
  public void addPrimate(String name, String species, Sex s1, int size, int weight, int approxAge,
                         FavFood f1) {
    ArrayList<String> al1 = new ArrayList<String>();
    al1.add(name);
    al1.add(species);
    al1.add(s1.toString());
    al1.add(Integer.toString(size));
    al1.add(Integer.toString(weight));
    al1.add(Integer.toString(approxAge));
    al1.add(f1.toString());
    primateDetails.put(++primateId, al1);

    moveToHousing(primateId, "ISO");
  }

  @Override
  public HashMap<Integer, ArrayList<String>> getPrimateDetails() {
    return primateDetails;
  }

  @Override
  public String speciesHoused(String spec) {
    int iso1 = 0;
    int encl1 = 0;
    int oth1 = 0;
    for (int i = 1; i <= primateDetails.size(); i++) {
      if (getSpecies(i).equals(spec)) {
        int houseId = housingDetails.get(i);
        String info = housingList.get(houseId);
        if (info.equals("ISO")) {
          iso1++;
        } else if (info.equals("ENCL")) {
          encl1++;
        } else if (info.equals("OTHER")) {
          oth1++;
        }
      }
    }
    if (iso1 == 0 && encl1 == 0 && oth1 == 0) {
      return (spec + " is not currently being housed in the sanctuary. ");
    } else if (iso1 > 0 && encl1 > 0) {
      return (spec + " is currently being housed in both isolation and enclosure. ");
    } else if (iso1 > 0 && encl1 <= 0) {
      return (spec + " is currently being housed only in isolation. ");
    } else if (iso1 <= 0 && encl1 > 0) {
      return (spec + " is currently being housed only in enclosure. ");
    } else {
      return (spec + " is currently being housed out of sanctuary. ");
    }
  }

  //https://www.javacodeexamples.com/java-hashmap-get-first-key-value-without-iterating-example/2290
  //https://stackoverflow.com/questions/26230225/hashmap-getting-first-key-value
  @Override
  public HashMap<Integer, ArrayList<String>> listOfMonkeys() {

    Map<Integer, String> hm1 = new HashMap<>();
    for (int i = 1; i <= primateDetails.size(); i++) {
      hm1.put(i, primateDetails.get(i).get(0));
    }
    hm1 = sortByValue(hm1, true);

    HashMap<Integer, ArrayList<String>> hm2 = new HashMap<>();

    for (int i = 0; i < hm1.size(); i++) {
      ArrayList al1 = new ArrayList();
      al1.add(hm1.values().toArray()[i]);
      String house = housingList.get(i + 1);
      al1.add(house);
      hm2.put(i, al1);
    }
    return hm2;
  }

  //https://stackoverflow.com/questions/8119366/sorting-hashmap-by-values

  /**
   * The sortByValue method takes the input of the primate details and sorts it by name in
   * alphabetical order which can be used to print the list.
   *
   * @param unsortMap takes the unsorted map
   * @param order     takes the sorting order (ascending or descending)
   * @return returns the map in a sorted order
   */
  private static Map<Integer, String> sortByValue(Map<Integer, String> unsortMap, final boolean
          order) {
    List<Map.Entry<Integer, String>> list = new LinkedList<>(unsortMap.entrySet());

    // Sorting the list based on values
    list.sort((o1, o2) -> order ? o1.getValue().compareTo(o2.getValue()) == 0
            ? o1.getKey().compareTo(o2.getKey())
            : o1.getValue().compareTo(o2.getValue()) : o2.getValue().compareTo(o1.getValue()) == 0
            ? o2.getKey().compareTo(o1.getKey())
            : o2.getValue().compareTo(o1.getValue()));
    return list.stream().collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (a, b)
        -> b, LinkedHashMap::new));
  }


  @Override
  public String shoppingList() {
    int[] food = {0, 0, 0, 0, 0, 0, 0};
    int mul = 0;
    String favf1 = "";
    for (int i = 1; i <= primateDetails.size(); i++) {
      favf1 = getFavFood(i);
      int size1 = getSize(i);
      if (size1 < 10) {
        mul = 100;
      } else if (size1 >= 10 && size1 < 20) {
        mul = 250;
      } else if (size1 >= 20) {
        mul = 500;
      }

      if (favf1.equals("EGGS")) {
        food[0] += mul;
      } else if (favf1.equals("FRUITS")) {
        food[1] += mul;
      } else if (favf1.equals("INSECTS")) {
        food[2] += mul;
      } else if (favf1.equals("LEAVES")) {
        food[3] += mul;
      } else if (favf1.equals("NUTS")) {
        food[4] += mul;
      } else if (favf1.equals("SEEDS")) {
        food[5] += mul;
      } else if (favf1.equals("TREE_SAP")) {
        food[6] += mul;
      }
    }

    favf1 = "Shopping list is as folows : \n1. Eggs : " + food[0] + "\n2. Fruits : " + food[1]
            + "\n3. Insects : " + food[2] + "\n4. Leaves : " + food[3] + "\n5. Nuts : " + food[4]
            + "\n6. Seeds : " + food[5] + "\n7. Tree Sap : " + food[6];
    return favf1;
  }

  @Override
  public void createSanctuary(int n, int m) {
    if (isoSize <= n) {
      isoSize = n;
      for (int i = 1; i <= isoSize; i++) {
        housingSpace.put(i, -1);
        housingList.put(i, "ISO");
        isoSize--;
      }
    }
    if (enclSize <= m) {
      enclSize = m;
      for (int i = n + 1; i <= enclSize + n; i++) {
        housingSpace.put(i, 100);
        housingList.put(i, "ENCL");
        enclosureSpecies.put(i, "");
        enclSize--;
      }
    }
  }
}
