package sanctuary;

/**
 * Defines the housing status of the primate, with other being if the animal is currently not part
 * of the sanctuary.
 */
public enum Status {
  ISO, ENCL, OTHER;
}
