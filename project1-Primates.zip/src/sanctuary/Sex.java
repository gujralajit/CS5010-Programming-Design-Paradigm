package sanctuary;

/**
 * Defines the sex of the primate, having other for animals that don't have a sex.
 */
public enum Sex {
  MALE, FEMALE, OTHER;
}
