import java.util.ArrayList;
import java.util.HashMap;

import sanctuary.NewWorldPrimates;
import sanctuary.Sex;
import sanctuary.FavFood;

/**
 * This is the driver class to take all the test cases and run them to print the appropriate output
 * of different scenarios.
 */
public class Main {
  static NewWorldPrimates p1 = new NewWorldPrimates();

  /**
   * Creating a public statsic void main to print the various runs of the program.
   *
   * @param args arguments
   */
  public static void main(String[] args) {
    p1.createSanctuary(20, 10);
    p1.addPrimate("Steve", "Drill", Sex.MALE, 5, 100, 3, FavFood.NUTS);
    p1.addPrimate("Rob", "Drill", Sex.FEMALE, 10, 250, 2, FavFood.FRUITS);
    p1.addPrimate("Dave", "Drill", Sex.MALE, 15, 300, 5, FavFood.EGGS);
    p1.addPrimate("Nate", "Drill", Sex.MALE, 20, 500, 8, FavFood.SEEDS);
    p1.addPrimate("Greg", "Drill", Sex.FEMALE, 25, 700, 12, FavFood.INSECTS);
    p1.addPrimate("Kevin", "Drill", Sex.MALE, 3, 45, 15, FavFood.LEAVES);
    p1.addPrimate("Gary", "Drill", Sex.FEMALE, 7, 78, 10, FavFood.INSECTS);
    p1.addPrimate("Jared", "Drill", Sex.MALE, 11, 200, 11, FavFood.NUTS);
    p1.addPrimate("Tim", "Drill", Sex.MALE, 18, 450, 2, FavFood.SEEDS);
    p1.addPrimate("Clark", "Drill", Sex.FEMALE, 35, 1000, 3, FavFood.TREE_SAP);

    HashMap<Integer, ArrayList<String>> hm1 = new HashMap<>();
    hm1 = p1.getPrimateDetails();
    System.out.println("The primate details are as follows : ");
    for (int i = 1; i <= hm1.size(); i++) {
      System.out.println(hm1.get(i));
    }
    String s = p1.shoppingList();
    System.out.println("\n" + s);

    hm1 = p1.listOfMonkeys();
    System.out.println("\nThe list of monkeys is as follows : " + hm1);

    s = p1.speciesHoused("Squirrel");
    System.out.println("\n" + s);
  }
}
