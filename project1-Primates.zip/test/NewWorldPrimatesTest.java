import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;

import sanctuary.FavFood;
import sanctuary.NewWorldPrimates;
import sanctuary.Sex;

import static org.junit.Assert.assertEquals;

/**
 * The NewWorldPrimatesTest class is used to run the default JUnit test cases for all of the
 * defined functions.
 */
public class NewWorldPrimatesTest {

  NewWorldPrimates p1 = new NewWorldPrimates();

  @Before
  public void setUp() {
    p1.createSanctuary(10, 10);
    p1.addPrimate("x", "abc", Sex.MALE, 10, 20, 10, FavFood.FRUITS);
    p1.addPrimate("c", "xyz", Sex.FEMALE, 20, 500, 20, FavFood.INSECTS);
    p1.addPrimate("b", "xyz", Sex.OTHER, 5, 50, 5, FavFood.EGGS);
    p1.addPrimate("d", "abc", Sex.FEMALE, 3, 100, 7, FavFood.NUTS);
    p1.addPrimate("a", "xyz", Sex.MALE, 15, 23, 11, FavFood.TREE_SAP);
  }

  @Test
  public void getName() {
    assertEquals("x", p1.getName(1));
  }

  @Test
  public void getSpecies() {
    assertEquals("abc", p1.getSpecies(1));
  }

  @Test
  public void getWeight() {
    assertEquals(20, p1.getWeight(1));
  }

  @Test
  public void getHousingID() {
    assertEquals(1, p1.getHousingID(1));
  }

  @Test
  public void moveToHousing() {
    p1.moveToHousing(1, "OTHER");
    assertEquals(1, p1.getHousingID(1));
  }

  @Test
  public void removeFromHousing() {
    p1.removeFromHousing(1);
    assertEquals(0, p1.getHousingID(1));
  }

  @Test
  public void getSex() {
    assertEquals("MALE", p1.getSex(1));
  }

  @Test
  public void getSize() {
    assertEquals(10, p1.getSize(1));
  }

  @Test
  public void getApproxAge() {
    assertEquals(10, p1.getApproxAge(1));
  }

  @Test
  public void getFavFood() {
    assertEquals("FRUITS", p1.getFavFood(1));
  }

  @Test
  public void getSign() {
    String s1 = p1.getSign(1);
    assertEquals("", s1);
  }

  @Test
  public void addPrimate() {
    p1.addPrimate("jkl", "abc", Sex.MALE, 10, 20, 10, FavFood.FRUITS);
    assertEquals("FRUITS", p1.getFavFood(6));
  }

  @Test
  public void speciesHoused() {
    String s1 = p1.speciesHoused("abc");
    assertEquals("", s1);
  }

  @Test
  public void listOfMonkeys() {
    HashMap<Integer, ArrayList<String>> hm1 = p1.listOfMonkeys();
    assertEquals("", hm1.values());
  }

  @Test
  public void shoppingList() {
    String s = p1.shoppingList();
    assertEquals("", s);
  }

  @Test
  public void getPrimateDetails() {
    assertEquals("", p1.getPrimateDetails());
  }
}