# Readme

1. **About**
    * Creating a program to create a library of primates which are currently being stored in the sanctuary.
    * The primates are housed in isolations (singular) or in enclosures (multiple). 
    * Some common features like the animal's favourite food, sex, and status have been stored in an enum. 
    * The sanctuary currently houses only primates but has the ability to expand in the futiure. 
   

2. **List of Features**
   * Ability to create a new sanctuary. 
   * Ability to add new primates. 
   * Ability to move primate from it's housing. 
   * Display a list of monkeys housed in the sanctuary. 
   * Create a shopping list based on the size and favourite food of the monkey. 
   * Create a sign for a specific monkey based on it's name, sex and favourite food.
   * Check if a particular species is housed in the sanctuary or not. 
   * Remove a specific monkey from the housing and move to another sanctuary if required. 


3. **How To Run**
   * Run the project1-Primates.jar file to see the output. 
   * No external input from the user is needed to run the jar file. 


4. **How to Use the Program**
   * There are various methods designed to implement the functionality of the program. 
   * We can get the various getters to get the attributes of the primates like name, sex, approxage, etc. 
   

5. **Description of Examples**
   * Run 1 contains the basic functionality of the code. 
   * Run 2 contains a scenario where the isolations are finished and the primate is added to an enclosure. 
   * Run 3 contains a scenario where the primate is being moved from the isolation to the enclosure.
   * We can also see the primate details, shopping list, list of monkeys in alphabetical order, and if a specific species is being housed in the sanctuary or not. 


6. **Design/Model Changes**
   * Added an interface housing which isolation and enclosure both implement to share common functionalities. 
   * Added an interface animals which the primate now implements to allow for a possibility for new types of animals to be added in the sanctuary later. 
   * Added an interface sanctuary which has the functionality to create shopping lists and ability to look for specific species. 
   * Added a newWorldPrimates class which implements all of these interfaces and takes up the isolation and enclosures required to create the sanctuary. 


7. **Assumptions**
   * Assuming that the user has all the primate details available since we are not adding any default values. 
   * Assuming that the user knows the IDs of the primates added which they can check with the given functionality.
   * Assuming that the user is aware of the enumerations for favourite food and sex. 


8. **Limitations**
   * List of monkeys can show incorrect housing status sometimes. 


9. **Citations**
   * https://www.geeksforgeeks.org/java-util-hashmap-in-java-with-examples/
   * https://www.javacodeexamples.com/java-hashmap-get-first-key-value-without-iterating-example/2290
   * https://stackoverflow.com/questions/26230225/hashmap-getting-first-key-value
   * https://stackoverflow.com/questions/8119366/sorting-hashmap-by-values
