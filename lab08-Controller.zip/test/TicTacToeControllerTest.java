import static org.junit.Assert.assertEquals;

import tictactoe.TicTacToe;
import tictactoe.TicTacToeConsoleController;
import tictactoe.TicTacToeController;
import tictactoe.TicTacToeModel;

import java.io.InputStreamReader;
import java.io.StringReader;

import org.junit.Test;

/**
 * Test cases for the tic tac toe controller, using mocks for readable and
 * appendable.
 */
public class TicTacToeControllerTest {

  // Providing this shell for you to write your
  // own test cases for the TicTacToe controller
  // You DO NOT NEED to implement tests for the provided model

  // TODO: Implement your own tests cases for the controller

  @Test(expected = IllegalStateException.class)
  public void testFailingAppendable() {
    // Testing when something goes wrong with the Appendable
    // Here we are passing it a mock of an Appendable that always fails
    TicTacToe m = new TicTacToeModel();
    StringReader input = new StringReader("2 2 1 1 3 3 1 2 1 3 2 3 2 1 3 1 3 2");
    Appendable gameLog = new FailingAppendable();
    TicTacToeController c = new TicTacToeConsoleController(input, gameLog);
    c.playGame(m);

    assertEquals("Enter move at: ", m.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullModel() {
    Readable input = new InputStreamReader(System.in);
    Appendable output = System.out;
    new TicTacToeConsoleController(input, output).playGame(null);
  }

  @Test
  public void testInvalidInputForRow() {
    Readable input = new StringReader("asdf q");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            "Not a valid number: asdf\n" +
            "Game quit! Ending game state:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n", output.toString());
  }

  @Test
  public void testInvalidInputForColumn() {
    Readable input = new StringReader("1 asdf q");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            "Not a valid number: asdf\n" +
            "Game quit! Ending game state:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n", output.toString());
  }

  @Test
  public void testOutOfBoundInputForRow() {
    Readable input = new StringReader("5 3 q");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            "Not a valid move: 5, 3\n" +
            "Game quit! Ending game state:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n", output.toString());
  }

  @Test
  public void testOutOfBoundInputForColumn() {
    Readable input = new StringReader("3 5 q");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            "Not a valid move: 3, 5\n" +
            "Game quit! Ending game state:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n", output.toString());
  }

  @Test
  public void testQuitForRow() {
    Readable input = new StringReader("2 2 q");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for O:\n" +
            "Game quit! Ending game state:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   |  \n", output.toString());
  }

  @Test
  public void testQuitForColumn() {
    Readable input = new StringReader("2 2 3 q");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for O:\n" +
            "Game quit! Ending game state:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   |  \n", output.toString());
  }

  @Test
  public void testValidInvalidSpaceOccupied() {
    Readable input = new StringReader("2 2 3 3 1 1 2 2 5 5 q");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for O:\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   | O\n" +
            "Enter a move for X:\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   | O\n" +
            "Enter a move for O:\n" +
            "Not a valid move: 2, 2\n" +
            "Not a valid move: 5, 5\n" +
            "Game quit! Ending game state:\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   | X |  \n" +
            "-----------\n" +
            "   |   | O\n", output.toString());
  }

  @Test
  public void testPlayerXWinning() {
    Readable input = new StringReader("1 1 3 3 1 2 3 2 1 3");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for O:\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   | O\n" +
            "Enter a move for X:\n" +
            " X | X |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   | O\n" +
            "Enter a move for O:\n" +
            " X | X |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | O | O\n" +
            "Enter a move for X:\n" +
            " X | X | X\n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | O | O\n" +
            "Game is over! X wins.\n", output.toString());
  }

  @Test
  public void testPlayerOWinning() {
    Readable input = new StringReader("1 1 3 3 1 2 3 2 2 1 3 1");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for O:\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   | O\n" +
            "Enter a move for X:\n" +
            " X | X |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   | O\n" +
            "Enter a move for O:\n" +
            " X | X |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   | O | O\n" +
            "Enter a move for X:\n" +
            " X | X |  \n" +
            "-----------\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   | O | O\n" +
            "Enter a move for O:\n" +
            " X | X |  \n" +
            "-----------\n" +
            " X |   |  \n" +
            "-----------\n" +
            " O | O | O\n" +
            "Game is over! O wins.\n", output.toString());
  }

  @Test
  public void testTieGame() {
    Readable input = new StringReader("1 1 1 2 2 1 3 1 1 3 2 2 2 3 3 3 3 2");
    Appendable output = new StringBuilder();
    TicTacToeController t1 = new TicTacToeConsoleController(input, output);
    t1.playGame(new TicTacToeModel());
    assertEquals("   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for O:\n" +
            " X | O |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for X:\n" +
            " X | O |  \n" +
            "-----------\n" +
            " X |   |  \n" +
            "-----------\n" +
            "   |   |  \n" +
            "Enter a move for O:\n" +
            " X | O |  \n" +
            "-----------\n" +
            " X |   |  \n" +
            "-----------\n" +
            " O |   |  \n" +
            "Enter a move for X:\n" +
            " X | O | X\n" +
            "-----------\n" +
            " X |   |  \n" +
            "-----------\n" +
            " O |   |  \n" +
            "Enter a move for O:\n" +
            " X | O | X\n" +
            "-----------\n" +
            " X | O |  \n" +
            "-----------\n" +
            " O |   |  \n" +
            "Enter a move for X:\n" +
            " X | O | X\n" +
            "-----------\n" +
            " X | O | X\n" +
            "-----------\n" +
            " O |   |  \n" +
            "Enter a move for O:\n" +
            " X | O | X\n" +
            "-----------\n" +
            " X | O | X\n" +
            "-----------\n" +
            " O |   | O\n" +
            "Enter a move for X:\n" +
            " X | O | X\n" +
            "-----------\n" +
            " X | O | X\n" +
            "-----------\n" +
            " O | X | O\n" +
            "Game is over! Tie game.\n", output.toString());
  }
}