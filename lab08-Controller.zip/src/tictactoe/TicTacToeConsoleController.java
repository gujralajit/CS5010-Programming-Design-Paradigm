package tictactoe;

import java.io.IOException;
import java.util.Scanner;

/**
 * This starter files is for students to implement a console controller for the
 * TicTacToe MVC assignment.
 */
public class TicTacToeConsoleController implements TicTacToeController {

  private final Appendable out;
  private final Scanner scan;

  /**
   * Constructor for the controller.
   *
   * @param in  the source to read from
   * @param out the target to print to
   */
  public TicTacToeConsoleController(Readable in, Appendable out) {
    if (in == null || out == null) {
      throw new IllegalArgumentException("Readable and Appendable can't be null");
    }
    this.out = out;
    scan = new Scanner(in);
  }

  @Override
  public void playGame(TicTacToe m) {
    if (m != null) {
      try {
        Player player;
        out.append(m.toString()).append("\n");
        while (!m.isGameOver()) {

          player = m.getTurn();
          String element = "";
          out.append("Enter a move for ").append(player.toString()).append(":\n");

          int row;
          int column;

          while (true) {
            while (true) {
              element = scan.next();
              if (element.equalsIgnoreCase("q")) {
                out.append("Game quit! Ending game state:\n").append(m.toString()).append("\n");
                return;
              }

              try {
                row = Integer.parseInt(element);
                break;
              } catch (IllegalArgumentException e) {
                out.append("Not a valid number: ").append(element).append("\n");
              }
            }

            while (true) {
              element = scan.next();
              if (element.equalsIgnoreCase("q")) {
                out.append("Game quit! Ending game state:\n").append(m.toString()).append("\n");
                return;
              }

              try {
                column = Integer.parseInt(element);
                break;
              } catch (IllegalArgumentException e) {
                out.append("Not a valid number: ").append(element).append("\n");
              }
            }

            try {
              m.move(row - 1, column - 1);
              break;
            } catch (IllegalArgumentException e) {
              out.append("Not a valid move: ").append(String.valueOf(row)).append(", ")
                      .append(String.valueOf(column)).append("\n");
            }
          }
          if (!m.isGameOver()) {
            out.append(m.toString()).append("\n");
          }
        }
        if (m.isGameOver()) {
          out.append(m.toString()).append("\n").append("Game is over! ");
          player = m.getWinner();
          if (player != null) {
            out.append(player.toString()).append(" wins.\n");
          } else {
            out.append("Tie game.\n");
          }
        }
      } catch (IOException ioe) {
        throw new IllegalStateException("Append failed", ioe);
      }
    } else {
      throw new IllegalArgumentException("Model cannot be null. ");
    }
  }
}
