package weather;

/**
 * To calculate how the real world feels as compared to the predicted temperature based on the
 * readings from weather stations called Stevenson Shelters.
 */
public final class StevensonReading implements WeatherReading {

  private final double airTemp;
  private final double dewTemp;
  private final double windSpeed;
  private final double totalRain;
  private StringBuilder sb = new StringBuilder("Reading: T = ");

  /**
   * Calculating the stevenson reading based on measures like temperature, dew point, wind speed,
   * rain.
   *
   * @param airTemp   has the air temperature
   * @param dewTemp   has the ew point temperature
   * @param windSpeed has the wind speed
   * @param totalRain has the total rain received
   * @throws IllegalArgumentException for any unexpected argument
   */
  public StevensonReading(double airTemp, double dewTemp, double windSpeed, double totalRain)
          throws IllegalArgumentException {

    this.airTemp = airTemp;
    sb.append((int) Math.round(airTemp) + ", D = ");
    this.dewTemp = dewTemp;
    this.windSpeed = windSpeed;
    this.totalRain = totalRain;

    if ((int) dewTemp > (int) airTemp) {
      throw new IllegalArgumentException("The dew temp cannot be greater than air temp. ");
    }
    sb.append((int) Math.round(dewTemp) + ", v = ");

    if ((int) windSpeed < 0) {
      throw new IllegalArgumentException("The wind speed cannot be negative. ");
    }
    sb.append((int) Math.round(windSpeed) + ", rain = ");
    if ((int) totalRain < 0) {
      throw new IllegalArgumentException("The total rain cannot be negative. ");
    }
    sb.append((int) Math.round(totalRain));
  }

  @Override
  public int getTemperature() {
    return (int) Math.round(airTemp);
  }

  @Override
  public int getDewPoint() {
    return (int) Math.round(dewTemp);
  }

  @Override
  public int getWindSpeed() {
    return (int) Math.round(windSpeed);
  }

  @Override
  public int getTotalRain() {
    return (int) Math.round(totalRain);
  }

  @Override
  public int getRelativeHumidity() {
    final double relativeHumidity = Math.round(5 * dewTemp - 5 * airTemp + 100);
    return (int) Math.round(relativeHumidity);
  }

  @Override
  public int getHeatIndex() {

    final double c1 = -8.78469475556;
    final double c2 = 1.61139411;
    final double c3 = 2.33854883889;
    final double c4 = -0.14611605;
    final double c5 = -0.012308094;
    final double c6 = -0.0164248277778;
    final double c7 = 0.002211732;
    final double c8 = 0.00072546;
    final double c9 = -0.000003582;

    final double relativeHumidity = 5 * dewTemp - 5 * airTemp + 100;
    final double heatIndex = c1 + c2 * airTemp + c3 * relativeHumidity
            + c4 * airTemp * relativeHumidity
            + c5 * Math.pow(airTemp, 2) + c6 * Math.pow(relativeHumidity, 2)
            + c7 * Math.pow(airTemp, 2) * relativeHumidity
            + c8 * airTemp * Math.pow(relativeHumidity, 2)
            + c9 * Math.pow(airTemp, 2) * Math.pow(relativeHumidity, 2);
    return (int) Math.round(heatIndex);
  }

  @Override
  public int getWindChill() {
    //converting air temp from celsius to fahrenheit
    final double airTempFar = (airTemp * 1.8) + 32;
    final double windChill = (35.74) + (0.6215 * airTempFar) - (35.75) * (Math.pow(windSpeed, 0.16))
            + (0.4275) * (airTempFar) * (Math.pow(windSpeed, 0.16));
    return (int) Math.round(windChill);
  }

  /**
   * Implementing toString method to display the inputs.
   *
   * @return string containing air temp, dew temp, wind speed, total rain
   */
  public String toString() {
    return sb.toString();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof WeatherReading)) {
      return false;
    }

    WeatherReading that = (WeatherReading) o;
    return this.getTemperature() == that.getTemperature();
  }

  @Override
  public int hashCode() {
    return Integer.hashCode(this.getTemperature());
  }
}
