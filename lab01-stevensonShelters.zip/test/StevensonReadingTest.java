import org.junit.Before;
import org.junit.Test;

import weather.StevensonReading;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Creating test class for Stevenson Reading.
 */
public class StevensonReadingTest {

  private StevensonReading sr;

  @Before
  public void setUp() throws Exception {
    sr = new StevensonReading(30, 25, 7, 15);
  }

  @Test
  public void getTemperature() {
    assertEquals(sr.getTemperature(), 30);
  }

  @Test
  public void getDewPoint() {
    assertEquals(sr.getDewPoint(), 25);
  }

  @Test
  public void getWindSpeed() {
    assertEquals(sr.getWindSpeed(), 7);
  }

  @Test
  public void getTotalRain() {
    assertEquals(sr.getTotalRain(), 15);
  }

  @Test
  public void getRelativeHumidity() {
    assertEquals(sr.getRelativeHumidity(), 75);
  }

  @Test
  public void getHeatIndex() {
    assertEquals(sr.getHeatIndex(), 36);
  }

  @Test
  public void getWindChill() {
    assertEquals(sr.getWindChill(), 91);
  }

  @Test
  public void testEquals() {
    assertTrue(sr.equals(sr));
    assertTrue(sr.equals(new StevensonReading(30, 25, 7, 15)));
    assertFalse(sr.equals(new StevensonReading(31, 24, 8, 14)));
  }

  @Test
  public void testHashCode() {
    assertEquals(Integer.hashCode(sr.getTemperature()),
            new StevensonReading(30, 25, 7, 15).hashCode());
  }

  @Test
  public void testToString() {
    assertEquals(sr.toString(), "Reading: T = 30, D = 25, v = 7, rain = 15");
  }
}