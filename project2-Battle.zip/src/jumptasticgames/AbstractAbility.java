package jumptasticgames;

/**
 * An abstract class to encapsulate the ability interface has been created which has the common code
 * to calculate the values of the abilities and getting their values.
 */
public abstract class AbstractAbility implements Abilities {

  private GetRandomValue r1 = new GetRandomValue();

  @Override
  public int assignAbility() {

    int num1 = calcValue();
    int num2 = calcValue();
    int num3 = calcValue();
    int num4 = calcValue();

    if (num1 <= num2 && num1 <= num3 && num1 <= num4) {
      return num2 + num3 + num4;
    } else if (num2 <= num1 && num2 <= num3 && num2 <= num4) {
      return num1 + num3 + num4;
    } else if (num3 <= num2 && num3 <= num1 && num3 <= num4) {
      return num2 + num1 + num4;
    } else {
      return num2 + num3 + num1;
    }
  }

  @Override
  public int calcValue() {

    int num = r1.getRand(1, 6);
    while (num == 1) {
      num = r1.getRand(1, 6);
    }
    return num;
  }

  @Override
  public int getStrength() {
    return 0;
  }

  @Override
  public int getConstitution() {
    return 0;
  }

  @Override
  public int getDexterity() {
    return 0;
  }

  @Override
  public int getCharisma() {
    return 0;
  }
}
