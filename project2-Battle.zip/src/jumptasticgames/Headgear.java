package jumptasticgames;

/**
 * This creates a gear of the headgear type. A player can equip only 1 headgear at a time. The
 * headgear gear affects the constitution of the player. It is possible that the headgear can
 * negatively affect the player.
 */
public class Headgear extends AbstractGear {

  private final int multiplier;
  private final String name;
  private final int constitution;

  /**
   * Creates a constructor for the headgear class to assign the name and multiplier.
   *
   * @param name       of the headgear
   * @param multiplier denotes if headgear affects positively or negatively
   */
  public Headgear(String name, int multiplier) {
    if (name != null && (multiplier == -1 || multiplier == 1)) {
      this.name = name;
      this.multiplier = multiplier;
    } else {
      throw new IllegalArgumentException("Arguments entered incorrectly");
    }
    constitution = assignAbility();
  }

  @Override
  public int getConstitution() {
    return multiplier * constitution;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public boolean isHead(Headgear o) {
    return true;
  }

  @Override
  public boolean compare(Object o) {
    if (o instanceof AbstractGear) {
      AbstractGear a = (AbstractGear) o;
      return a.isHead(this);
    }
    return false;
  }

  @Override
  public int getMultiplier() {
    return multiplier;
  }
}
