package jumptasticgames;

/**
 * The weapon interface contains all the common methods and functionalities that are exhibited by
 * the weapon. This interface gets us the damage dealt by the weapon and the name of that specific
 * weapon. The damage dealt is a random value based on the damage range of the specific weapon.
 */
public interface Weapon {

  /**
   * This returns the damage dealt in this turn by that weapon. It has a specific range denoted
   * by the type of the weapon.
   *
   * @return damage dealt by the weapon
   */
  int damageDone();

  /**
   * This returns the name of the weapon.
   *
   * @return name of weapon
   */
  String getName();
}
