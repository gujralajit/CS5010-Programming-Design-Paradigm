package jumptasticgames;

/**
 * Created an abstract gear class to encapsulate and handle double dispatch among the various gear
 * types.
 */
public abstract class AbstractGear extends AbstractAbility {

  /**
   * Checks if the gear is of headgear type.
   *
   * @param o takes in headgear
   * @return if it is of type headgear
   */
  public boolean isHead(Headgear o) {
    return false;
  }

  /**
   * Checks if the gear is of footwear type.
   *
   * @param o takes in footwear
   * @return if it is of type footwear
   */
  public boolean isFoot(Footwear o) {
    return false;
  }

  /**
   * Checks if the gear is of belt type.
   *
   * @param o takes in belt
   * @return if it is of type belt
   */
  public boolean isBelt(Belt o) {
    return false;
  }

  /**
   * Checks if the gear is of potion type.
   *
   * @param o takes in potion
   * @return if it is of type potion
   */
  public boolean isPotion(Potion o) {
    return false;
  }

  /**
   * To compare the given object with its gear type.
   *
   * @param o takes in any object
   * @return if that object is of a specific gear type
   */
  public boolean compare(Object o) {
    return false;
  }

  public int getMultiplier() {
    return 0;
  }
}
