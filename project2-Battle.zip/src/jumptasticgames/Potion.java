package jumptasticgames;

/**
 * This creates a gear of the potion type. There is no limit to the number of potions that the
 * player can consume. A potion affects only 1 ability of the player. It is possible that the potion
 * can negatively affect the player.
 */
public class Potion extends AbstractGear {

  private final int multiplier;
  private final String name;
  private final int strength;
  private final int constitution;
  private final int dexterity;
  private final int charisma;

  /**
   * Creates a constructor for the potion class to assign the name and multiplier.
   *
   * @param name       of the potion
   * @param multiplier denotes if potion affects positively or negatively
   */
  public Potion(String name, int multiplier) {
    if (name != null && (multiplier == -1 || multiplier == 1)) {
      this.name = name;
      this.multiplier = multiplier;
    } else {
      throw new IllegalArgumentException("Arguments entered incorrectly");
    }
    GetRandomValue r1 = new GetRandomValue();
    int assign = r1.getRand(1, 4);
    if (assign == 1) {
      strength = assignAbility();
      constitution = 0;
      dexterity = 0;
      charisma = 0;
    } else if (assign == 2) {
      constitution = assignAbility();
      strength = 0;
      dexterity = 0;
      charisma = 0;
    } else if (assign == 3) {
      dexterity = assignAbility();
      constitution = 0;
      strength = 0;
      charisma = 0;
    } else {
      charisma = assignAbility();
      constitution = 0;
      dexterity = 0;
      strength = 0;
    }
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public int getStrength() {
    return multiplier * strength;
  }

  @Override
  public int getConstitution() {
    return multiplier * constitution;
  }

  @Override
  public int getDexterity() {
    return multiplier * dexterity;
  }

  @Override
  public int getCharisma() {
    return multiplier * charisma;
  }

  @Override
  public boolean isPotion(Potion o) {
    return true;
  }

  @Override
  public boolean compare(Object o) {
    if (o instanceof AbstractGear) {
      AbstractGear a = (AbstractGear) o;
      return a.isPotion(this);
    }
    return false;
  }

  @Override
  public int getMultiplier() {
    return multiplier;
  }
}
