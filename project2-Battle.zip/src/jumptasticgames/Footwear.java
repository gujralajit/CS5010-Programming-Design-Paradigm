package jumptasticgames;

/**
 * This creates a gear of the footwear type. Footwear gears come in pairs and a player can equip
 * only 1 footwear at a time. The footwear gear affects the dexterity of the player. It is possible
 * that the footwear can negatively affect the player.
 */
public class Footwear extends AbstractGear {

  private final int multiplier;
  private final String name;
  private final int dexterity;

  /**
   * Creates a constructor for the footwear class to assign the name and multiplier.
   *
   * @param name       of the footwear
   * @param multiplier denotes if footwear affects positively or negatively
   */
  public Footwear(String name, int multiplier) {
    if (name != null && (multiplier == -1 || multiplier == 1)) {
      this.name = name;
      this.multiplier = multiplier;
    } else {
      throw new IllegalArgumentException("Arguments entered incorrectly");
    }
    dexterity = assignAbility();
  }

  @Override
  public int getDexterity() {
    return multiplier * dexterity;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public boolean isFoot(Footwear o) {
    return true;
  }

  @Override
  public boolean compare(Object o) {
    if (o instanceof AbstractGear) {
      AbstractGear a = (AbstractGear) o;
      return a.isFoot(this);
    }
    return false;
  }

  @Override
  public int getMultiplier() {
    return multiplier;
  }
}
