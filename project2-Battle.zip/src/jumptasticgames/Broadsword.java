package jumptasticgames;

/**
 * Creates a broadsword type weapon. This is a good medium weapon that deals 6 to 10 damage per
 * turn.
 */
public class Broadsword extends AbstractWeapon {

  private final String name;
  private GetRandomValue r1;

  /**
   * Created a constructor to assign the name to the broadsword.
   *
   * @param name is the name of the broadsword
   */
  public Broadsword(String name) {
    if (name != null) {
      this.name = name;
    } else {
      throw new IllegalArgumentException("Name cannot be null");
    }
    r1 = new GetRandomValue();
  }

  @Override
  public int damageDone() {
    return r1.getRand(6, 10);
  }

  @Override
  public boolean isBroadsword(Broadsword o) {
    return true;
  }

  @Override
  public String getName() {
    return name;
  }
}
