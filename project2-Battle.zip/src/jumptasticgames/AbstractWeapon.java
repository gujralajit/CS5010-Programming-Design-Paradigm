package jumptasticgames;

/**
 * Created an abstract weapon class to encapsulate and handle double dispatch among the various
 * weapon types.
 */
public abstract class AbstractWeapon implements Weapon {

  /**
   * Checks if the weapon is of two handed type.
   *
   * @param o takes in two handed
   * @return if it is of type two handed
   */
  public boolean isTwoHanded(TwoHanded o) {
    return false;
  }

  /**
   * Checks if the weapon is of flail type.
   *
   * @param o takes in flail
   * @return if it is of type flail
   */
  public boolean isFlail(Flail o) {
    return false;
  }

  /**
   * Checks if the weapon is of Broadsword type.
   *
   * @param o takes in Broadsword
   * @return if it is of type Broadsword
   */
  public boolean isBroadsword(Broadsword o) {
    return false;
  }

  /**
   * Checks if the weapon is of Katana type.
   *
   * @param o takes in Katana
   * @return if it is of type Katana
   */
  public boolean isKatana(Katana o) {
    return false;
  }

  /**
   * Checks if the weapon is of Axe type.
   *
   * @param o takes in Axe
   * @return if it is of type Axe
   */
  public boolean isAxe(Axe o) {
    return false;
  }

  /**
   * To compare the given object with its weapon type.
   *
   * @param o takes in any object
   * @return if that object is of a specific weapon type
   */
  public boolean compare(Object o) {
    return false;
  }
}
