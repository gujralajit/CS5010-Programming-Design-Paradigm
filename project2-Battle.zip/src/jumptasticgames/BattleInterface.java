package jumptasticgames;

import java.util.List;

/**
 * The Battle interface is used to define all the available methods and how these can be used to
 * create a battle scenario. The battle interface has the ability to generate different types of
 * gears and weapons and also assign them to the players from a randomly generated pool of 20 items.
 * This also allows the battle to be played and to evaluate if a winner has been declared or not.
 */
public interface BattleInterface {

  /**
   * Creates a random name for the weapons and the gear to be created in a battle arena, each time a
   * battle takes place.
   *
   * @return the random name to be assigned to the gear/weapon
   */
  String createRandomName();

  /**
   * Creates a random number of weapons upto 50, at least 1 of each type (axe, broadsword, flail,
   * katana, two handed) and assigns them random names based on their type (names for katanas start
   * with initial characters being 'kat', 'brd', 'two', 'fla', 'axe').
   */
  void createWeapons();

  /**
   * Creates a random number of footwear (at least 5), out of which 25% are declared to diminish the
   * abilities of the player and assigns them random names with first 4 characters being 'foot'.
   */
  void createFootwear();

  /**
   * Creates a random number of headgear (at least 5), out of which 25% are declared to diminish the
   * abilities of the player and assigns them random names with first 4 characters being 'head'.
   */
  void createHeadgear();

  /**
   * Creates a random number of potions (at least 15), out of which 25% are declared to diminish the
   * abilities of the player and assigns them random names with first 3 characters being 'pot'.
   */
  void createPotions();

  /**
   * Creates a random number of belts (at least 15), out of which 25% are declared to diminish the
   * abilities of the player and assigns them random names with first 4 characters being 'belt'.
   */
  void createBelts();

  /**
   * Assigns a random weapon from the list of randomly generated weapons (which contains at least 1
   * of each weapon type). The player has no input here and is randomly assigned 1 weapon.
   *
   * @param p1 is the player who is being assigned a random weapon
   */
  void assignWeapon(Player p1);

  /**
   * Creates a random list of 20 items which are being assigned to the player. It can contain at min
   * 0 of every type of gear, and the gear being added to the list has also been randomized.
   *
   * @return the list of 20 gears from which the player has to equip
   */
  List<AbstractGear> createRandomBag();

  /**
   * The random list of 20 items obtained from yhe above method are used to equip them to the player
   * and the player has no choice over which items to pick and equip. All the available potions are
   * consumed, all belts which have sum of units less than 10 are equipped, and the first available
   * headgear and footwear is equipped.
   *
   * @param p1 is the player who is equipping the gears
   */
  void assignGear(Player p1);

  /**
   * This is used to calculate the striking ability of the player for this specific turn. If the
   * player attacks or misses is dependent on this. This takes in the strength of the attacker,
   * the strength of the gears, and a random number between 1 and 10.
   *
   * @param p1 is the player who is attacking
   * @return the striking power of the attacker for this turn
   */
  int getStrikingPower(Player p1);

  /**
   * This is used to calculate the avoidance ability of the player for this specific turn. If the
   * player attacks or misses is dependent on this. This takes in dexterity of the defender, the
   * dexterity of the gears, and a random number between 1 and 6.
   *
   * @param p1 is the player who is defending
   * @return the avoidance ability of the defender for this turn
   */
  int getAvoidanceAbility(Player p1);

  /**
   * This calculates the potential striking damage of the attacker. This takes into account the
   * player's strength, and the damage done by the weapon. This also takes into account if the
   * player has teh adequate stats to equip their current weapon, and reduces the damage from the
   * weapon if the player is weaker than expected.
   *
   * @param p1 is the player who is attacking
   * @return the potential striking damage of the attacker for this turn
   */
  int getPotentialStrikingDamage(Player p1);

  /**
   * This takes in both players and calls the damage and avoidance methods and calculates if the
   * attacker actually swings their sword and hits or misses the defender.
   *
   * @param p1 player who is the attacker
   * @param p2 player who is the defender
   * @return if the attacker successfully executes their attack or not
   */
  boolean doesAttack(Player p1, Player p2);

  /**
   * This calculates the actual damage that the attacker does to the defender based on the
   * potential striking damage of the attacker and the constitution of the defender.
   *
   * @param p1 player who is the attacker
   * @param p2 player who is the defender
   * @return the actual damage that attacker deals to the defender
   */
  int actualDamage(Player p1, Player p2);

  /**
   * This checks the charisma of both the players and decides who plays first on the basis of that
   * player having higher charisma and dazzling their opponent.
   *
   * @param p1 player1 to check who plays first
   * @param p2 player2 to check who plays first
   * @return the player that plays first
   */
  Player getFirst(Player p1, Player p2);

  /**
   * This method does the battle for this specific turn for both players abd takes in the
   * aforementioned methods to calculate the damage dealt and if attack is successful or not.
   *
   * @param p1 player who is the attacker
   * @param p2 player who is the defender
   */
  void doBattle(Player p1, Player p2);

  /**
   * This method does the actual damage and deducts the health from the defender if the attack is
   * successful.
   *
   * @param p1 player who is the attacker
   * @param p2 player who is the defender
   */
  void doDamage(Player p1, Player p2);

  /**
   * This method checks if the battle is over based on the current health of the players and the
   * number of turns calculated. If either of the player's health gets below 0 or the turns have
   * completed, it ends the battle.
   *
   * @param p1 player who is the attacker
   * @param p2 player who is the defender
   * @return if the battle is over or not
   */
  boolean isBattleOver(Player p1, Player p2);

  /**
   * This method checks to see if a winner has been declared, and if so, who is the winner of the
   * battle.
   *
   * @param p1 one of the players
   * @param p2 the other player
   * @return who the winner of the battle is, null if it is a draw
   */
  Player getWinner(Player p1, Player p2);

  /**
   * This method initiates a rematch by resetting the current health of the players to their max
   * health and also resetting the counter of the turn, resetting the state of the battle,  so that
   * a rematch can be played between the two players.
   */
  void rematch();

  /**
   * This method calculates whose turn it is and return the player as a result.
   *
   * @return the player whose turn it is
   */
  Player getTurn(Player p1, Player p2);

  /**
   * This method sorts the list of gears that are currently equipped by the player in alphabetical
   * order sorted from head to toe.
   *
   * @return
   */
  List<String> sortList(Player p1);
}
