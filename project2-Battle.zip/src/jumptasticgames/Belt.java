package jumptasticgames;

/**
 * This creates a gear of the belt type. Belts can be equipped by the player based on their size.
 * Small belts consume 1 unit, medium belts consume 2 units, and large belts consume 4 unites.
 * A player can equip upto 10 units of belt. A belt can affect upto 2 abilities of the user.
 */
public class Belt extends AbstractGear {

  private final int multiplier;
  private final int units;
  private final String name;
  private final Size size;
  private final int strength;
  private final int constitution;
  private final int dexterity;
  private final int charisma;

  /**
   * Creates a constructor for the belt class to assign the name, size and multiplier.
   *
   * @param name       of the belt
   * @param size       of the belt
   * @param multiplier denotes if belt affects positively or negatively
   */
  public Belt(String name, Size size, int multiplier) {
    if (name != null && size != null && (multiplier == -1 || multiplier == 1)) {
      this.name = name;
      this.size = size;
      this.multiplier = multiplier;
    } else {
      throw new IllegalArgumentException("Arguments entered incorrectly");
    }
    GetRandomValue r1 = new GetRandomValue();
    if (size.toString().equals("SMALL")) {
      this.units = 1;
    } else if (size.toString().equals("MEDIUM")) {
      this.units = 2;
    } else {
      this.units = 4;
    }

    if (r1.getRand(1, 2) == 1) {
      int assign = r1.getRand(1, 4);
      if (assign == 1) {
        strength = assignAbility();
        constitution = 0;
        dexterity = 0;
        charisma = 0;
      } else if (assign == 2) {
        constitution = assignAbility();
        strength = 0;
        dexterity = 0;
        charisma = 0;
      } else if (assign == 3) {
        dexterity = assignAbility();
        constitution = 0;
        strength = 0;
        charisma = 0;
      } else {
        charisma = assignAbility();
        constitution = 0;
        dexterity = 0;
        strength = 0;
      }
    } else {
      int assign1 = r1.getRand(1, 4);
      int assign2 = r1.getRand(1, 3);
      if (assign1 == 1) {
        if (assign2 == 1) {
          strength = assignAbility();
          constitution = assignAbility();
          dexterity = 0;
          charisma = 0;

        } else if (assign2 == 2) {
          strength = assignAbility();
          dexterity = assignAbility();
          constitution = 0;
          charisma = 0;
        } else {
          strength = assignAbility();
          charisma = assignAbility();
          dexterity = 0;
          constitution = 0;
        }
      } else if (assign1 == 2) {
        if (assign2 == 1) {
          constitution = assignAbility();
          strength = assignAbility();
          dexterity = 0;
          charisma = 0;
        } else if (assign2 == 2) {
          constitution = assignAbility();
          dexterity = assignAbility();
          strength = 0;
          charisma = 0;
        } else {
          constitution = assignAbility();
          charisma = assignAbility();
          dexterity = 0;
          strength = 0;
        }
      } else if (assign1 == 3) {
        if (assign2 == 1) {
          dexterity = assignAbility();
          constitution = assignAbility();
          strength = 0;
          charisma = 0;
        } else if (assign2 == 2) {
          dexterity = assignAbility();
          strength = assignAbility();
          constitution = 0;
          charisma = 0;
        } else {
          dexterity = assignAbility();
          charisma = assignAbility();
          strength = 0;
          constitution = 0;
        }
      } else {
        if (assign2 == 1) {
          charisma = assignAbility();
          constitution = assignAbility();
          strength = 0;
          dexterity = 0;
        } else if (assign2 == 2) {
          charisma = assignAbility();
          strength = assignAbility();
          constitution = 0;
          dexterity = 0;
        } else {
          charisma = assignAbility();
          strength = assignAbility();
          constitution = 0;
          dexterity = 0;
        }
      }
    }
  }

  /**
   * Gets the units of the belt based on it's size.
   *
   * @return the units required by the belt
   */
  public int getUnits() {
    return units;
  }

  /**
   * Gets the size of the belt as defined while initializing.
   *
   * @return the size of the belt
   */
  public Size getSize() {
    return size;
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public int getStrength() {
    return multiplier * strength;
  }

  @Override
  public int getConstitution() {
    return multiplier * constitution;
  }

  @Override
  public int getDexterity() {
    return multiplier * dexterity;
  }

  @Override
  public int getCharisma() {
    return multiplier * charisma;
  }

  @Override
  public boolean isBelt(Belt o) {
    return true;
  }

  @Override
  public boolean compare(Object o) {
    if (o instanceof AbstractGear) {
      AbstractGear a = (AbstractGear) o;
      return a.isBelt(this);
    }
    return false;
  }

  @Override
  public int getMultiplier() {
    return multiplier;
  }
}
