package jumptasticgames;

/**
 * This class creates a player object and assigns random abilities of strength, dexterity, charisma,
 * constitution. The sum of these abilities is the max health of the player. The player has some
 * gears assigned to it and a weapon which can be used to attack.
 */
public class Player extends AbstractAbility {

  private final int strength;
  private final int constitution;
  private final int dexterity;
  private final int charisma;
  private final int maxHealth;
  private final String name;
  private Footwear f1;
  private Headgear h1;
  private Belt[] b1;
  private int beltUnits;
  private int beltNum;
  private Potion[] p1;
  private int potNum;
  private AbstractWeapon w1;
  private int currentHealth;

  /**
   * Created a constructor for the player to assign the abilities when it enters the battle and
   * the given name of the player.
   *
   * @param name of the player
   */
  public Player(String name) {
    if (name != null) {
      this.name = name;
    } else {
      throw new IllegalArgumentException("Name entered cannot be null");
    }
    this.strength = assignAbility();
    this.constitution = assignAbility();
    this.dexterity = assignAbility();
    this.charisma = assignAbility();
    maxHealth = getMaxHealth();
    currentHealth = maxHealth;

    f1 = null;
    h1 = null;
    b1 = new Belt[10];
    beltUnits = 10;
    beltNum = 0;
    p1 = new Potion[20];
    potNum = 0;
    w1 = null;
  }

  /**
   * Created parametrized constructor for player to pass skewed values of abilities for testing.
   *
   * @param name         of the player
   * @param strength     of the player
   * @param constitution of the player
   * @param dexterity    of the player
   * @param charisma     of the player
   */
  public Player(String name, int strength, int constitution, int dexterity, int charisma) {
    if (name != null && strength != 0 && constitution != 0 && dexterity != 0 && charisma != 0) {
      this.strength = strength;
      this.constitution = constitution;
      this.dexterity = dexterity;
      this.charisma = charisma;
      this.name = name;
    } else {
      throw new IllegalArgumentException("Arguments are incorrect");
    }
    maxHealth = getMaxHealth();
    currentHealth = maxHealth;

    f1 = null;
    h1 = null;
    b1 = new Belt[10];
    beltUnits = 10;
    beltNum = 0;
    p1 = new Potion[20];
    potNum = 0;
    w1 = null;
  }

  @Override
  public int getStrength() {
    return strength;
  }

  @Override
  public int getConstitution() {
    return constitution;
  }

  @Override
  public int getDexterity() {
    return dexterity;
  }

  @Override
  public int getCharisma() {
    return charisma;
  }

  /**
   * Gets the max health of the user which is the sum of its 4 abilities and the sum of the
   * abilities of the gears equipped by the player.
   *
   * @return the max health of the player
   */
  public int getMaxHealth() {
    currentHealth = maxHealth + getGearStrength() + getGearConstitution() + getGearDexterity()
            + getGearCharisma();
    return strength + constitution + dexterity + charisma + getGearStrength()
            + getGearConstitution() + getGearDexterity() + getGearCharisma();
  }

  /**
   * Gets the current health of the player which is reduced when it takes damage in battle.
   *
   * @return the current health of the player
   */
  public int getCurrentHealth() {
    return currentHealth;
  }

  /**
   * Sets the current health of the player based on the damage taken in battle.
   *
   * @param health is set as the current health of the player
   */
  public void setCurrentHealth(int health) {
    currentHealth = health;
  }

  /**
   * Assigns a footwear to the player. A player can only equip 1 footwear at a time.
   *
   * @param f is the footwear assigned to the player
   */
  public void setFootwear(Footwear f) {
    f1 = f;
  }

  /**
   * Gets the footwear worn by the player.
   *
   * @return the footwear worn by the player
   */
  public Footwear getFootwear() {
    return f1;
  }

  /**
   * Assigns a headgear to the player. A player can only equip 1 headgear at a time.
   *
   * @param h is the headgear assigned to the player
   */
  public void setHeadgear(Headgear h) {
    h1 = h;
  }

  /**
   * Gets the headgear worn by the player.
   *
   * @return the headgear worn by the player
   */
  public Headgear getHeadgear() {
    return h1;
  }

  /**
   * Assigns belt to the player if the units required to equip the belt are free.
   *
   * @param b is the belt assigned to the player.
   */
  public void setBelt(Belt b) {

    if (b != null && beltUnits >= b.getUnits()) {
      beltUnits -= b.getUnits();
      b1[beltNum] = b;
      beltNum++;
    }
  }

  /**
   * Returns the belt equipped by the user.
   *
   * @param beltNumber is the number of the belt that is worn by the user
   * @return the belt worn on that position for the player
   */
  public Belt getBelt(int beltNumber) {
    if (beltNumber >= 0 && beltNumber <= b1.length) {
      return b1[beltNumber];
    }
    return null;
  }

  /**
   * This gives the number of belts currently worn by the player.
   *
   * @return number of belts worn by player
   */
  public int getBeltNumber() {
    return beltNum;
  }

  /**
   * Assigns potion to the player.
   *
   * @param p is the potion assigned to the player.
   */
  public void setPotion(Potion p) {
    p1[potNum++] = p;
  }

  /**
   * Returns the potion equipped by the user.
   *
   * @param potionNumber is the number of the potion that is consumed by the user
   * @return the potion consumed in that position for the player
   */
  public Potion getPotion(int potionNumber) {
    return p1[potionNumber];
  }

  /**
   * This gives the number of potions currently consumed by the player.
   *
   * @return number of potions consumed by player
   */
  public int getPotionNumber() {
    return potNum;
  }

  /**
   * Assigns a weapon to the player.
   *
   * @param w is assigned to the player
   */
  public void setWeapon(AbstractWeapon w) {
    w1 = w;
  }

  /**
   * Gets the weapon currently equipped by the player.
   *
   * @return weapon equipped by the player
   */
  public AbstractWeapon getWeapon() {
    return w1;
  }

  /**
   * Gets the sum of strength of all gears equipped by the player.
   *
   * @return sum of gear strength
   */
  public int getGearStrength() {

    int gearStrength = 0;
    if (b1 != null) {
      for (Belt belt : b1) {
        if (belt != null) {
          gearStrength += belt.getStrength();
        }
      }
    }
    if (p1 != null) {
      for (Potion potion : p1) {
        if (potion != null) {
          gearStrength += potion.getStrength();
        }
      }
    }
    return gearStrength;
  }

  /**
   * Gets the sum of constitution of all gears equipped by the player.
   *
   * @return sum of gear constitution
   */
  public int getGearConstitution() {

    int gearConstitution = 0;
    if (h1 != null) {
      gearConstitution += getHeadgear().getConstitution();
    }
    if (b1 != null) {
      for (Belt belt : b1) {
        if (belt != null) {
          gearConstitution += belt.getConstitution();
        }
      }
    }
    if (p1 != null) {
      for (Potion potion : p1) {
        if (potion != null) {
          gearConstitution += potion.getConstitution();
        }
      }
    }
    return gearConstitution;
  }

  /**
   * Gets the sum of dexterity of all gears equipped by the player.
   *
   * @return sum of gear dexterity
   */
  public int getGearDexterity() {

    int gearDexterity = 0;
    if (f1 != null) {
      gearDexterity += getFootwear().getDexterity();
    }
    if (b1 != null) {
      for (Belt belt : b1) {
        if (belt != null) {
          gearDexterity += belt.getDexterity();
        }
      }
    }
    if (p1 != null) {
      for (Potion potion : p1) {
        if (potion != null) {
          gearDexterity += potion.getDexterity();
        }
      }
    }
    return gearDexterity;
  }

  /**
   * Gets the sum of charisma of all gears equipped by the player.
   *
   * @return sum of gear charisma
   */
  public int getGearCharisma() {

    int gearCharisma = 0;
    if (b1 != null) {
      for (Belt belt : b1) {
        if (belt != null) {
          gearCharisma += belt.getCharisma();
        }
      }
    }
    if (p1 != null) {
      for (Potion potion : p1) {
        if (potion != null) {
          gearCharisma += potion.getCharisma();
        }
      }
    }
    return gearCharisma;
  }

  @Override
  public String getName() {
    return name;
  }
}