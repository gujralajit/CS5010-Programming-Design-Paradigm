package jumptasticgames;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * The battler class creates an arena for the players to battle. This battle takes in 2 player.
 * Once the players enter the arena, they are assigned random abilities and given an option to fight
 * bare handed, equip weapons, equip gears, and an option to rematch at the end of the battle.
 * The arena creates random weapons and assigns any weapon to a player when it is requested. The
 * player has no choice over which weapon they are being assigned. The arena also gives an option
 * to equip gear to the players. The arena creates a random bag of 20 gears containing various
 * types of headgear, footwear, belts and potions. The player has to equip all possible gears that
 * the arena assigns even if it negatively impacts the player. When a rematch is initiated, the
 * players' health is restored, and they restart the match with same weapons and gears equipped.
 */
public class Battler implements BattleInterface {

  private GetRandomValue r1;
  private int turn;
  private ArrayList<AbstractWeapon> weaponList;
  private ArrayList<Headgear> headGearList;
  private ArrayList<Footwear> footWearList;
  private ArrayList<Potion> potionList;
  private ArrayList<Belt> beltList;

  /**
   * Creates a constructor for the battle arena and create empty lists for the gears and weapons.
   */
  public Battler() {
    r1 = new GetRandomValue();
    turn = 0;
    weaponList = new ArrayList<AbstractWeapon>();
    headGearList = new ArrayList<Headgear>();
    footWearList = new ArrayList<Footwear>();
    potionList = new ArrayList<Potion>();
    beltList = new ArrayList<Belt>();
  }

  //https://www.baeldung.com/java-random-string
  @Override
  public String createRandomName() {
    int leftLimit = 97;
    int rightLimit = 122;
    int targetStringLength = r1.getRand(1, 6);
    Random random = new Random();
    StringBuilder buffer = new StringBuilder(targetStringLength);
    for (int i = 0; i < targetStringLength; i++) {
      int randomLimitedInt = leftLimit + (int)
              (random.nextFloat() * (rightLimit - leftLimit + 1));
      buffer.append((char) randomLimitedInt);
    }
    return buffer.toString();
  }

  @Override
  public void createWeapons() {
    int random = r1.getRand(1, 9);
    for (int i = 0; i < random; i++) {
      Katana k1 = new Katana("kat-" + createRandomName());
      weaponList.add(k1);

      Broadsword b1 = new Broadsword("brd-" + createRandomName());
      weaponList.add(b1);

      TwoHanded t1 = new TwoHanded("two-" + createRandomName());
      weaponList.add(t1);

      Axe a1 = new Axe("axe-" + createRandomName());
      weaponList.add(a1);

      Flail f1 = new Flail("fla-" + createRandomName());
      weaponList.add(f1);
    }
  }

  @Override
  public void createFootwear() {

    int random = r1.getRand(5, 20);
    for (int i = 0; i < random; i++) {
      int mul = 1;
      if (i % 5 == 0) {
        mul = -1;
      }
      Footwear f1 = new Footwear("foot-" + createRandomName(), mul);
      footWearList.add(f1);
    }
  }

  @Override
  public void createHeadgear() {

    int random = r1.getRand(5, 20);
    for (int i = 0; i < random; i++) {
      int mul = 1;
      if (i % 5 == 0) {
        mul = -1;
      }
      Headgear f1 = new Headgear("head-" + createRandomName(), mul);
      headGearList.add(f1);
    }
  }

  @Override
  public void createPotions() {

    int random = r1.getRand(15, 45);
    for (int i = 0; i < random; i++) {
      int mul = 1;
      if (i % 5 == 0) {
        mul = -1;
      }
      Potion f1 = new Potion("pot-" + createRandomName(), mul);
      potionList.add(f1);
    }
  }

  @Override
  public void createBelts() {

    int random = r1.getRand(15, 45);
    for (int i = 1; i <= random; i++) {
      int mul = 1;
      if (i - 1 % 5 == 0) {
        mul = -1;
      }
      Size s1 = Size.SMALL;
      if (i % 3 == 0) {
        s1 = Size.MEDIUM;
      } else if (i % 8 == 0) {
        s1 = Size.LARGE;
      }
      Belt f1 = new Belt("belt-" + createRandomName(), s1, mul);
      beltList.add(f1);
    }
  }

  @Override
  public void assignWeapon(Player p1) {
    if (p1 != null) {
      p1.setWeapon(weaponList.get(r1.getRand(0, weaponList.size() - 1)));
    } else {
      throw new IllegalArgumentException("Player cannot be null");
    }
  }

  @Override
  public List<AbstractGear> createRandomBag() {

    ArrayList<AbstractGear> randomGearList = new ArrayList<>();

    int count = 0;
    for (int i = 0; i <= r1.getRand(0, 4); i++) {
      randomGearList.add(headGearList.get(r1.getRand(0, headGearList.size() - 1)));
      count++;
    }
    for (int i = 0; i <= r1.getRand(0, 4); i++) {
      randomGearList.add(footWearList.get(r1.getRand(0, footWearList.size() - 1)));
      count++;
    }
    int max = count;
    for (int i = 0; i <= r1.getRand(0, 15 - max); i++) {
      randomGearList.add(beltList.get(r1.getRand(0, beltList.size() - 1)));
      count++;
    }
    max = count;
    for (int i = r1.getRand(0, 4); i <= 20 - max; i++) {
      randomGearList.add(potionList.get(r1.getRand(0, potionList.size() - 1)));
      count++;
    }
    ArrayList<AbstractGear> randomGearList1 = new ArrayList<>();
    randomGearList1.addAll(randomGearList);
    return randomGearList1;
  }

  @Override
  public void assignGear(Player p1) {

    if (p1 != null) {
      List<AbstractGear> randomGearList = createRandomBag();
      for (int i = 0; i < randomGearList.toArray().length; i++) {
        if (randomGearList.get(i).compare(headGearList.get(1)) && p1.getHeadgear() == null) {
          p1.setHeadgear((Headgear) randomGearList.get(i));
        } else if (randomGearList.get(i).compare(footWearList.get(1)) && p1.getFootwear() == null) {
          p1.setFootwear((Footwear) randomGearList.get(i));
        } else if (randomGearList.get(i).compare(beltList.get(1))) {
          p1.setBelt((Belt) randomGearList.get(i));
        } else if (randomGearList.get(i).compare(potionList.get(1))) {
          p1.setPotion((Potion) randomGearList.get(i));
        }
      }
    } else {
      throw new IllegalArgumentException("Player cannot be null");
    }
  }

  @Override
  public int getStrikingPower(Player p1) {

    if (p1 != null) {
      int strikePow = 0;
      strikePow += p1.getStrength();
      strikePow += p1.getGearStrength();
      strikePow += r1.getRand(1, 9);
      return strikePow;
    } else {
      throw new IllegalArgumentException("Player cannot be null");
    }
  }

  @Override
  public int getAvoidanceAbility(Player p1) {

    if (p1 != null) {
      int avoidAbility = 0;
      avoidAbility += p1.getDexterity();
      avoidAbility += p1.getGearDexterity();
      avoidAbility += r1.getRand(1, 5);
      return avoidAbility;
    } else {
      throw new IllegalArgumentException("Player cannot be null");
    }
  }

  @Override
  public int getPotentialStrikingDamage(Player p1) {

    if (p1 != null) {
      int potStrikeDmg = 0;
      potStrikeDmg += p1.getStrength();
      if (p1.getWeapon() != null) {
        if (p1.getWeapon().compare(new TwoHanded("yo")) && p1.getStrength() <= 14) {
          potStrikeDmg += 0.5 * p1.getWeapon().damageDone();
        } else if (p1.getWeapon().compare(new Flail("yo")) && p1.getDexterity() <= 14) {
          potStrikeDmg += 0.5 * p1.getWeapon().damageDone();
        } else {
          potStrikeDmg += p1.getWeapon().damageDone();
        }
      }
      return potStrikeDmg;
    } else {
      throw new IllegalArgumentException("Player cannot be null");
    }
  }

  @Override
  public boolean doesAttack(Player p1, Player p2) {

    if (p1 != null && p2 != null) {
      return getStrikingPower(p1) > getAvoidanceAbility(p2);
    } else {
      throw new IllegalArgumentException("Players cannot be null");
    }
  }

  @Override
  public int actualDamage(Player p1, Player p2) {

    if (p1 != null && p2 != null) {
      return getPotentialStrikingDamage(p1) - p2.getConstitution();
    } else {
      throw new IllegalArgumentException("Players cannot be null");
    }
  }

  @Override
  public Player getFirst(Player p1, Player p2) {

    if (p1 != null && p2 != null) {
      if (p1.getCharisma() + p1.getGearCharisma() >= p2.getCharisma() + p2.getGearCharisma()) {
        return p1;
      } else {
        return p2;
      }
    } else {
      throw new IllegalArgumentException("Players cannot be null");
    }
  }

  @Override
  public void doBattle(Player p1, Player p2) {

    if (p1 != null && p2 != null) {
      if (turn % 2 == 0) {
        doDamage(p1, p2);
        doDamage(p2, p1);
      } else {
        doDamage(p2, p1);
        doDamage(p1, p2);
      }
    } else {
      throw new IllegalArgumentException("Players cannot be null");
    }
  }

  @Override
  public void doDamage(Player p1, Player p2) {

    if (p1 != null && p2 != null) {
      turn++;
      if (doesAttack(p1, p2)) {
        int actualDmg = actualDamage(p1, p2);
        if (actualDmg > 0) {
          int health = p1.getCurrentHealth();
          health -= actualDmg;
          p1.setCurrentHealth(health);
        }
      }
    } else {
      throw new IllegalArgumentException("Players cannot be null");
    }
  }

  @Override
  public boolean isBattleOver(Player p1, Player p2) {

    if (p1 != null && p2 != null) {
      return p1.getCurrentHealth() <= 0 || p2.getCurrentHealth() <= 0 || turn == 200;
    } else {
      throw new IllegalArgumentException("Players cannot be null");
    }
  }

  @Override
  public Player getWinner(Player p1, Player p2) {

    if (p1 != null && p2 != null) {
      if (p1.getCurrentHealth() <= 0 && p2.getCurrentHealth() > 0) {
        return p2;
      } else if (p2.getCurrentHealth() <= 0 && p1.getCurrentHealth() > 0) {
        return p1;
      } else {
        return null;
      }
    } else {
      throw new IllegalArgumentException("Players cannot be null");
    }
  }

  @Override
  public void rematch() {
    turn = 0;
  }

  @Override
  public Player getTurn(Player p1, Player p2) {
    if (turn % 2 == 0) {
      return p1;
    } else {
      return p2;
    }
  }

  @Override
  public List<String> sortList(Player p1) {

    List<String> a1 = new ArrayList<>();
    List<String> a3 = new ArrayList<>();

    for (int i = 0; i < p1.getPotionNumber(); i++) {
      a1.add(p1.getPotion(i).getName());
    }
    a3.add(p1.getHeadgear().getName());
    Collections.sort(a1);
    a3.addAll(a1);
    a1.clear();
    for (int i = 0; i < p1.getBeltNumber(); i++) {
      a1.add(p1.getBelt(i).getName());
    }
    Collections.sort(a1);
    a3.addAll(a1);
    a3.add(p1.getFootwear().getName());

    return a3;
  }
}
