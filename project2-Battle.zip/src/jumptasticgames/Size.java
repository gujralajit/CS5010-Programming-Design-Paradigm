package jumptasticgames;

/**
 * This enumeration denotes the sizes of the belts that are available to the player to equip. There
 * are only 3 types of belt sizes available, small belts requiring 1 unit of space, medium belts
 * requiring 2 units of space and large belts requiring 4 units of space.
 */
public enum Size {
  SMALL, MEDIUM, LARGE;
}
