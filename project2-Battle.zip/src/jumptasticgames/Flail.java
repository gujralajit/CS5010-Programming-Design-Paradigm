package jumptasticgames;

/**
 * This creates a flail type weapon. This is a heavy weapon only wielded by strong players
 * whose dexterity is greater than 14. They do 8 to 12 damage per turn. If the player has less
 * dexterity, it only deals half damage.
 */
public class Flail extends AbstractWeapon {

  private final String name;
  private GetRandomValue r1;

  /**
   * Created a constructor to assign the name to the flail.
   *
   * @param name is the name of the flail
   */
  public Flail(String name) {
    if (name != null) {
      this.name = name;
    } else {
      throw new IllegalArgumentException("Name cannot be null");
    }
    r1 = new GetRandomValue();
  }

  @Override
  public int damageDone() {
    return r1.getRand(8, 12);
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public boolean isFlail(Flail o) {
    return true;
  }

  @Override
  public boolean compare(Object o) {
    if (o instanceof AbstractWeapon) {
      AbstractWeapon a = (AbstractWeapon) o;
      return a.isFlail(this);
    }
    return false;
  }
}
