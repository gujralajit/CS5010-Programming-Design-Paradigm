package jumptasticgames;

import java.util.Random;

/**
 * This class contains the get random function which takes in an upper bound and lower bound and
 * returns a random integer value between these two.
 */
public class GetRandomValue {

  int high;
  int low;
  int result;

  //https://stackoverflow.com/questions/5271598/java-generate-random-number-between-two-given-values
  protected int getRand(int low, int high) {
    Random r = new Random();
    this.high = high;
    this.low = low;
    result = r.nextInt(high - low + 1) + low;
    return result;
  }

}
