package jumptasticgames;

/**
 * The abilities interface contains all the common methods and functionalities that are exhibited by
 * the player and the gear, such as their strength, constitution, dexterity, and charisma. This
 * interface also extends the ability to assign the values to these abilities.
 */
public interface Abilities {

  /**
   * Assigns the value to the ability based on 4 reruns of a die roll and adding the top 3 values,
   * re-rolling for every dice that returns 1.
   *
   * @return the sum of max 3 values
   */
  int assignAbility();

  /**
   * Calculates a roll of the dice, re-rolling everytime a 1 lands on the dice.
   *
   * @return the value of the dice
   */
  int calcValue();

  /**
   * Gets the value of the strength ability.
   *
   * @return strength value
   */
  int getStrength();

  /**
   * Gets the value of the constitution ability.
   *
   * @return constitution value
   */
  int getConstitution();

  /**
   * Gets the value of the dexterity ability.
   *
   * @return dexterity value
   */
  int getDexterity();

  /**
   * Gets the value of the charisma ability.
   *
   * @return charisma value
   */
  int getCharisma();

  /**
   * Gets the name of the player.
   *
   * @return name
   */
  String getName();
}
