package jumptasticgames;

/**
 * Creates a katana type weapon. This is a lightweight curved sword that comes in pairs. They do 4
 * to 6 damage per turn and a player can carry upto two of them at a time, which attach separately.
 */

public class Katana extends AbstractWeapon {

  private final String name;
  private GetRandomValue r1;

  /**
   * Created a constructor to assign the name to the katana.
   *
   * @param name is the name of the katana
   */
  public Katana(String name) {
    if (name != null) {
      this.name = name;
    } else {
      throw new IllegalArgumentException("Name cannot be null");
    }
    r1 = new GetRandomValue();
  }

  @Override
  public int damageDone() {
    return r1.getRand(4, 6) + r1.getRand(4, 6);
  }

  @Override
  public boolean isKatana(Katana o) {
    return true;
  }

  @Override
  public String getName() {
    return name;
  }
}
