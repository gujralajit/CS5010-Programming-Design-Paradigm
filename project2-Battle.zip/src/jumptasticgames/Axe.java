package jumptasticgames;

/**
 * Creates an axe type weapon. This is a great general weapon doing 6 to 10 damage per turn.
 */
public class Axe extends AbstractWeapon {

  private final String name;
  private GetRandomValue r1;

  /**
   * Created a constructor to assign the name to the axe.
   *
   * @param name is the name of the axe
   */
  public Axe(String name) {
    if (name != null) {
      this.name = name;
    } else {
      throw new IllegalArgumentException("Name entered cannot be null");
    }
    r1 = new GetRandomValue();
  }

  @Override
  public int damageDone() {
    return r1.getRand(6, 10);
  }

  @Override
  public String getName() {
    return name;
  }

  @Override
  public boolean isAxe(Axe o) {
    return true;
  }

  @Override
  public boolean compare(Object o) {
    if (o instanceof AbstractWeapon) {
      AbstractWeapon a = (AbstractWeapon) o;
      return a.isAxe(this);
    }
    return false;
  }
}
