import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import jumptasticgames.BattleInterface;
import jumptasticgames.Battler;
import jumptasticgames.Player;

/**
 * This is the driver class to simulate the experience of players entering a battle arena.
 */
public class Main {

  /**
   * Created a public static void main to print various runs of the program.
   *
   * @param args arguments
   */
  public static void main(String[] args) {

    Player p1 = new Player("Rick");
    Player p2 = new Player("Morty");

    BattleInterface b1 = new Battler();

    b1.createWeapons();
    b1.createHeadgear();
    b1.createFootwear();
    b1.createBelts();
    b1.createPotions();

    b1.assignWeapon(p1);
    b1.assignWeapon(p2);

    b1.assignGear(p1);
    b1.assignGear(p2);

    System.out.println("Player 1 --> \nName : " + p1.getName() + "\nStrength : " + p1.getStrength()
            + "\nConstitution : " + p1.getConstitution() + "\nDexterity : " + p1.getDexterity()
            + "\nCharisma : " + p1.getCharisma() + "\nWeapon : " + p1.getWeapon().getName()
            + "\ngearStrength : " + p1.getGearStrength() + "\ngearConstitution : "
            + p1.getGearConstitution() + "\ngearDexterity : " + p1.getGearDexterity()
            + "\ngearCharisma : " + p1.getGearCharisma());
    System.out.println("Player 1 has headgear equipped : " + p1.getHeadgear().getName());
    List<String> a1 = new ArrayList<>();
    for (int i = 0; i < p1.getPotionNumber(); i++) {
      a1.add(p1.getPotion(i).getName());
    }
    Collections.sort(a1);
    System.out.println("Player 1 has the following potions equipped : ");
    a1 = printPotion(p1, a1);
    System.out.println("\nPlayer 1 has the following belts equipped : ");
    printBelt(p1, a1);
    System.out.println("\nPlayer 1 has footwear equipped : " + p1.getFootwear().getName());

    System.out.println("Player 2 --> \nName : " + p2.getName() + "\nStrength : " + p2.getStrength()
            + "\nConstitution : " + p2.getConstitution() + "\nDexterity : " + p2.getDexterity()
            + "\nCharisma : " + p2.getCharisma() + "\nWeapon : " + p2.getWeapon().getName()
            + "\ngearStrength : " + p2.getGearStrength() + "\ngearConstitution : "
            + p2.getGearConstitution() + "\ngearDexterity : " + p2.getGearDexterity()
            + "\ngearCharisma : " + p2.getGearCharisma());
    System.out.println("Player 2 has headgear equipped : " + p2.getHeadgear().getName());
    a1 = new ArrayList<>();
    for (int i = 0; i < p2.getPotionNumber(); i++) {
      a1.add(p2.getPotion(i).getName());
    }
    Collections.sort(a1);
    System.out.println("Player 2 has the following potions equipped : ");
    a1 = printPotion(p2, a1);
    System.out.println("\nPlayer 2 has the following belts equipped : ");
    printBelt(p2, a1);
    System.out.println("\nPlayer 2 has footwear equipped : " + p2.getFootwear().getName());

    int rematch = 1;

    while (rematch != 0) {
      System.out.println("The first player to play is : " + b1.getFirst(p1, p2).getName());
      if (b1.getFirst(p1, p2) == p1) {
        int c1 = p1.getMaxHealth();
        int c2 = p2.getMaxHealth();
        while (!b1.isBattleOver(p1, p2)) {
          b1.doBattle(p1, p2);
          if (c2 > p2.getCurrentHealth()) {
            System.out.println(p1.getName() + " successfully attacks with "
                    + (c2 - p2.getCurrentHealth()) + " damage. ");
          } else {
            System.out.println(p1.getName() + " does not attack this turn");
          }
          if (c1 > p1.getCurrentHealth()) {
            System.out.println(p2.getName() + " successfully attacks with "
                    + (c1 - p1.getCurrentHealth()) + " damage. ");
          } else {
            System.out.println(p2.getName() + " does not attack this turn");
          }
          System.out.println(p1.getName() + "'s current health : " + p1.getCurrentHealth() + "\n"
                  + p2.getName() + "'s current health : " + p2.getCurrentHealth());
          c1 = p1.getCurrentHealth();
          c2 = p2.getCurrentHealth();
        }
        if (b1.getWinner(p1, p2) == null) {
          System.out.println("This match has ended in a draw. ");
        } else if (b1.getWinner(p1, p2) == p1) {
          System.out.println(p1.getName() + " is the winner. ");
        } else if (b1.getWinner(p1, p2) == p2) {
          System.out.println(p2.getName() + " is the winner. ");
        }
      } else {
        int c1 = p2.getMaxHealth();
        int c2 = p1.getMaxHealth();
        while (!b1.isBattleOver(p1, p2)) {
          b1.doBattle(p2, p1);
          if (c2 > p1.getCurrentHealth()) {
            System.out.println(p2.getName() + " successfully attacks with "
                    + (c2 - p1.getCurrentHealth()) + " damage. ");
          } else {
            System.out.println(p2.getName() + " does not attack this turn");
          }
          if (c1 > p2.getCurrentHealth()) {
            System.out.println(p1.getName() + " successfully attacks with "
                    + (c1 - p2.getCurrentHealth()) + " damage. ");
          } else {
            System.out.println(p1.getName() + " does not attack this turn");
          }
          System.out.println(p2.getName() + "'s current health : " + p2.getCurrentHealth() + "\n"
                  + p1.getName() + "'s current health : " + p1.getCurrentHealth());
          c1 = p2.getCurrentHealth();
          c2 = p1.getCurrentHealth();
        }
        if (b1.getWinner(p1, p2) == null) {
          System.out.println("This match has ended in a draw. ");
        } else if (b1.getWinner(p1, p2) == p1) {
          System.out.println(p1.getName() + " is the winner. ");
        } else if (b1.getWinner(p1, p2) == p2) {
          System.out.println(p2.getName() + " is the winner. ");
        }
      }
      System.out.println("Press 1 to rematch, any other number to quit. ");
      Scanner sc = new Scanner(System.in);
      if (sc.next().equals("1")) {
        System.out.println("Starting rematch. ");
        p1.setCurrentHealth(p1.getMaxHealth());
        p2.setCurrentHealth(p2.getMaxHealth());
        b1.rematch();
      } else {
        rematch = 0;
      }
    }
  }

  private static List<String> printPotion(Player p1, List<String> a1) {
    for (int i = 0; i < p1.getPotionNumber(); i++) {
      System.out.print("\t" + (i + 1) + ". " + a1.get(i) + "(ch : " + p1.getPotion(i).getCharisma()
              + ", dex : " + p1.getPotion(i).getDexterity() + ", str : "
              + p1.getPotion(i).getStrength() + ", const : " + p1.getPotion(i).getConstitution()
              + ")\n");
    }
    a1 = new ArrayList<>();
    for (int i = 0; i < p1.getBeltNumber(); i++) {
      a1.add(p1.getBelt(i).getName());
    }
    Collections.sort(a1);
    return a1;
  }

  private static void printBelt(Player p1, List<String> a1) {
    for (int i = 0; i < p1.getBeltNumber(); i++) {
      System.out.print("\t" + (i + 1) + ". " + a1.get(i) + "(ch : " + p1.getBelt(i).getCharisma()
              + ", dex : " + p1.getBelt(i).getDexterity() + ", str : " + p1.getBelt(i).getStrength()
              + ", const : " + p1.getBelt(i).getConstitution() + ", size : "
              + p1.getBelt(i).getSize() + ")\n");
    }
  }
}
