# Readme

1. **About**
   * Creating a battle arena where players can enter and fight to the death. 
   * The players enter the arena bare handed and can equip armor and weapons to aid them in the fight. 
   * Players can request for a rematch where their health are restored to the initial values. 
   * The battle happens in a turn based manner. Players take turns to attack and inflict damage on their opponent. 
   * Players can attack or dodge based on their abilities.


2. **List of Features**
    * Players have the option to enter the arena bare handed and fight in this manner if required. 
    * Players also have an option to equip themselves with weapons and gears. 
    * Players can request for a weapon from the armory but the weapon is assigned to them randomly. 
    * Players can also request for gears, but they are only presented with a bag of 20 options, and they must equip all possible options. 
    * Gear is of 4 types -->  
      * Headgear : can only equip 1 at a time
      * Footwear : can only equip 1 at a time
      * Belts : can equip upto 10 units of belt, units depend on size of belt, can enhance or diminish upto 2 of the player's abilities. 
      * Potions : can equip as many as available, can enhance or diminish 1 of the player's abilities.


3. **How To Run**
    * Run the project1-Primates.jar file to see the output.
    * The user is prompted if they want a rematch. 
    * This is the only input required from the user. 
    * The rematch happens with the same player abilities, weapons and gear equiped. 
    * Only the player health is restored in a rematch. 


4. **How to Use the Program**
    * The main method simulates the complete battle with each player taking turns to attack the other player. 
    * The player has the option to equip weapons, gears, etc. 
    * The player also has the option to fight bare handed. 


5. **Description of Examples**
    * Run 1 contains a scenario where doing a rematch changes the winner of the match. 
    * Run 2 contains a scenario where player 1 is the winner. 
    * Run 3 contains a scenario where player 1 is the winner.
    * Run 4 contains a scenario where the match ends in a draw. 
    * Run 5 contains a scenario where the match is played bare handed and with no gear equipped.
    * Run 6 contains a scenario where the match is played with no gear equipped.
    * Run 7 contains a scenario where the match is played bare handed.


6. **Design/Model Changes**
    * Removed gear interface since the abilities can be accessed by the abilities interface. 
    * Added abstract classes for gear and weapons to share common code. 
    * Remove sword interface since the weight of the sword is not required for any calculation. 
    * Added a battle interface as every public facing class should expose only a higher level interfce. 


7. **Assumptions**
    * Assuming that the user knows that rematch happens with same gear and abilities. 
    * Assuming that the user is aware that they have to give an input to exit the code if they don't want to rematch.
    * Assuming that the user knows that we can choose to assign weapons/gears or fight bare handed. 


8. **Limitations**
    * User is not aware of the gears and weapons available per battle.
    * Gears' abilities are not temporary and are assigned for the whole battle. 


9. **Citations**
   * https://www.baeldung.com/java-random-string
   * https://stackoverflow.com/questions/5271598/java-generate-random-number-between-two-given-values

