import org.junit.Before;
import org.junit.Test;

import jumptasticgames.Belt;
import jumptasticgames.Footwear;
import jumptasticgames.Headgear;
import jumptasticgames.Potion;
import jumptasticgames.Size;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created a testing class to test various functionalities of the gear.
 */
public class GearTest {

  Potion pt1;
  Potion pt2;
  Potion pt3;
  Belt bt1;
  Belt bt2;
  Belt bt3;
  Headgear hg1;
  Headgear hg2;
  Footwear fw1;
  Footwear fw2;

  @Before
  public void setUp() {

    pt1 = new Potion("pot-123", 1);
    pt2 = new Potion("pot-456", -1);
    bt1 = new Belt("belt-123", Size.SMALL, 1);
    bt2 = new Belt("belt-456", Size.MEDIUM, -1);
    bt3 = new Belt("belt-789", Size.LARGE, 1);
    hg1 = new Headgear("head-123", 1);
    hg2 = new Headgear("head-456", -1);
    fw1 = new Footwear("foot-123", 1);
    fw2 = new Footwear("foot-456", -1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullGear() {
    pt3 = new Potion(null, 1);
    bt3 = new Belt(null, null, 0);
    hg2 = new Headgear(null, 0);
    fw2 = new Footwear(null, 0);
  }

  @Test
  public void testGearAttributes() {

    assertEquals("pot-123", pt1.getName());
    assertEquals("belt-123", bt1.getName());
    assertEquals(Size.SMALL, bt1.getSize());
    assertEquals(1, bt1.getUnits());
    assertEquals("head-123", hg1.getName());
    assertEquals("foot-123", fw1.getName());

    assertEquals(1, pt1.getMultiplier());
    assertEquals(1, bt1.getMultiplier());
    assertEquals(1, hg1.getMultiplier());
    assertEquals(1, fw1.getMultiplier());

    assertEquals(false, pt1.compare(bt1));
    assertEquals(false, pt1.compare(hg1));
    assertEquals(false, pt1.compare(fw1));

    assertEquals(false, bt1.compare(pt1));
    assertEquals(false, bt1.compare(hg1));
    assertEquals(false, bt1.compare(fw1));

    assertEquals(false, hg1.compare(bt1));
    assertEquals(false, hg1.compare(pt1));
    assertEquals(false, hg1.compare(fw1));

    assertEquals(false, fw1.compare(bt1));
    assertEquals(false, fw1.compare(hg1));
    assertEquals(false, fw1.compare(pt1));

    assertEquals(true, pt1.isPotion(pt2));
    assertEquals(true, bt1.isBelt(bt2));
    assertEquals(true, hg1.isHead(hg2));
    assertEquals(true, fw1.isFoot(fw2));

    assertTrue(0 <= pt1.getCharisma() && pt1.getCharisma() <= 18);
    assertTrue(0 <= pt1.getConstitution() && pt1.getConstitution() <= 18);
    assertTrue(0 <= pt1.getDexterity() && pt1.getDexterity() <= 18);
    assertTrue(0 <= pt1.getStrength() && pt1.getStrength() <= 18);

    assertTrue(0 <= pt1.getCharisma() && pt1.getCharisma() <= 18);
    assertTrue(0 <= pt1.getConstitution() && pt1.getConstitution() <= 18);
    assertTrue(0 <= pt1.getDexterity() && pt1.getDexterity() <= 18);
    assertTrue(0 <= pt1.getStrength() && pt1.getStrength() <= 18);

    assertEquals(0, hg1.getCharisma());
    assertTrue(6 <= hg1.getConstitution() && hg1.getConstitution() <= 18);
    assertEquals(0, hg1.getDexterity());
    assertEquals(0, hg1.getStrength());

    assertEquals(0, fw1.getCharisma());
    assertTrue(6 <= fw1.getDexterity() && fw1.getDexterity() <= 18);
    assertEquals(0, fw1.getConstitution());
    assertEquals(0, fw1.getStrength());
  }
}