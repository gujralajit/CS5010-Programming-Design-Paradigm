import org.junit.Before;
import org.junit.Test;

import jumptasticgames.Player;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created a testing class to test various functionalities of the player.
 */
public class PlayerTest {

  Player p1;
  Player p2;

  @Before
  public void setUp() {
    p1 = new Player("ABC", 14, 10, 15, 17);
    p2 = new Player("XYZ", 15, 11, 8, 12);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testNullPlayer() {
    p1 = new Player(null);
    p2 = new Player(null, 0, 0, 0, 0);
  }

  @Test
  public void testPlayerAttributes() {

    assertEquals("ABC", p1.getName());
    assertTrue(6 <= p1.getCharisma() && p1.getCharisma() <= 18);
    assertTrue(6 <= p1.getConstitution() && p1.getConstitution() <= 18);
    assertTrue(6 <= p1.getDexterity() && p1.getDexterity() <= 18);
    assertTrue(6 <= p1.getStrength() && p1.getStrength() <= 18);

    assertTrue(6 <= p1.getStrength() + p1.getGearStrength() && p1.getStrength()
            + p1.getGearStrength() <= 36);
  }
}