import org.junit.Before;
import org.junit.Test;

import java.util.List;

import jumptasticgames.AbstractGear;
import jumptasticgames.Axe;
import jumptasticgames.Battler;
import jumptasticgames.Belt;
import jumptasticgames.Broadsword;
import jumptasticgames.Flail;
import jumptasticgames.Footwear;
import jumptasticgames.Headgear;
import jumptasticgames.Katana;
import jumptasticgames.Player;
import jumptasticgames.Potion;
import jumptasticgames.Size;
import jumptasticgames.TwoHanded;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created a testing class to test various functionalities of the battle.
 */
public class BattlerTest {

  Battler b1;
  Player p1;
  Player p2;

  Katana k1;
  Flail f1;
  Broadsword bd1;
  Axe a1;
  TwoHanded t1;

  Potion pt1;
  Potion pt2;
  Potion pt3;
  Belt bt1;
  Belt bt2;
  Belt bt3;
  Headgear hg1;
  Headgear hg2;
  Footwear fw1;
  Footwear fw2;

  @Before
  public void setUp() {
    b1 = new Battler();

    p1 = new Player("ABC", 14, 10, 15, 17);
    p2 = new Player("XYZ", 15, 11, 8, 12);

    k1 = new Katana("kat-123");
    f1 = new Flail("fla-123");
    bd1 = new Broadsword("brd-123");
    a1 = new Axe("axe-123");
    t1 = new TwoHanded("two-123");

    pt1 = new Potion("pot-123", 1);
    pt2 = new Potion("pot-456", -1);
    pt3 = new Potion("pot-789", 1);
    bt1 = new Belt("belt-123", Size.SMALL, 1);
    bt2 = new Belt("belt-456", Size.MEDIUM, -1);
    bt3 = new Belt("belt-789", Size.LARGE, 1);
    hg1 = new Headgear("head-123", 1);
    hg2 = new Headgear("head-456", -1);
    fw1 = new Footwear("foot-123", 1);
    fw2 = new Footwear("foot-456", -1);
  }

  @Test
  public void testName() {
    assertEquals("ABC", p1.getName());
  }

  @Test
  public void testPlayer() {
    assertEquals(0, p1.getStrength());
  }

  @Test
  public void testWeapon() {
    p1.setWeapon(t1);
    p2.setWeapon(t1);
    assertEquals(true, b1.getPotentialStrikingDamage(p1) < b1.getPotentialStrikingDamage(p2));
    p1.setWeapon(f1);
    p2.setWeapon(f1);
    assertEquals(true, b1.getPotentialStrikingDamage(p2) < b1.getPotentialStrikingDamage(p1));
  }

  @Test
  public void testGear() {
    b1.createWeapons();
    b1.createHeadgear();
    b1.createFootwear();
    b1.createBelts();
    b1.createPotions();

    List<AbstractGear> l1 = b1.createRandomBag();
    assertEquals(20, l1.size());

    p1.setBelt(bt3);
    p1.setBelt(bt3);
    p1.setBelt(bt2);
    p1.setBelt(bt2);

    assertEquals(bt3.getName(), p1.getBelt(0).getName());
    assertEquals(bt3.getName(), p1.getBelt(1).getName());
    assertEquals(bt2.getName(), p1.getBelt(2).getName());
    assertEquals(null, p1.getBelt(3));

    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);
    p1.setPotion(pt1);

    assertEquals("pot-123", p1.getPotion(0).getName());
    assertEquals("pot-123", p1.getPotion(5).getName());
    assertEquals("pot-123", p1.getPotion(9).getName());
    assertEquals(null, p1.getPotion(10));

    p1.setHeadgear(hg1);
    assertEquals("head-123", hg1.getName());
    assertEquals(1, hg1.getMultiplier());
    p1.setHeadgear(hg2);
    assertEquals("head-456", hg2.getName());
    assertEquals(-1, hg2.getMultiplier());

    p1.setFootwear(fw1);
    assertEquals("foot-123", fw1.getName());
    assertEquals(1, fw1.getMultiplier());
    p1.setFootwear(fw2);
    assertEquals("foot-456", fw2.getName());
    assertEquals(-1, fw2.getMultiplier());

    assertEquals("[head-456, pot-123, pot-123, pot-123, pot-123, pot-123, pot-123, pot-123,"
                    + " pot-123, pot-123, pot-123, belt-456, belt-789, belt-789, foot-456]",
            b1.sortList(p1).toString());
  }

  @Test
  public void testAssignGear() {

    p1 = new Player("ABC");

    assertEquals(null, p1.getWeapon());
    assertEquals(null, p1.getHeadgear());
    assertEquals(null, p1.getFootwear());
    assertEquals(null, p1.getBelt(0));
    assertEquals(null, p1.getPotion(0));

    b1.createWeapons();
    b1.createHeadgear();
    b1.createFootwear();
    b1.createBelts();
    b1.createPotions();

    b1.assignWeapon(p1);
    b1.assignGear(p1);

    assertNotEquals(null, p1.getWeapon());
    assertNotEquals(null, p1.getHeadgear());
    assertNotEquals(null, p1.getFootwear());
    assertNotEquals(null, p1.getBelt(0));
    assertNotEquals(null, p1.getPotion(0));
  }

  @Test
  public void testBattle() {

    p1 = new Player("ABC", 18, 18, 18, 18);
    p2 = new Player("XYZ", 6, 6, 6, 6);

    assertEquals(72, p1.getMaxHealth());
    assertTrue(17 <= b1.getStrikingPower(p1) && b1.getStrikingPower(p1) <= 27);
    assertTrue(19 <= b1.getAvoidanceAbility(p1) && b1.getAvoidanceAbility(p1) <= 25);
    assertEquals(18, b1.getPotentialStrikingDamage(p1));

    assertEquals(null, p1.getWeapon());


    b1.doDamage(p1, p2);
    assertEquals(p2, b1.getTurn(p1, p2));
    assertEquals(12, p2.getCurrentHealth());
    b1.doDamage(p1, p2);
    assertEquals(p1, b1.getTurn(p1, p2));
    assertEquals(72, p1.getCurrentHealth());
  }
}