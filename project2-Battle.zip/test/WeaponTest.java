import org.junit.Before;
import org.junit.Test;

import jumptasticgames.Axe;
import jumptasticgames.Broadsword;
import jumptasticgames.Flail;
import jumptasticgames.Katana;
import jumptasticgames.TwoHanded;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created a testing class to test various functionalities of the weapon.
 */
public class WeaponTest {

  Katana k1;
  Katana k2;
  Flail f1;
  Flail f2;
  Broadsword bd1;
  Broadsword bd2;
  Axe a1;
  Axe a2;
  TwoHanded t1;
  TwoHanded t2;

  @Before
  public void setUp() {

    k1 = new Katana("kat-123");
    f1 = new Flail("fla-123");
    bd1 = new Broadsword("brd-123");
    a1 = new Axe("axe-123");
    t1 = new TwoHanded("two-123");

    k2 = new Katana("kat-456");
    f2 = new Flail("fla-456");
    bd2 = new Broadsword("brd-456");
    a2 = new Axe("axe-456");
    t2 = new TwoHanded("two-456");
  }

  @Test
  public void testWeapon() {

    assertEquals("kat-123", k1.getName());
    assertEquals("fla-123", f1.getName());
    assertEquals("brd-123", bd1.getName());
    assertEquals("axe-123", a1.getName());
    assertEquals("two-123", t1.getName());

    assertEquals(false, k1.compare(f1));
    assertEquals(false, k1.compare(bd1));
    assertEquals(false, k1.compare(a1));
    assertEquals(false, k1.compare(t1));

    assertEquals(false, f1.compare(k1));
    assertEquals(false, f1.compare(bd1));
    assertEquals(false, f1.compare(a1));
    assertEquals(false, f1.compare(t1));

    assertEquals(false, bd1.compare(f1));
    assertEquals(false, bd1.compare(k1));
    assertEquals(false, bd1.compare(a1));
    assertEquals(false, bd1.compare(t1));

    assertEquals(false, a1.compare(f1));
    assertEquals(false, a1.compare(bd1));
    assertEquals(false, a1.compare(k1));
    assertEquals(false, a1.compare(t1));

    assertEquals(false, t1.compare(f1));
    assertEquals(false, t1.compare(bd1));
    assertEquals(false, t1.compare(a1));
    assertEquals(false, t1.compare(k1));

    assertEquals(true, k1.isKatana(k2));
    assertEquals(true, f1.isFlail(f2));
    assertEquals(true, bd1.isBroadsword(bd2));
    assertEquals(true, a1.isAxe(a2));
    assertEquals(true, t1.isTwoHanded(t2));

    assertEquals(true, t1.isTwoHanded(t2));

    assertTrue(8 <= k1.damageDone() && k1.damageDone() <= 12);
    assertTrue(8 <= f1.damageDone() && f1.damageDone() <= 12);
    assertTrue(6 <= bd1.damageDone() && bd1.damageDone() <= 10);
    assertTrue(6 <= a1.damageDone() && a1.damageDone() <= 10);
    assertTrue(8 <= t1.damageDone() && t1.damageDone() <= 12);
  }
}