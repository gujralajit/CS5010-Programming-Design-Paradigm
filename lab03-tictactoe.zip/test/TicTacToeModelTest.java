import org.junit.Before;
import org.junit.Test;

import tictactoe.Player;
import tictactoe.TicTacToeModel;

import static org.junit.Assert.assertEquals;

/**
 * Creating a test class for the tictactoe model of a 3 by 3 size game, testing various
 * functionalities like creating a board, getting the toString to print the board state,
 * moving a unit to a specific place on the board, getting a specific unit from the board,
 * checking whose turn it is, and getting a winner if decided.
 */
public class TicTacToeModelTest {

  private TicTacToeModel m1 = new TicTacToeModel();
  private TicTacToeModel m2 = new TicTacToeModel();
  private TicTacToeModel m3 = new TicTacToeModel();
  private TicTacToeModel m4 = new TicTacToeModel();
  private TicTacToeModel m5 = new TicTacToeModel();
  private TicTacToeModel m6 = new TicTacToeModel();

  private static boolean setUpIsDone = false;

  @Before
  public void setUp() {
    if (setUpIsDone) {
      return;
    }
    m1.move(0, 0);
    m1.move(0, 1);
    m1.move(1, 1);
    m1.move(2, 2);
    m1.move(2, 0);
    m1.move(0, 2);
    m1.move(1, 0);

    m2.move(0, 0);
    m2.move(0, 1);
    m2.move(0, 2);
    m2.move(1, 0);
    m2.move(1, 1);
    m2.move(1, 2);

    m4.move(0, 0);
    m4.move(1, 0);
    m4.move(0, 1);
    m4.move(2, 0);
    m4.move(0, 2);

    m5.move(0, 0);
    m5.move(1, 1);
    m5.move(1, 0);
    m5.move(2, 2);
    m5.move(2, 0);

    m6.move(0, 0);
    m6.move(1, 0);
    m6.move(1, 1);
    m6.move(2, 0);
    m6.move(2, 2);
  }

  @Test
  public void testToString() {
    String s1 = m1.toString();
    assertEquals(" X | O | O\n" + "-----------\n" + " X | X |  \n"
            + "-----------\n" + " X |   | O", s1);
  }

  @Test//(expected = IllegalStateException.class)
  public void move() {
    m1.move(1, 2);
    assertEquals(Player.X, m1.getMarkAt(1, 2));
    m1.move(2, 1);

    m3.move(0,0);
    m3.move(1,1);
    m3.move(2,1);
    assertEquals(Player.X, m3.getMarkAt(0, 0));
    assertEquals(null, m3.getMarkAt(0, 1));
    assertEquals(null, m3.getMarkAt(0, 2));
    assertEquals(null, m3.getMarkAt(1, 0));
    assertEquals(Player.O, m3.getMarkAt(1, 1));
    assertEquals(null, m3.getMarkAt(1, 2));
    assertEquals(null, m3.getMarkAt(2, 0));
    assertEquals(Player.X, m3.getMarkAt(2, 1));
    assertEquals(null, m3.getMarkAt(2, 2));
  }

  @Test(expected = IllegalArgumentException.class)
  public void move1() {
    m3.move(1, 1);
    m3.move(4, 7);
  }

  @Test
  public void getTurn() {
    Player p1 = m1.getTurn();
    assertEquals(Player.O, p1);

    p1 = m3.getTurn();
    assertEquals(Player.X, p1);
    m3.move(1, 1);
    p1 = m3.getTurn();
    assertEquals(Player.O, p1);
  }

  @Test
  public void isGameOver() {
    assertEquals(true, m1.isGameOver());

    assertEquals(false, m3.isGameOver());

    assertEquals(true, m4.isGameOver());

    assertEquals(true, m5.isGameOver());

    assertEquals(true, m6.isGameOver());

    assertEquals(false, m2.isGameOver());
    m2.move(2, 2);
    assertEquals(true, m2.isGameOver());
  }

  @Test
  public void getWinner() {
    assertEquals(Player.X, m1.getWinner());
    assertEquals(null, m3.getWinner());
  }

  @Test
  public void getBoard() {
    Player[][] p1 = m1.getBoard();

    assertEquals(p1[0][0], m1.getMarkAt(0, 0));
    assertEquals(p1[0][1], m1.getMarkAt(0, 1));
    assertEquals(p1[0][2], m1.getMarkAt(0, 2));
    assertEquals(p1[1][0], m1.getMarkAt(1, 0));
    assertEquals(p1[1][1], m1.getMarkAt(1, 1));
    assertEquals(p1[1][2], m1.getMarkAt(1, 2));
    assertEquals(p1[2][0], m1.getMarkAt(2, 0));
    assertEquals(p1[2][1], m1.getMarkAt(2, 1));
    assertEquals(p1[2][2], m1.getMarkAt(2, 2));
  }

  @Test(expected = IllegalArgumentException.class)
  public void getMarkAt() {
    Player p1 = m1.getMarkAt(1, 1);
    assertEquals(Player.X, p1);

    assertEquals(Player.X, m1.getMarkAt(3, 6));
  }
}