package tictactoe;

import java.util.Arrays;
import java.util.stream.Collectors;

/**
 * Creating a grid for a 3x3 model of a tictactoe game. The class has the ability to create a new
 * board, move players, and decide who is thw winner. The game starts with Player X and it goes on
 * for a maximum of 9 turns. If a user gets 3 in a row (horizontally, vertically, or diagonally),
 * they are declared as the winner.
 */
public class TicTacToeModel implements TicTacToe {
  // add your implementation here
  private int turn;
  final private Player[][] board = new Player[3][3];

  public TicTacToeModel() {
    turn = 0;
    Player[][] board = {{null, null, null}, {null, null, null}, {null, null, null}};
  }

  @Override
  public String toString() {
    // Using Java stream API to save code:
    return Arrays.stream(getBoard()).map(row -> " " + Arrays.stream(row)
      .map(p -> p == null ? " " : p.toString()).collect(Collectors.joining(" | ")))
        .collect(Collectors.joining("\n-----------\n"));
//     This is the equivalent code as above, but using iteration, and still using the helpful
//     built-in String.join method.
//    List<String> rows = new ArrayList<>();
//    for (Player[] row : getBoard()) {
//      List<String> rowStrings = new ArrayList<>();
//      for (Player p : row) {
//        if (p == null) {
//          rowStrings.add(" ");
//        } else {
//          rowStrings.add(p.toString());
//        }
//      }
//      rows.add(" " + String.join(" | ", rowStrings));
//    }
//    return String.join("\n-----------\n", rows);
  }

  @Override
  public void move(int r, int c) {
    if (isGameOver()) {
      throw new IllegalStateException("The game is already over. ");
    }
    if (!isrcValid(r, c)) {
      throw new IllegalArgumentException("Please enter correct row and column for 3x3 matrix. ");
    } else {
      Player p1 = getTurn();
      if (board[r][c] == null) {
        if (turn <= 7) {
          turn++;
        }
        if (p1.toString().equals("X")) {
          board[r][c] = Player.X;
        } else if (p1.toString().equals("O")) {
          board[r][c] = Player.O;
        }
      } else {
        throw new IllegalArgumentException("This block is already occupied. ");
      }
    }
  }

  @Override
  public Player getTurn() {
    if (turn % 2 == 0) {
      return Player.X;
    } else {
      return Player.O;
    }
  }

  @Override
  public boolean isGameOver() {
    Boolean gameOver = true;
    if (getWinner() != null) {
      return gameOver;
    }
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (board[i][j] == null) {
          gameOver = false;
        }
      }
    }
    return gameOver;
  }

  @Override
  public Player getWinner() {
    for (int i = 0; i < 3; i++) {
      if (board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
        return board[i][0];
      } else if (board[0][i] == board[1][i] && board[1][i] == board[2][i]) {
        return board[0][i];
      } else if (board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
        return board[1][1];
      } else if (board[2][0] == board[1][1] && board[1][1] == board[0][2]) {
        return board[1][1];
      }
    }
    return null;
  }

  @Override
  public Player[][] getBoard() {
    Player[][] p1 = {{board[0][0], board[0][1], board[0][2]}, {board[1][0], board[1][1],
            board[1][2]}, {board[2][0], board[2][1], board[2][2]}};
    return p1;
  }

  @Override
  public Player getMarkAt(int r, int c) {
    if (isrcValid(r, c)) {
      return board[r][c];
    } else {
      throw new IllegalArgumentException("Please enter correct row and column for 3x3 matrix. ");
    }
  }

  /**
   * Creating a primate row and column checker. This takes the row number and the column number and
   * determines if the given values are valid or not. Since this is a tictactoe game, it has to be
   * a 3x3 matrix, with row numbers ranging from 0-2 and column numbers also from 0-2.
   *
   * @param r as row number
   * @param c as clumn number
   * @return boolean value if the given r and c are valid inouts
   */
  private Boolean isrcValid(int r, int c) {
    if (r >= 0 && r <= 2 && c >= 0 && c <= 2) {
      return true;
    } else {
      return false;
    }
  }
}
