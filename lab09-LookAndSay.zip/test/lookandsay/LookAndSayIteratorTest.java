package lookandsay;

import org.junit.Before;
import org.junit.Test;

import java.math.BigInteger;
import java.util.NoSuchElementException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Test class for look and say.
 */
public class LookAndSayIteratorTest {

  RIterator<BigInteger> t1;
  RIterator<BigInteger> t2;
  RIterator<BigInteger> t3;

  @Before
  public void setup() {
    t1 = new LookAndSayIterator(new BigInteger("7113"));
    t2 = new LookAndSayIterator(new BigInteger("7113"), new BigInteger("311711222113"));
    t3 = new LookAndSayIterator();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalSeedTwoArgs() {
    t3 = new LookAndSayIterator(new BigInteger("1001"), new BigInteger("999999"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testSmallEndTwoArgs() {
    t3 = new LookAndSayIterator(new BigInteger("333211"), new BigInteger("32"));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalSeedOneArgs() {
    t3 = new LookAndSayIterator(new BigInteger("1001"));
  }

  @Test
  public void testValidNext() {
    assertEquals("7113", t1.next().toString());
  }

  @Test(expected = NoSuchElementException.class)
  public void testInvalidNext() {
    while (t2.hasNext()) {
      t2.next();
    }
    t2.next();
  }

  @Test
  public void testValidPrev() {
    assertEquals("11111113", t1.prev().toString());
  }

  @Test(expected = NoSuchElementException.class)
  public void testInvalidPrev() {
    while (t2.hasPrevious()) {
      t2.prev();
    }
    t2.prev();
  }

  @Test
  public void testTrueNext() {
    assertTrue(t1.hasNext());
  }

  @Test
  public void testFalseNext() {
    while (t2.hasNext()) {
      t2.next();
    }
    assertFalse(t2.hasNext());
  }

  @Test
  public void testTruePrev() {
    assertTrue(t1.hasPrevious());
  }

  @Test
  public void testFalsePrev() {
    while (t2.hasPrevious()) {
      t2.prev();
    }
    assertFalse(t2.hasPrevious());
  }
}