package lookandsay;

import java.math.BigInteger;
import java.util.NoSuchElementException;

/**
 * Implementation of look and say class.
 */
public class LookAndSayIterator implements RIterator<BigInteger> {

  private BigInteger seed;
  private final BigInteger endValue;
  private Boolean flag;
  private static final BigInteger MAX_VALUE = new BigInteger("9".repeat(100));
  private static final BigInteger MIN_SEED = new BigInteger("1");

  /**
   * Constructor with 2 arguments.
   *
   * @param seed     is the given seed
   * @param endValue is the given end value
   */
  public LookAndSayIterator(BigInteger seed, BigInteger endValue) {

    if (seed.compareTo(BigInteger.ZERO) < 0 || seed.compareTo(endValue) > 0
            || seed.toString().contains("0")) {
      throw new IllegalArgumentException("Illegal seed value : " + seed + " endVal : " + endValue);
    }
    this.seed = seed;
    this.endValue = endValue;
    flag = false;
  }

  /**
   * Constructor with 1 argument.
   *
   * @param seed is the given seed
   */
  public LookAndSayIterator(BigInteger seed) {
    this(seed, MAX_VALUE);
  }

  /**
   * Constructor with 0 parameters.
   */
  public LookAndSayIterator() {
    this(MIN_SEED, MAX_VALUE);
  }

  @Override
  public BigInteger prev() throws NoSuchElementException {

    if (!hasPrevious()) {
      throw new NoSuchElementException("No previous element available for seed : " + seed);
    }
    if (flag) {
      String number = seed.toString();
      StringBuilder output = getPrevValue(number);
      seed = new BigInteger(output.toString());
      number = seed.toString();
      output = getPrevValue(number);
      seed = new BigInteger(output.toString());
      flag = false;
      return new BigInteger(output.toString());
    } else {
      String number = seed.toString();
      StringBuilder output = getPrevValue(number);
      seed = new BigInteger(output.toString());
      flag = false;
      return new BigInteger(output.toString());
    }
  }

  @Override
  public boolean hasPrevious() {

    StringBuilder output;
    if (flag) {
      String number = seed.toString();
      if (number.length() > 1 && number.length() % 2 == 0) {
        output = getPrevValue(number);
      } else {
        return false;
      }
      number = output.toString();
      if (number.length() > 1 && number.length() % 2 == 0) {
        output = getPrevValue(number);
      } else {
        return false;
      }
    } else {
      String number = seed.toString();
      if (number.length() > 1 && number.length() % 2 == 0) {
        output = getPrevValue(number);
      } else {
        return false;
      }
    }
    BigInteger prev = new BigInteger(output.toString());
    return prev.compareTo(BigInteger.ZERO) >= 0 && prev.compareTo(endValue) <= 0;
  }

  @Override
  public boolean hasNext() {

    String number = seed.toString();
    BigInteger next = new BigInteger(number);
    return next.compareTo(endValue) <= 0;
  }

  @Override
  public BigInteger next() {

    if (hasNext()) {
      flag = true;
      String number = seed.toString();
      StringBuilder output = getNextValue();
      seed = new BigInteger(output.toString());
      return new BigInteger(number);
    } else {
      throw new NoSuchElementException("No next element available for seed : " + seed);
    }
  }

  private StringBuilder getPrevValue(String number) {

    StringBuilder output = new StringBuilder();
    for (int i = 0; i < number.length(); i += 2) {
      int index = Integer.parseInt(Character.toString(number.charAt(i)));
      int prevNumber;
      prevNumber = Integer.parseInt(Character.toString(number.charAt(i + 1)));
      output.append(String.valueOf(prevNumber).repeat(Math.max(0, index)));
    }
    return new StringBuilder(output.toString());
  }

  private StringBuilder getNextValue() {

    String number = seed.toString();
    int index = 1;
    int prevNumber = Integer.parseInt(Character.toString(number.charAt(0)));
    StringBuilder output = new StringBuilder();
    for (int i = 1; i < number.length(); i++) {
      int compareVal = Integer.parseInt(Character.toString(number.charAt(i)));
      if (prevNumber == compareVal) {
        index++;
      } else {
        output.append(index).append(prevNumber);
        index = 1;
        prevNumber = compareVal;
      }
    }
    output.append(index).append(prevNumber);
    return new StringBuilder(output.toString());
  }
}