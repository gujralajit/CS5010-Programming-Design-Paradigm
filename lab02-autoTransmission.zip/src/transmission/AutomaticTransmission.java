package transmission;

/**
 * To automatically switch the gear based on the speed of the car.
 */

public class AutomaticTransmission implements Transmission {

  private final int[] gear = new int[7];

  private int currentGear = 0;
  private int currentSpeed = 0;

  @Override
  public void increaseSpeed() {
    ++currentSpeed;
    changeGear();
  }

  @Override
  public void decreaseSpeed() throws IllegalStateException {
    if (currentSpeed == 0) {
      throw new IllegalStateException("Speed cannot be negative. ");
    } else {
      --currentSpeed;
    }
    changeGear();
  }

  /**
   * Adding changeGear method to change the current gear in case the speed passes the threshold.
   */
  private void changeGear() {
    if (currentGear != 6 && currentSpeed >= gear[currentGear + 1]) {
      currentGear++;
    } else if (currentSpeed <= gear[currentGear - 1]) {
      currentGear--;
    }
  }

  @Override
  public int getSpeed() {
    return currentSpeed;
  }

  @Override
  public int getGear() {
    for (int i = 1; i < 6; i++) {
      if (currentSpeed == 0) {
        currentGear = 0;
      } else if (currentSpeed >= gear[i] && currentSpeed < gear[i + 1]) {
        currentGear = i;
      }
    }
    return currentGear;
  }

  /**
   * Initializing the thresholds for the different gears based on the input.
   *
   * @param gear2 has the gear2 threshold.
   * @param gear3 has the gear3 threshold.
   * @param gear4 has the gear4 threshold.
   * @param gear5 has the gear5 threshold.
   * @param gear6 has the gear6 threshold.
   */
  public AutomaticTransmission(int gear2, int gear3, int gear4, int gear5, int gear6) {
    currentGear = currentSpeed = 0;
    gear[0] = 0;
    gear[1] = 1;
    if (gear2 <= gear[1]) {
      throw new IllegalArgumentException("Gear 2 cannot be less than gear 1. ");
    } else {
      this.gear[2] = gear2;
    }
    if (gear3 <= gear[2]) {
      throw new IllegalArgumentException("Gear 3 cannot be less than gear 2. ");
    } else {
      this.gear[3] = gear3;
    }
    if (gear4 <= gear[3]) {
      throw new IllegalArgumentException("Gear 4 cannot be less than gear 3. ");
    } else {
      this.gear[4] = gear4;
    }
    if (gear5 <= gear[4]) {
      throw new IllegalArgumentException("Gear 5 cannot be less than gear 4. ");
    } else {
      this.gear[5] = gear5;
    }
    if (gear6 <= gear[5]) {
      throw new IllegalArgumentException("Gear 6 cannot be less than gear 5. ");
    } else {
      this.gear[6] = gear6;
    }
  }

  /**
   * Implementing toString method to display the current gear and speed.
   *
   * @return string containing speed and gear
   */
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("Transmission (speed = ");
    sb.append(currentSpeed);
    sb.append(", gear = ");
    sb.append(currentGear);
    sb.append(")");
    return sb.toString();
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (!(o instanceof Transmission)) {
      return false;
    }

    AutomaticTransmission that = (AutomaticTransmission) o;
    return (this.gear[2] == that.gear[2] && this.gear[3] == that.gear[3]
            && this.gear[4] == that.gear[4] && this.gear[5] == that.gear[5]
            && this.gear[6] == that.gear[6]);
  }

  @Override
  public int hashCode() {
    return Integer.hashCode(this.getGear());
  }
}