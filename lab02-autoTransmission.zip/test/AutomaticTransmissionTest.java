import org.junit.Before;
import org.junit.Test;

import transmission.AutomaticTransmission;
import transmission.Transmission;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Creating test class for AutomaticTransmission class.
 */
public class AutomaticTransmissionTest {

  private AutomaticTransmission at1;
  private AutomaticTransmission at3;

  private Transmission t8;
  private Transmission t9;

  @Before
  public void setUp() {
    at1 = new AutomaticTransmission(10, 25, 40, 75, 100);
    try {
      AutomaticTransmission at2 =
              new AutomaticTransmission(10, 25, 40, 38, 39);
    } catch (IllegalArgumentException e) {
      System.out.println("IllegalArgumentException : gear 5 cannot be less than gear 4. ");
    }
    at3 = new AutomaticTransmission(2, 3, 4, 5, 6);

    t8 = new AutomaticTransmission(2, 3, 4, 5, 6);
    t9 = new AutomaticTransmission(10, 25, 40, 75, 100);
  }

  @Test
  public void increaseSpeed() {
    at1.increaseSpeed();
    assertEquals(at1.getSpeed(), 1);

    for (int i = 0; i < 5; i++) {
      at3.increaseSpeed();
    }
    assertEquals(at3.getSpeed(), 5);

    for (int i = 0; i < 30; i++) {
      t8.increaseSpeed();
    }
    assertEquals(t8.getSpeed(), 30);

    for (int i = 0; i < 15; i++) {
      t9.increaseSpeed();
    }
    assertEquals(t9.getSpeed(), 15);
  }

  /**
   * Testing for decreaseSpeed method where the speed cannot be negative.
   *
   * @throws IllegalArgumentException for negative speeds
   */
  @Test(expected = IllegalStateException.class)
  public void decreaseSpeed() {
    at1.increaseSpeed();
    at1.decreaseSpeed();
    assertEquals(at1.getSpeed(), 0);
    at1.decreaseSpeed();

    for (int i = 0; i < 30; i++) {
      at3.increaseSpeed();
      t8.increaseSpeed();
      t9.increaseSpeed();
    }

    for (int i = 0; i < 5; i++) {
      at3.decreaseSpeed();
    }
    assertEquals(at1.getSpeed(), 25);

    for (int i = 0; i < 20; i++) {
      at3.decreaseSpeed();
    }
    assertEquals(at1.getSpeed(), 10);

    for (int i = 0; i < 30; i++) {
      at3.decreaseSpeed();
    }
    assertEquals(at1.getSpeed(), 0);
  }

  @Test
  public void getSpeed() {
    assertEquals(at1.getSpeed(), 0);
  }

  @Test
  public void getGear() {
    assertEquals(at1.getGear(), 0);
  }

  @Test
  public void testToString() {
    assertEquals(at1.toString(), "Transmission (speed = 0, gear = 0)");
  }

  @Test
  public void testEquals() {
    assertTrue(at1.equals(at1));
    assertTrue(at1.equals(new AutomaticTransmission(10, 25, 40, 75,
            100)));
    assertFalse(at1.equals(new AutomaticTransmission(10, 25, 40, 75,
            101)));
  }

  @Test
  public void testHashCode() {
    assertEquals(Integer.hashCode(at1.hashCode()),
            new AutomaticTransmission(10, 25, 40, 75, 100).hashCode());
  }
}