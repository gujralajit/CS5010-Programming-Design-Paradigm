package tictactoe;

/**
 * Run a TicTacToe game interactively.
 */
public class Main {
  /**
   * Run a TicTacToe game interactively.
   */
  public static void main(String[] args) {

    TicTacToeModel m = new TicTacToeModel();
    TicTacToeViewImpl v = new TicTacToeViewImpl(m);
    TicTacToeControllerImpl c = new TicTacToeControllerImpl(m, v);

    c.playGame(m);
  }
}
