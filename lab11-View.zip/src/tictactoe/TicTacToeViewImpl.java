package tictactoe;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

/**
 * A view for TicTacToe: display the game board and provide visual interface
 * for users.
 */
public class TicTacToeViewImpl extends JFrame implements TicTacToeView {

  private final BoardPanel boardPanel;
  private final ReadonlyTttModel model;

  /**
   * A constructor for the view class that takes in a read only model to get data and game state.
   *
   * @param model is the read only model of the game
   */
  public TicTacToeViewImpl(ReadonlyTttModel model) {

    super("Tic-Tac-Toe");
    this.model = model;
    this.setSize(500, 500);
    this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    boardPanel = new BoardPanel(model);
    add(boardPanel);
  }

  @Override
  public void addClickListener(TicTacToeController listener) {

    if (!model.isGameOver()) {
      MouseAdapter clickAdapter = new MouseAdapter() {
        @Override
        public void mouseClicked(MouseEvent e) {
          super.mouseClicked(e);
          int row = e.getX();
          int column = e.getY();

          row = getCoordinates(row);
          column = getCoordinates(column);

          listener.handleCellClick(row, column);
          refresh();
        }
      };
      boardPanel.addMouseListener(clickAdapter);
    }
  }

  private int getCoordinates(int coordinate) {

    if (coordinate >= 100 && coordinate <= 200) {
      coordinate = 0;
    } else if (coordinate >= 200 && coordinate <= 300) {
      coordinate = 1;
    } else if (coordinate >= 300 && coordinate <= 400) {
      coordinate = 2;
    } else {
      coordinate = -1;
    }
    return coordinate;
  }

  @Override
  public void refresh() {
    repaint();
  }

  @Override
  public void makeVisible() {
    setVisible(true);
  }
}