package tictactoe;

/**
 * Represents a Controller for TicTacToe: handle user moves by executing them using the model;
 * convey move outcomes to the user in some form.
 */
public class TicTacToeControllerImpl implements TicTacToeController {

  private final TicTacToe m;
  private final TicTacToeView v;

  /**
   * A constructor for the controller.
   *
   * @param m is the model of the game
   * @param v is the view of the game
   */
  public TicTacToeControllerImpl(TicTacToe m, TicTacToeView v) {
    this.m = m;
    this.v = v;
  }

  @Override
  public void playGame(TicTacToe m) {

    v.makeVisible();
    v.addClickListener(this);
  }

  @Override
  public void handleCellClick(int row, int col) {

    if (row != -1 && col != -1) {
      m.move(row, col);
    }
  }
}
