package tictactoe;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Font;

import javax.swing.JPanel;

class BoardPanel extends JPanel {

  private final ReadonlyTttModel model;

  public BoardPanel(ReadonlyTttModel model) {
    this.model = model;
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;
    g2d.drawLine(200, 100, 200, 400);
    g2d.drawLine(300, 100, 300, 400);
    g2d.drawLine(100, 200, 400, 200);
    g2d.drawLine(100, 300, 400, 300);
    Player[][] board = model.getBoard();
    g.setFont(new Font("TimesRoman", Font.PLAIN, 50));

    if (model.isGameOver()) {
      g.setFont(new Font("TimesRoman", Font.PLAIN, 30));
      if (model.getWinner() == null) {
        g2d.drawString("The game has ended in a tie. ", 25, 50);
      } else {
        g2d.drawString("The game is over. Winner : " + model.getWinner().toString(), 25, 50);
      }
    } else if (model.getTurn() == Player.X) {
      g2d.drawString("Current Turn : X", 25, 50);
    } else if (model.getTurn() == Player.O) {
      g2d.drawString("Current Turn : O", 25, 50);
    }

    g.setFont(new Font("TimesRoman", Font.PLAIN, 75));

    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        if (board[i][j] != null && board[i][j].toString().equals("X")) {
          g2d.drawString("X", ((i + 1) * 100) + 25, ((j + 1) * 100) + 75);
        } else if (board[i][j] != null && board[i][j].toString().equals("O")) {
          g2d.drawString("O", ((i + 1) * 100) + 25, ((j + 1) * 100) + 75);
        }
      }
    }
  }
}
