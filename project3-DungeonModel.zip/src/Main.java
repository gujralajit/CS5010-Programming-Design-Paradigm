import dungeonmodel.Model;
import dungeonmodel.ModelImpl;

/**
 * Main method to denote the driver class.
 */
public class Main {

  /**
   * Main class which is the driver for our dungeon.
   *
   * @param args inline arguments
   */
  public static void main(String[] args) {
    Model m = new ModelImpl();

    int row = Integer.parseInt(args[0]);
    int column = Integer.parseInt(args[1]);
    int interconnectivity = Integer.parseInt(args[2]);
    boolean wrapping = Boolean.parseBoolean(args[3]);
    int cavePercentage = Integer.parseInt(args[4]);

    m.start(row, column, interconnectivity, wrapping, cavePercentage);
    System.out.println(m);
    System.out.println(m.getStart());
    System.out.println(m.getEnd());
    System.out.println(m.getCurrentLocation());
    System.out.println(m.getPlayerDetails());
    System.out.println("Is game over? --> " + m.isGameOver());

    for (int i = 0; i < row; i++) {
      if (i % 2 == 0) {
        for (int j = 0; j < column; j++) {
          m.move(i, j);
          System.out.print(m.getCurrentLocation());
        }
      } else {
        for (int j = column - 1; j >= 0; j--) {
          m.move(i, j);
          System.out.print(m.getCurrentLocation());
        }
      }
    }
  }
}
