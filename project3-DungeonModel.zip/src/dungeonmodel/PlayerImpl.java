package dungeonmodel;

/**
 * Creates a player class to enter the dungeon. It has the ability to traverse the dungeon and
 * collect treasures present in the caves.
 */
public class PlayerImpl implements Player {

  private int rubyValue;
  private int sapphireValue;
  private int diamondValue;

  /**
   * Constructor for the player which sets the default values of the treasure stored by the player
   * to 0.
   */
  public PlayerImpl() {

    rubyValue = 0;
    sapphireValue = 0;
    diamondValue = 0;
  }

  @Override
  public void addTreasure(Treasure t, int val) {

    if (t != null && val >= 0) {
      if (t == Treasure.RUBY) {
        rubyValue += val;
      } else if (t == Treasure.SAPPHIRE) {
        sapphireValue += val;
      } else if (t == Treasure.DIAMOND) {
        diamondValue += val;
      }
    } else {
      throw new IllegalArgumentException("Incorrect values have been passed to the treasure. ");
    }
  }

  @Override
  public String toString() {

    StringBuilder tempTreasure = new StringBuilder();
    if (rubyValue == 0 && sapphireValue == 0 && diamondValue == 0) {
      return "The player has no treasures equipped yet. ";
    }
    tempTreasure.append("The player has the following treasures equipped --> ");
    return Cave.getString(tempTreasure, rubyValue, sapphireValue, diamondValue);
  }
}