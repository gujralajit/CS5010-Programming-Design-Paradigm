package dungeonmodel;

/**
 * The model implementation for the dungeon which creates a dungeon based on the given input by the
 * user.
 */
public class ModelImpl implements Model {

  private Dungeon d1;

  @Override
  public void start(int row, int column, int interconnectivity, boolean wrapping,
                    int cavePercentage) {
    if (row > 4 && column > 4 && interconnectivity >= 0 && cavePercentage >= 0
            && cavePercentage <= 100) {
      d1 = new DungeonImpl(row, column, interconnectivity, wrapping, cavePercentage);
    } else {
      throw new IllegalArgumentException("Illegal arguments have been passed to the dungeon. ");
    }
  }

  @Override
  public void start(int r, int c) {
    if (r > 4 && c > 4) {
      d1 = new DungeonImpl(r, c);
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than 4. ");
    }
  }

  @Override
  public void move(int r, int c) {
    if (r >= 0 && c >= 0) {
      d1.move(r, c);
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public String toString() {
    return d1.toString();
  }

  @Override
  public String getCurrentLocation() {
    return d1.getPlayerLocation();
  }

  @Override
  public boolean isGameOver() {
    return d1.isGameOver();
  }

  @Override
  public String getPlayerDetails() {
    return d1.getPlayerDetails();
  }

  @Override
  public String getCaveDetails(int r, int c) {
    if (r > 0 && c > 0) {
      return d1.getCaveDetails(r, c);
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than 0. ");
    }
  }

  @Override
  public String getStart() {
    return "Start node is at row : " + d1.getStart().getRow() + " and column : "
            + d1.getStart().getColumn();
  }

  @Override
  public String getEnd() {
    return "End node is at row : " + d1.getEnd().getRow() + " and column : "
            + d1.getEnd().getColumn();
  }
}