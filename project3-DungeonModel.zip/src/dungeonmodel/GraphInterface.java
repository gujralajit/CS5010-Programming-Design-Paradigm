package dungeonmodel;

import java.util.List;

/**
 * Creates a graph to represent a dungeon so that we can traverse the nodes based on the edges in
 * the graph. We can use the generated edges and compare them if they form a union set.
 * If the edges form a cycle, they are not added to the list and the dungeon is created. Based on
 * the given connectivity, we can add other edges from the leftover list.
 */
public interface GraphInterface {

  /**
   * Creates the edges list to form the adjacency list and the leftover list. The edges from this
   * list are compared while creating the dungeon.
   *
   * @param row      is the row of the dungeon
   * @param column   is the column of the dungeon
   * @param wrapping denotes if the dungeon is wrapping or not to create the edges
   */
  void createEdgeList(int row, int column, boolean wrapping);

  /**
   * We compare the edge list and compare the edges to form the dungeon. We randomly select the
   * edge and if they form a cycle, they are added to the leftover list, else they are added to the
   * adjacency list. Based on the interconnectivity, we create the dungeon.
   *
   * @param interconnectivity is the given interconnectivity of the dungeon
   */
  void unionSet(int interconnectivity);

  /**
   * We return the adjacency list created in te graph so that it can be used to create the dungeon
   * based on the randomly generated graph.
   *
   * @return the adjacency list
   */
  List<Edge> getAdjacencyList();
}
