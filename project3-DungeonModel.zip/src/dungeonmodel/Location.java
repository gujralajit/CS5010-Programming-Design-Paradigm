package dungeonmodel;

/**
 * The location interface is used to denote the caves and tunnels in the dungeon. The location has
 * the ability to store treasure. The location is able to have upto 4 exits, on right, left, top
 * and bottom. We characterize the location as a tunnel if it only has 2 exits.
 */
public interface Location {

  /**
   * Calculates the number of exits in the location.
   *
   * @return the exits in location
   */
  int getExits();

  /**
   * Returns if the location is a tunnel or not.
   *
   * @return true if it has exactly 2 exits
   */
  Boolean isTunnel();

  /**
   * Adds the treasure in the location.
   *
   * @param treasure is the type of treasure
   * @param value    is the value of the treasure
   */
  void setTreasure(Treasure treasure, int value);

  /**
   * If the location has an exit to the left, it returns true.
   *
   * @return 1 if it has a left exit
   */
  int getLeft();

  /**
   * If the location has an exit to the right, it returns true.
   *
   * @return 1 if it has a right exit
   */
  int getRight();

  /**
   * If the location has an exit at the top, it returns true.
   *
   * @return 1 if it has a top exit
   */
  int getTop();

  /**
   * If the location has an exit at the bottom, it returns true.
   *
   * @return 1 if it has a bottom exit
   */
  int getBottom();

  /**
   * We can check the amount of sapphire stored in the given location.
   *
   * @return the value of sapphire in the location
   */
  int getSapphireValue();

  /**
   * We can check the amount of ruby stored in the given location.
   *
   * @return the value of ruby in the location
   */
  int getRubyValue();

  /**
   * We can check the amount of diamond stored in the given location.
   *
   * @return the value of diamond in the location
   */
  int getDiamondValue();
}
