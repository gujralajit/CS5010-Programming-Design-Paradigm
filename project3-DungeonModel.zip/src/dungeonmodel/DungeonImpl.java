package dungeonmodel;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Creates the dungeon based on the given row and column numbers. Based on the given
 * interconnectivity, wrapping and percentage of caves having treasure, we create an adjacency list
 * and form the dungeon based on this.
 */
public class DungeonImpl implements Dungeon {

  private final Cave[][] dungeon;
  private final Player player;
  private final int interconnectivity;
  private final boolean wrapping;
  private final int cavePercentage;
  private Vertex start;
  private Vertex end;
  private Vertex currentLocation;
  private List<Edge> adjacencyList;

  /**
   * Constructor for the dungeon based on the given attributes.
   *
   * @param row               denotes the row number of the dungeon
   * @param column            denotes the column number of the dungeon
   * @param interconnectivity denotes the interconnectivity of the dungeon
   * @param wrapping          denotes if the dungeon is wrapping or not
   * @param cavePercentage    denotes the percentage of caves having treasure
   */
  public DungeonImpl(int row, int column, int interconnectivity, boolean wrapping,
                     int cavePercentage) {
    if (row > 0 && column > 0 && interconnectivity >= 0 && cavePercentage >= 0
            && cavePercentage <= 100) {
      this.interconnectivity = interconnectivity;
      this.wrapping = wrapping;
      this.dungeon = createDungeon(row, column);
      this.player = new PlayerImpl();
      this.cavePercentage = cavePercentage;
      this.currentLocation = getStart();
      populateDungeon();
    } else {
      throw new IllegalArgumentException("Illegal arguments have been passed to the dungeon. ");
    }
  }

  /**
   * Constructor for the fake dungeon where we create a deterministic dungeon everytime based on the
   * given row and column number.
   *
   * @param row    denotes the row number of the dungeon
   * @param column denotes the column number of the dungeon
   */
  public DungeonImpl(int row, int column) {
    if (row > 0 && column > 0) {
      this.interconnectivity = 0;
      this.wrapping = false;
      this.dungeon = createFakeDungeon(row, column);
      this.player = new PlayerImpl();
      this.cavePercentage = 0;
      this.currentLocation = getStart();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than 0. ");
    }
  }

  /**
   * Creates a fake dungeon where we create a deterministic dungeon everytime based on the given
   * row and column numbers.
   *
   * @param row    denotes the row number of the dungeon
   * @param column denotes the column number of the dungeon
   * @return the fake dungeon created here
   */
  public Cave[][] createFakeDungeon(int row, int column) {
    if (row >= 0 && column >= 0) {
      Cave[][] tempDungeon = new Cave[row][column];
      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          int left = 0;
          int right = 0;
          int top = 0;
          int bottom = 0;

          if (i % 2 == 0) {
            if (i == 0 && j == 0) {
              right = 1;
            } else if (j == column - 1 && i != row - 1) {
              bottom = 1;
              left = 1;
            } else if (j == 0) {
              top = 1;
              right = 1;
            } else if (j == column - 1 && i == row - 1) {
              left = 1;
            } else {
              right = 1;
              left = 1;
            }
          } else {
            if (j == 0 && i != row - 1) {
              bottom = 1;
              right = 1;
            } else if (j == column - 1) {
              left = 1;
              top = 1;
            } else if (j == 0 && i == row - 1) {
              right = 1;
            } else {
              right = 1;
              left = 1;
            }
          }
          tempDungeon[i][j] = new Cave(left, right, top, bottom);
        }
      }
      start = new Vertex(0, 0);
      end = new Vertex(row - 1, column - 1);

      tempDungeon[row - 1][column - 1].setTreasure(Treasure.RUBY, 1);
      tempDungeon[row - 1][column - 1].setTreasure(Treasure.DIAMOND, 1);
      tempDungeon[row - 1][column - 1].setTreasure(Treasure.SAPPHIRE, 1);

      Graph g1 = new Graph(row, column, interconnectivity, wrapping);
      adjacencyList = g1.getAdjacencyList();
      Cave[][] tempDungeon1 = new Cave[row][column];

      for (int i = 0; i < row; i++) {
        System.arraycopy(tempDungeon[i], 0, tempDungeon1[i], 0, column);
      }
      return tempDungeon1;
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public Cave[][] createDungeon(int row, int column) {
    if (row >= 0 && column >= 0) {
      Cave[][] tempDungeon = new Cave[row][column];
      String[][] tempString = new String[row][column];
      Graph g1 = new Graph(row, column, interconnectivity, wrapping);
      adjacencyList = g1.getAdjacencyList();
      for (Edge e1 : adjacencyList) {
        Vertex v1 = e1.getSource();
        Vertex v2 = e1.getDestination();
        if (v1.getColumn() == 0 && v2.getColumn() == column - 1) {
          tempString[v1.getRow()][v1.getColumn()] += "left";
          tempString[v2.getRow()][v2.getColumn()] += "right";
        } else if (v1.getColumn() == column - 1 && v2.getColumn() == 0) {
          tempString[v2.getRow()][v2.getColumn()] += "left";
          tempString[v1.getRow()][v1.getColumn()] += "right";
        } else if (v1.getColumn() > v2.getColumn()) {
          tempString[v2.getRow()][v2.getColumn()] += "right";
          tempString[v1.getRow()][v1.getColumn()] += "left";
        } else if (v1.getColumn() < v2.getColumn()) {
          tempString[v2.getRow()][v2.getColumn()] += "left";
          tempString[v1.getRow()][v1.getColumn()] += "right";
        }
        if (v1.getRow() == 0 && v2.getRow() - 1 == row) {
          tempString[v2.getRow()][v2.getColumn()] += "bottom";
          tempString[v1.getRow()][v1.getColumn()] += "top";
        } else if (v1.getRow() == row - 1 && v2.getRow() == 0) {
          tempString[v2.getRow()][v2.getColumn()] += "top";
          tempString[v1.getRow()][v1.getColumn()] += "bottom";
        } else if (v1.getRow() > v2.getRow()) {
          tempString[v2.getRow()][v2.getColumn()] += "bottom";
          tempString[v1.getRow()][v1.getColumn()] += "top";
        } else if (v1.getRow() < v2.getRow()) {
          tempString[v2.getRow()][v2.getColumn()] += "top";
          tempString[v1.getRow()][v1.getColumn()] += "bottom";
        }
      }

      for (int i = 0; i < row; i++) {
        for (int j = 0; j < column; j++) {
          int left = 0;
          int right = 0;
          int top = 0;
          int bottom = 0;
          if (tempString[i][j].contains("left")) {
            left = 1;
          }
          if (tempString[i][j].contains("right")) {
            right = 1;
          }
          if (tempString[i][j].contains("top")) {
            top = 1;
          }
          if (tempString[i][j].contains("bottom")) {
            bottom = 1;
          }
          tempDungeon[i][j] = new Cave(left, right, top, bottom);
        }
      }

      int retry = 100;
      while (retry != 0) {
        try {
          getStartEnd(tempDungeon, adjacencyList);
          retry = 0;
        } catch (IllegalArgumentException ignored) {
          //retrying for new start
        }
      }
      Cave[][] tempDungeon1 = new Cave[row][column];
      for (int i = 0; i < row; i++) {
        System.arraycopy(tempDungeon[i], 0, tempDungeon1[i], 0, column);
      }
      return tempDungeon1;
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public String toString() {

    StringBuilder sb3 = new StringBuilder();
    sb3.append("\n");
    for (int j = 0; j < dungeon.length; j++) {
      if (dungeon[0][j].getTop() == 1) {
        sb3.append("  |");
      } else {
        sb3.append("   ");
      }
    }
    sb3.append("\n");
    for (Cave[] caves : dungeon) {
      StringBuilder sb1 = new StringBuilder();
      StringBuilder sb2 = new StringBuilder();
      for (int j = 0; j < dungeon[0].length; j++) {
        if (j == 0 && caves[j].getLeft() == 1) {
          sb1.append("--");
        } else if (j == 0) {
          sb1.append("  ");
        }
        if (caves[j].isTunnel()) {
          sb1.append("T");
        } else {
          sb1.append("C");
        }
        if (caves[j].getRight() == 1) {
          sb1.append("--");
        } else {
          sb1.append("  ");
        }
        if (caves[j].getBottom() == 1) {
          sb2.append("  |");
        } else {
          sb2.append("   ");
        }
      }
      sb3.append(sb1).append("\n").append(sb2).append("\n");
    }
    return sb3.append("\n").toString();
  }

  @Override
  public void populateDungeon() {

    if (cavePercentage > 0) {
      List<Cave> caveList = getCaveList(dungeon);
      int numberOfCaves = (caveList.size() * cavePercentage) / 100;
      if (numberOfCaves == 0) {
        numberOfCaves = 1;
      }
      for (int i = 0; i < numberOfCaves; i++) {
        int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
        Cave c1 = caveList.get(randomNum);
        c1.setTreasure(Treasure.RUBY, 1);
      }
      for (int i = 0; i < numberOfCaves; i++) {
        int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
        Cave c1 = caveList.get(randomNum);
        c1.setTreasure(Treasure.SAPPHIRE, 1);
      }
      for (int i = 0; i < numberOfCaves; i++) {
        int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
        Cave c1 = caveList.get(randomNum);
        c1.setTreasure(Treasure.DIAMOND, 1);
      }
    }
  }

  @Override
  public List<Cave> getCaveList(Cave[][] dungeon) {
    if (dungeon != null) {
      List<Cave> caveList = new ArrayList<>();
      for (Cave[] caves : dungeon) {
        for (int j = 0; j < dungeon[0].length; j++) {
          if (!caves[j].isTunnel()) {
            caveList.add(caves[j]);
          }
        }
      }
      return new ArrayList<>(caveList);
    } else {
      throw new IllegalArgumentException("Null dungeon has been passed to get caves. ");
    }
  }

  @Override
  public Vertex getStart() {
    return new Vertex(start.getRow(), start.getColumn());
  }

  @Override
  public Vertex getEnd() {
    return new Vertex(end.getRow(), end.getColumn());
  }

  @Override
  public String getPlayerLocation() {
    return "The player is at row : " + currentLocation.getRow() + " and column : "
            + currentLocation.getColumn() + "\n";
  }

  @Override
  public void move(int r, int c) {
    if (r >= 0 && c >= 0) {
      currentLocation = new Vertex(r, c);
      pickupTreasure(r, c);
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public void pickupTreasure(int r, int c) {
    if (r >= 0 && c >= 0) {
      if (dungeon[r][c].getSapphireValue() != 0) {
        player.addTreasure(Treasure.SAPPHIRE, dungeon[r][c].getSapphireValue());
        dungeon[r][c].setTreasure(Treasure.SAPPHIRE, 0);
      }
      if (dungeon[r][c].getRubyValue() != 0) {
        player.addTreasure(Treasure.RUBY, dungeon[r][c].getRubyValue());
        dungeon[r][c].setTreasure(Treasure.RUBY, 0);
      }
      if (dungeon[r][c].getDiamondValue() != 0) {
        player.addTreasure(Treasure.DIAMOND, dungeon[r][c].getDiamondValue());
        dungeon[r][c].setTreasure(Treasure.DIAMOND, 0);
      }
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public boolean isGameOver() {
    return currentLocation.getRow() == end.getRow()
            && currentLocation.getColumn() == end.getColumn();
  }

  @Override
  public void getStartEnd(Cave[][] tempDungeon, List<Edge> adjacencyList) {
    if (tempDungeon != null && adjacencyList != null) {
      List<Cave> caveList = getCaveList(tempDungeon);
      int randomNum = ThreadLocalRandom.current().nextInt(0, caveList.size());
      Cave c1 = caveList.get(randomNum);
      int r = 0;
      int c = 0;
      for (int i = 0; i < tempDungeon.length; i++) {
        for (int j = 0; j < tempDungeon[0].length; j++) {
          if (c1 == tempDungeon[i][j]) {
            r = i;
            c = j;
          }
        }
      }

      LinkedHashMap<Vertex, Integer> hm1 = new LinkedHashMap<>();
      List<Vertex> l1 = new ArrayList<>();

      Vertex v1 = new Vertex(r, c);

      helperStartEnd(adjacencyList, hm1, l1, v1);

      while (l1.size() != 0) {
        for (Edge e1 : adjacencyList) {
          v1 = getVertex(v1, hm1, l1, e1);
        }

        l1.remove(v1);
        if (!l1.isEmpty()) {
          v1 = l1.get(0);
        }
      }
      ArrayList<Vertex> listOfVertex = new ArrayList<>();
      for (Vertex v : hm1.keySet()) {
        if (hm1.get(v) == 0) {
          v1 = v;
        }
        if (hm1.get(v) >= 5) {
          listOfVertex.add(v);
        }
      }

      Vertex v2;
      randomNum = ThreadLocalRandom.current().nextInt(0, listOfVertex.size());
      v2 = listOfVertex.get(randomNum);
      while (tempDungeon[v2.getRow()][v2.getColumn()].isTunnel()) {
        listOfVertex.remove(v2);
        randomNum = ThreadLocalRandom.current().nextInt(0, listOfVertex.size());
        v2 = listOfVertex.get(randomNum);
      }
      start = new Vertex(v1.getRow(), v1.getColumn());
      end = new Vertex(v2.getRow(), v2.getColumn());
    } else {
      throw new IllegalArgumentException("Null arguments have been passed. ");
    }
  }

  //helper method to get start and end
  private void helperStartEnd(List<Edge> adjacencyList, LinkedHashMap<Vertex, Integer> hm1,
                              List<Vertex> l1, Vertex v1) {
    for (Edge e1 : adjacencyList) {
      if (v1.getRow() == e1.getSource().getRow()
              && v1.getColumn() == e1.getSource().getColumn()) {
        hm1.put(e1.getSource(), 0);
        l1.add(e1.getSource());
        break;
      } else if (v1.getRow() == e1.getDestination().getRow()
              && v1.getColumn() == e1.getDestination().getColumn()) {
        hm1.put(e1.getDestination(), 0);
        l1.add(e1.getDestination());
        break;
      }
    }
  }

  //helper method to get start and end
  private Vertex getVertex(Vertex v1, LinkedHashMap<Vertex, Integer> hm1,
                           List<Vertex> l1, Edge e1) {
    Vertex v2;
    if (v1.getRow() == e1.getSource().getRow() && v1.getColumn() == e1.getSource().getColumn()) {
      v1 = e1.getSource();
      v2 = e1.getDestination();
      if (!hm1.containsKey(v2)) {
        hm1.put(v2, hm1.get(v1) + 1);
        l1.add(v2);
      }
    } else if (v1.getRow() == e1.getDestination().getRow()
            && v1.getColumn() == e1.getDestination().getColumn()) {
      v1 = e1.getDestination();
      v2 = e1.getSource();
      if (!hm1.containsKey(v2)) {
        hm1.put(v2, hm1.get(v1) + 1);
        l1.add(v2);
      }
    }
    return v1;
  }


  @Override
  public String getPlayerDetails() {
    return player.toString();
  }

  @Override
  public String getCaveDetails(int r, int c) {
    if (r >= 0 && c >= 0) {
      return dungeon[r][c].toString();
    } else {
      throw new IllegalArgumentException("Row and column have to be greater than equal to 0. ");
    }
  }

  @Override
  public List<Edge> getAdjacencyList() {
    return new ArrayList<>(adjacencyList);
  }

  @Override
  public int countOfCavesContainingTreasure() {
    int count = 0;
    for (Cave[] caves : dungeon) {
      for (int j = 0; j < dungeon[0].length; j++) {
        if (!caves[j].isTunnel() && (caves[j].getRubyValue() != 0
                || caves[j].getSapphireValue() != 0 || caves[j].getDiamondValue() != 0)) {
          count++;
        }
      }
    }
    return count;
  }

  @Override
  public int getShortestPath(Vertex v1, Vertex v2) {

    Vertex end = new Vertex(v2.getRow(), v2.getColumn());

    LinkedHashMap<Vertex, Integer> hm1 = new LinkedHashMap<>();
    List<Vertex> l1 = new ArrayList<>();

    helperStartEnd(adjacencyList, hm1, l1, v1);

    while (l1.size() != 0) {
      for (Edge e1 : adjacencyList) {
        v1 = getVertex(v1, hm1, l1, e1);
        if (v1.getRow() == getEnd().getRow() && v1.getColumn() == getEnd().getColumn()) {
          end = v1;
        }
      }

      l1.remove(v1);
      if (!l1.isEmpty()) {
        v1 = l1.get(0);
      }
    }
    return hm1.get(end);
  }
}