package dungeonmodel;

import java.util.List;

/**
 * Creates a dungeon based on the graph created by the given rows and columns by the user and
 * the interconnectivity and wrapping properties. The dungeon takes creates a start and end point
 * with distance between them being 5 units. A player enters the dungeon at the start cave and exits
 * at the end cave. The dungeon stores treasure in some caves. The player has the ability to pick up
 * this treasure.
 */
public interface Dungeon {

  /**
   * Creates the dungeon based on the given row and column number and interconnectivity and wrapping
   * properties.
   *
   * @param row    denotes the row numbers of the dungeon
   * @param column denotes the column number of the dungeon
   * @return the created dungeon consisting of a 2d array of caves
   */
  Cave[][] createDungeon(int row, int column);

  /**
   * Populates the dungeon with at least the given percentage of caves having some treasure.
   * If the percentage is very low, but still greater than 0, we populate at least 1 cave with
   * treasure.
   */
  void populateDungeon();

  /**
   * The start node where the player enters the dungeon from.
   *
   * @return the start vertex.
   */
  Vertex getStart();

  /**
   * The end node where the player exits the dungeon from.
   *
   * @return the end vertex
   */
  Vertex getEnd();

  /**
   * It gets the current location of the player in the dungeon.
   *
   * @return the row and column number of the player's position at the moment
   */
  String getPlayerLocation();

  /**
   * It validates and moves the player to the denoted position in the dungeon.
   *
   * @param row    is the row number of the location to which the player is to be moved
   * @param column is the column number of the location to which the player is to be moved
   */
  void move(int row, int column);

  /**
   * It validates if this location is a cave or a tunnel and picks up the treasure and adds it to
   * the player if there is treasure to be assigned and removes it from the cave.
   *
   * @param row    is the row number of the location from which treasure is to be extracted
   * @param column is the column number of the location from which treasure is to be extracted
   */
  void pickupTreasure(int row, int column);

  /**
   * Validates if the player has reached the end location or not.
   *
   * @return true if player is on the end node
   */
  boolean isGameOver();

  /**
   * Returns the player information at this moment in the dungeon denoting the treasures currently
   * being held by the player.
   *
   * @return the string containing player information
   */
  String getPlayerDetails();

  /**
   * Returns the cave information denoting the treasure being held in the cave currently.
   *
   * @param row    denotes the row number of the cave
   * @param column denotes the column number of the cave
   * @return the string containing location information
   */
  String getCaveDetails(int row, int column);

  /**
   * Creates a list of caves when we need to populate the dungeon with treasure.
   *
   * @param dungeon gets the dungeon to which treasure is to be assigned
   * @return the list of caves present in the dungeon and their location
   */
  List<Cave> getCaveList(Cave[][] dungeon);

  /**
   * Selects a random start node and finds elements 5 nodes away from the start and chooses a random
   * end node. If there exists no such end node, it randomly selects a new start node until an end
   * is found.
   *
   * @param tempDungeon   takes in the dungeon whose start and end is to be selected
   * @param adjacencyList denotes the adjacency list which holds the edges present in the dungeon
   */
  void getStartEnd(Cave[][] tempDungeon, List<Edge> adjacencyList);

  /**
   * Gets the edges currently stored in the adjacency list that correspodn to the edges present in
   * the dungeon.
   *
   * @return the list of all edges
   */
  List<Edge> getAdjacencyList();

  /**
   * Returns the count of caves containing treasure in the dungeon.
   *
   * @return the count
   */
  int countOfCavesContainingTreasure();

  /**
   * Calculates the shortest distance among 2 vertices in teh graph.
   *
   * @param v1 first vertex
   * @param v2 second vertex
   * @return the distance between them
   */
  int getShortestPath(Vertex v1, Vertex v2);
}
