package dungeonmodel;

/**
 * Creates the Player that enters the dungeon. The player enters at the start node and exits at the
 * end node. The player has the ability to collect and hold treasure that is present in the cave
 * that the player moves into.
 */
public interface Player {

  /**
   * It adds the treasure to the player based on the treasure present in the cave.
   *
   * @param treasure denotes the type of treasure present in the cave
   * @param value    denotes the value of the treasure being assigned to the player
   */
  void addTreasure(Treasure treasure, int value);
}
