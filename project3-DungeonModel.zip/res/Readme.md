# Readme

1. **About**
    * Creating a model that can create a dungeon. 
    * The dungeon contains caves and tunnels. 
    * If the location has exactly 2 exits, it is a tunnel.  
    * The size of the dungeon is given by the user. 
    * The dungeon can be wrapping, which means the last row connects to first row and last column 
      connects to first column. 
    * The user can increase interconnectivity among the dungeons, which means increasing paths among
      nodes. 
    * By default, we create the dungeon with 0 interconnectivity, meaning there exists only 1 
      distinct path among any 2 nodes in the dungeon.  
    * We can also populate the dungeon with treasure. 
    * Treasure can be assigned only to caves. 
    * Player can enter at the start and get out at the end. 
    * Player can collect treasure from the caves. 


2. **List of Features**
    * Player can collect treasure. 
    * Caves can have treasure. 
    * Player can get into the dungeon from start cave. 
    * Player can get out of the dungeon from end cave. 


3. **How To Run**
    * User has to enter the row, column, interconnectivity, wrapping and cave percentage to create
      the dungeon.
    * The user will have to move the player.


4. **How to Use the Program**
    * User has to create the dungeon by giving command line arguments. 
    * The dungeon is created and displayed. 


5. **Description of Examples**
    * Run 1 contains a wrapping dungeon where the player is moving from start to end and prints the 
      final player description. 
    * Run 2 contains a non wrapping dungeon where the player is moving from start to end and prints 
      the final player description.
    * Run 3 contains a dungeon where the player is visiting all nodes and prints the final player 
      description. 
    * Run 4 contains a dungeon where the player is simply moving from start to end collecting the 
      treasure along the caves.
    * Run 5 contains a dungeon where the player is moving from start to end printing the cave and 
      player description after every move. 


6. **Design/Model Changes**
    * Created graph and edges and vertex classes. 
    * Added graph interface for public facing methods. 
    * Added a model class and interface to access the dungeon. 
    * Added extra methods to create adjacency lists and compare them.  


7. **Assumptions**
    * User knows how to run the program. 
    * They are aware that they have to give input for creating the dungeon. 
    * User is aware of illegal arguments (row negative, cave percentage greater than 100).


8. **Limitations**
    * Player has to be moved manually by the model. 
    * There is no objective of the game. Player enters at start and gets out at end. 


9. **Citations**
    * https://www.geeksforgeeks.org/kruskals-minimum-spanning-tree-algorithm-greedy-algo-2/
    * https://www.geeksforgeeks.org/graph-and-its-representations/
    * https://www.geeksforgeeks.org/shortest-path-unweighted-graph/
    * https://en.wikipedia.org/wiki/Kruskal's_algorithm
    * https://en.wikipedia.org/wiki/Depth-first_search#:~:text=Depth%2Dfirst%20search%20(DFS

