import org.junit.Before;
import org.junit.Test;

import dungeonmodel.Dungeon;
import dungeonmodel.DungeonImpl;
import dungeonmodel.Vertex;

import static org.junit.Assert.assertEquals;

/**
 * Testing for dungeon.
 */
public class MainTest {

  Dungeon deterministic;
  Dungeon wrapping;
  Dungeon nonWrapping;
  Dungeon d1;

  @Before
  public void setUp() {
    deterministic = new DungeonImpl(5, 5);
    wrapping = new DungeonImpl(5, 5, 6, true, 10);
    nonWrapping = new DungeonImpl(5, 5, 0, false, 20);
  }

  @Test
  public void testDeterministicDungeon() {
    assertEquals("\n               \n"
            + "  C--T--T--T--T  \n"
            + "              |\n"
            + "  T--T--T--T--T  \n"
            + "  |            \n"
            + "  T--T--T--T--T  \n"
            + "              |\n"
            + "  T--T--T--T--T  \n"
            + "  |            \n"
            + "  T--T--T--T--C  \n"
            + "               \n"
            + "\n", deterministic.toString());


    //check adjacency list size
    assertEquals(24, deterministic.getAdjacencyList().size());

    //check percentage of caves
    assertEquals(1, deterministic.countOfCavesContainingTreasure());

    //check cave to string
    assertEquals("This cave has no treasures. ",
            deterministic.getCaveDetails(0, 0));

    //check player description
    assertEquals("The player has no treasures equipped yet. ",
            deterministic.getPlayerDetails());

    //check start location
    assertEquals("0 + 0", deterministic.getStart().getRow() + " + "
            + deterministic.getStart().getColumn());

    //check player location is same as start
    assertEquals("The player is at row : 0 and column : 0\n",
            deterministic.getPlayerLocation());

    //move left in wrapping
    deterministic.move(0, 4);
    assertEquals("The player is at row : 0 and column : 4\n",
            deterministic.getPlayerLocation());

    //move bottom
    deterministic.move(1, 4);
    assertEquals("The player is at row : 1 and column : 4\n",
            deterministic.getPlayerLocation());

    //move top
    deterministic.move(0, 4);
    assertEquals("The player is at row : 0 and column : 4\n",
            deterministic.getPlayerLocation());

    //move right in wrapping
    deterministic.move(0, 0);
    assertEquals("The player is at row : 0 and column : 0\n",
            deterministic.getPlayerLocation());

    assertEquals("The player has no treasures equipped yet. ",
            deterministic.getPlayerDetails());

    //treasure in cave before player moved in
    assertEquals("The cave has the following treasures : \n\nRuby : 1\nSapphire : 1\n"
            + "Diamond : 1", deterministic.getCaveDetails(4, 4));

    //moving player from start to end
    deterministic.move(4, 0);
    deterministic.move(4, 1);
    deterministic.move(4, 2);
    deterministic.move(4, 3);
    deterministic.move(4, 4);

    //player reaches end
    assertEquals("The player is at row : 4 and column : 4\n",
            deterministic.getPlayerLocation());

    //treasure in cave after player has picked it up
    assertEquals("This cave has no treasures. ",
            deterministic.getCaveDetails(4, 4));

    //treasure picked up by player
    assertEquals("The player has the following treasures equipped --> \nRuby : 1\n"
            + "Sapphire : 1\nDiamond : 1", deterministic.getPlayerDetails());

    assertEquals(24, nonWrapping.getAdjacencyList().size());

    assertEquals(true, wrapping.getShortestPath(new
                    Vertex(wrapping.getStart().getRow(), wrapping.getStart().getColumn()),
            new Vertex(wrapping.getEnd().getRow(), wrapping.getEnd().getColumn())) >= 5);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testFailingDungeon() {
    d1 = new DungeonImpl(5, 3, 0, false, 0);
    d1 = new DungeonImpl(3, 5, 0, false, 0);
    d1 = new DungeonImpl(5, 5, -1, false, 0);
    d1 = new DungeonImpl(5, 5, 0, true, 0);
    d1 = new DungeonImpl(5, 5, 0, false, 120);

    assertEquals("The player is at row : 3 and column : 0\n",
            nonWrapping.getPlayerLocation());
  }

  //every location is connected to other
  @Test
  public void testEveryLocation() {
    for (int i = 0; i < 5; i++) {
      for (int j = 0; j < 5; j++) {
        for (int x = 0; x < 5; x++) {
          for (int y = 0; y < 5; y++) {
            assertEquals(true, wrapping.getShortestPath(new Vertex(i, j), new Vertex(x, y)) >= 0);
          }
        }
      }
    }
  }

  //move to every location
  @Test
  public void moveEverywhere() {

    assertEquals("The player is at row : 0 and column : 0\n",
            deterministic.getPlayerLocation());
    for (int i = 0; i < 5; i++) {
      if (i % 2 == 0) {
        for (int j = 0; j < 5; j++) {
          deterministic.move(i, j);
          assertEquals("The player is at row : " + i + " and column : " + j + "\n",
                  deterministic.getPlayerLocation());
        }
      } else {
        for (int j = 5 - 1; j >= 0; j--) {
          deterministic.move(i, j);
          assertEquals("The player is at row : " + i + " and column : " + j + "\n",
                  deterministic.getPlayerLocation());
        }
      }
    }
  }
}